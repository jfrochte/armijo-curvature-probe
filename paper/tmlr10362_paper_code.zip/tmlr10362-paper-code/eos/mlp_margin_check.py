# eos/mlp_margin_check.py
#
# Analysis artifact: is the mlp_fashion@0.1 divergence under
# the 5x criterion a PROBATION effect or boundary variance? Under Protocol C
# (extend init + probation, kappa=2) 2/3 seeds diverged, under the static
# extend cap 0/3 -- both at the identical initial cap kappa*beta^7 = 0.015625,
# and the probationary window can only LOWER the cap. Hypothesis: the MLP at
# eta=0.1 sits at its stability boundary under this cap and survival is
# batch-order noise. Test: 10 seeds each, static vs probation, 5x criterion.
#
# Usage: CUDA_VISIBLE_DEVICES=0 python -m eos.mlp_margin_check

import csv
import os
import sys
import time
import traceback

import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.validate_kappa_universality import (MLP, armijo_cap, train,
                                             train_probation, dev, RUNS)
from eos.data import make_fashion_mnist_loaders

SEEDS = 10
ETA, KAPPA = 0.1, 2.0


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def main():
    tl, te = make_fashion_mnist_loaders(batch_size=256, num_workers=3, seed=0)
    crit = nn.CrossEntropyLoss()
    out = os.path.join(RUNS, "mlp_margin_check.csv")
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["variant", "seed", "capped_lr",
                                          "alpha_bar", "diverged", "test_acc"])
        w.writeheader()
        for variant in ("extend_static_k2", "extend_probation_k2"):
            for sd in range(SEEDS):
                try:
                    torch.manual_seed(sd)
                    model = MLP(784, 10).to(dev)
                    for X, Y in tl:
                        Xb, Yb = X[:256].to(dev), Y[:256].to(dev)
                        break
                    clr, ab = armijo_cap(model, crit, Xb, Yb, ETA, KAPPA,
                                         "adam", max_iter=30)
                    if variant == "extend_static_k2":
                        acc, div = train(model, tl, te, clr, epochs=3)
                    else:
                        acc, div, clr = train_probation(model, tl, te, clr,
                                                        KAPPA, Xb, Yb, crit,
                                                        epochs=3)
                    w.writerow(dict(variant=variant, seed=sd,
                                    capped_lr=round(clr, 7),
                                    alpha_bar=round(ab, 7),
                                    diverged=int(div),
                                    test_acc=round(acc, 4) if acc == acc else ""))
                    f.flush()
                    log(f"{variant} s{sd}: lr={clr:.5g} div={int(div)} acc={acc}")
                except Exception:
                    log(f"!!! {variant} s{sd} FAILED:\n{traceback.format_exc()}")
    log(f"MARGIN CHECK DONE -> {out}")


if __name__ == "__main__":
    main()
