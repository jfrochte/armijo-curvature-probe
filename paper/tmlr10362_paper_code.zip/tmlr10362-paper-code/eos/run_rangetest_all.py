"""eos/run_rangetest_all.py

Reproduction artifact: extends the learning-rate range-test comparison
(Table tab:rangetest) from CIFAR-10/ResNet-18 to all four benchmarks.
Runs the identical Smith (2017) range test with the paper's budgets
and divergence rule, 5 seeds each, and writes runs/lr_rangetest_all.csv.

Protocol per benchmark and seed:
  ramp eta exponentially 1e-5 -> 1.0 over ~2 epochs of steps, record the
  smoothed loss, pick eta* = (eta at min smoothed loss)/10, discard the
  ramp model, then train a fresh init for the full paper budget at eta*
  with plain Adam. Extra cost = the ~2 ramp epochs (fwd+bwd per step).

The probe arm is NOT re-run here: the direction-matched kappa=2 probe
results at eta=0.1 already exist for all four benchmarks (the grid runs
behind tab:retry); the summary joins against those.
"""
import os, sys, csv, time, traceback
import numpy as np
import torch, torch.nn as nn
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.data import (cifar_resnet18, make_cifar10_loaders,
                      FashionCNN, make_fashion_mnist_loaders,
                      AGNewsTransformer, make_agnews_loaders,
                      imagenette_resnet18, make_imagenette_loaders)

dev = "cuda"
RES = "eos/runs"
SEEDS = int(os.environ.get("SEEDS", "5"))
GPU = int(os.environ.get("GPU", "0"))

# dataset -> (epochs, make_loaders_and_model)
def _cifar(seed):
    tl, te = make_cifar10_loaders(batch_size=256, num_workers=4, seed=seed)
    return tl, te, lambda: cifar_resnet18().to(dev)

def _fashion(seed):
    tl, te = make_fashion_mnist_loaders(batch_size=256, num_workers=4, seed=seed)
    return tl, te, lambda: FashionCNN(num_classes=10).to(dev)

def _agnews(seed):
    tl, te, vocab = make_agnews_loaders(batch_size=256, num_workers=4, seed=seed)
    return tl, te, lambda: AGNewsTransformer(vocab, num_classes=4, num_layers=4).to(dev)

def _imagenette(seed):
    tl, te = make_imagenette_loaders(batch_size=256, num_workers=4, seed=seed)
    return tl, te, lambda: imagenette_resnet18(num_classes=10).to(dev)

BENCH = {
    "cifar10": (10, _cifar),
    "fashion_mnist": (10, _fashion),
    "agnews": (10, _agnews),
    "imagenette": (20, _imagenette),
}


def log(m): print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def evaluate(model, te):
    model.eval(); c = t = 0
    with torch.no_grad():
        for X, Y in te:
            X, Y = X.to(dev), Y.to(dev)
            c += (model(X).argmax(1) == Y).sum().item(); t += Y.numel()
    return c / t


def lr_range_test(model, tl, ramp_steps, lo=1e-5, hi=1.0):
    """Smith LR finder: exponentially ramp eta, record loss; return eta* = (eta at
    min smoothed loss)/10. Non-destructive choice; model is discarded after."""
    crit = nn.CrossEntropyLoss()
    opt = torch.optim.Adam(model.parameters(), lr=lo)
    mult = (hi / lo) ** (1.0 / ramp_steps)
    lrs, losses = [], []
    avg, beta = 0.0, 0.98
    it = 0; best = float("inf")
    model.train()
    done = False
    while not done:
        for X, Y in tl:
            X, Y = X.to(dev), Y.to(dev)
            lr = lo * (mult ** it)
            for g in opt.param_groups:
                g["lr"] = lr
            opt.zero_grad(set_to_none=True)
            loss = crit(model(X), Y); loss.backward(); opt.step()
            lv = float(loss.detach())
            avg = beta * avg + (1 - beta) * lv
            smooth = avg / (1 - beta ** (it + 1))
            lrs.append(lr); losses.append(smooth)
            best = min(best, smooth)
            it += 1
            if it >= ramp_steps or not np.isfinite(lv) or smooth > 4 * best:
                done = True; break
    i_min = int(np.argmin(losses))
    return lrs[i_min] / 10.0, lrs[i_min], it


def train(model, tl, te, lr, epochs):
    crit = nn.CrossEntropyLoss()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    l0 = None; diverged = False
    for ep in range(epochs):
        model.train()
        for X, Y in tl:
            X, Y = X.to(dev), Y.to(dev)
            opt.zero_grad(set_to_none=True)
            loss = crit(model(X), Y); loss.backward(); opt.step()
            lv = float(loss.detach())
            if l0 is None: l0 = lv
            if not np.isfinite(lv) or lv > 5 * l0:
                diverged = True; break
        if diverged:
            break
    return (float("nan") if diverged else evaluate(model, te)), diverged


def main():
    torch.cuda.set_device(GPU)
    path = f"{RES}/lr_rangetest_all.csv"
    f = open(path, "w", newline="")
    w = csv.DictWriter(f, fieldnames=["dataset", "seed", "eta_min", "eta_star",
                                      "ramp_steps_used", "steps_per_epoch",
                                      "epochs", "test_acc", "diverged"])
    w.writeheader()
    log(f"RANGETEST-ALL START seeds={SEEDS} gpu={GPU}")
    t0 = time.time()
    for ds, (epochs, make) in BENCH.items():
        for sd in range(SEEDS):
            try:
                torch.manual_seed(sd); np.random.seed(sd)
                tl, te, model_fn = make(sd)
                ramp_steps = 2 * len(tl)
                m = model_fn()
                eta_star, eta_min, used = lr_range_test(m, tl, ramp_steps)
                del m; torch.cuda.empty_cache()
                torch.manual_seed(sd); np.random.seed(sd)   # fresh init for the real run
                m = model_fn()
                acc, div = train(m, tl, te, eta_star, epochs)
                w.writerow(dict(dataset=ds, seed=sd, eta_min=f"{eta_min:.6g}",
                                eta_star=f"{eta_star:.6g}", ramp_steps_used=used,
                                steps_per_epoch=len(tl), epochs=epochs,
                                test_acc=(round(acc, 4) if acc == acc else ""),
                                diverged=int(div)))
                f.flush()
                log(f"{ds} seed {sd}: eta*={eta_star:.2e} (min@{eta_min:.2e}, "
                    f"{used} ramp steps) acc={acc:.4f} div={int(div)}")
                del m; torch.cuda.empty_cache()
            except Exception:
                log(f"!!! {ds} s{sd}:\n{traceback.format_exc()}")
    log(f"RANGETEST-ALL DONE in {(time.time()-t0)/60:.1f} min -> {path}")


if __name__ == "__main__":
    main()
