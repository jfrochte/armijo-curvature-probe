#!/usr/bin/env bash
# Controlled wall-clock overhead benchmark for the cost analysis
# (Section "Cost analysis" of ./armijo_curvature_probe.tex).
#
# Why this script exists: the per-experiment wall-clock values in runs/ were
# collected under non-identical load conditions and are therefore not
# comparable across experiments. Overhead is measured instead in
# a single, interleaved session on a warmed-up GPU. This script does exactly
# that and writes runs/overhead_benchmark.csv.
#
# It compares, for each controller, the forward-only probe (FO, the deployed
# default) against the forward+backward reference variant (FB,
# EOS_PROBE_FORWARD_ONLY=0) so the saving from forward-only is reproducible.
#
# Set PY to override the python interpreter (default: `python` on PATH).
set -euo pipefail

PY=${PY:-python}
EPOCHS=${EPOCHS:-10}
SEEDS=${SEEDS:-"0 1 2"}
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/eos/runs/overhead_bench"
CSV="$ROOT/eos/runs/overhead_benchmark.csv"
mkdir -p "$OUT"

cd "$ROOT"

# Warm up the GPU so the first timed run is not penalised by cold-start.
$PY -m eos.train_adam_sls --dataset cifar10 --optimizer adam --epochs 1 \
    --seed 99 --outdir "$OUT/warmup" >/dev/null 2>&1
echo "GPU warmup done"

echo "mode,opt,seed,wall_s,test_acc,diverged" > "$CSV"
for seed in $SEEDS; do
  for opt in adam adam_init_only adam_watchdog adam_tracker; do
    for mode in 1 0; do   # 1 = forward-only (deployed), 0 = forward+backward reference
      # vanilla adam never probes, so the FO/FB distinction is meaningless: skip FB.
      if [ "$opt" = "adam" ] && [ "$mode" = "0" ]; then continue; fi
      out="$OUT/${opt}_s${seed}_m${mode}"
      EOS_PROBE_FORWARD_ONLY=$mode $PY -m eos.train_adam_sls \
        --dataset cifar10 --optimizer "$opt" --epochs "$EPOCHS" \
        --seed "$seed" --outdir "$out" >/dev/null 2>&1
      $PY - "$out/summary.json" "$mode" "$opt" "$seed" >> "$CSV" <<'PYEOF'
import json, sys
s = json.load(open(sys.argv[1]))
mode = "FO" if sys.argv[2] == "1" else "FB"
print(f"{mode},{sys.argv[3]},{sys.argv[4]},{s['wall_s']:.2f},{s['test_acc']},{s['diverged']}")
PYEOF
    done
  done
done

echo "=== wrote $CSV ==="
$PY -m eos.summarize_overhead "$CSV" || cat "$CSV"
