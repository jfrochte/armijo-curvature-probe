# eos/optimizer.py
#
# Line-search optimiser (GGAO, Appendix A of the manuscript) with a mode
# flag, used for the Edge-of-Stability measurements of this study.
#
# Modes:
#   "gs+armijo" — the golden-section variant (Golden Section in [0, alpha_max]
#                 then Armijo backtracking on the result).
#   "armijo"    — pure Armijo backtracking starting from alpha_max.
#                 (This is the SLS-style baseline; isolates what GS adds.)
#   "fixed"     — no line search, alpha = alpha_max (sanity check).

import torch


class GGAO(torch.optim.Optimizer):
    def __init__(self, params,
                 alpha_max=1.0,
                 mode="gs+armijo",
                 gs_tol=1e-4, gs_max_iter=20,
                 armijo_c=1e-4, armijo_beta=0.5, armijo_max_iter=10,
                 use_tanh=True):
        assert mode in ("gs+armijo", "armijo", "fixed")
        defaults = dict(alpha_max=alpha_max)
        super().__init__(params, defaults)
        self.mode = mode
        self.gs_tol = gs_tol
        self.gs_max_iter = gs_max_iter
        self.armijo_c = armijo_c
        self.armijo_beta = armijo_beta
        self.armijo_max_iter = armijo_max_iter
        self.use_tanh = use_tanh
        self.last_alpha = 0.0
        self.last_gnorm = 0.0  # ||g||_2 for logging

    def step(self, closure, eval_loss=None):
        with torch.enable_grad():
            loss_tensor = closure()
        cur_loss = float(loss_tensor)

        params = [p for grp in self.param_groups
                    for p in grp["params"] if p.grad is not None]
        if not params:
            return loss_tensor

        x0    = [p.detach().clone() for p in params]
        grads = [p.grad.detach().clone() for p in params]
        d     = [-torch.tanh(g) if self.use_tanh else -g for g in grads]
        gd    = sum((g * di).sum().item() for g, di in zip(grads, d))
        gnorm = sum((g * g).sum().item() for g in grads) ** 0.5
        self.last_gnorm = gnorm
        alpha_max = self.param_groups[0]["alpha_max"]

        @torch.no_grad()
        def set_alpha(alpha):
            for p, x0p, dp in zip(params, x0, d):
                p.data.copy_(x0p + alpha * dp)

        if eval_loss is not None:
            def f_alpha(alpha):
                set_alpha(alpha)
                return float(eval_loss())
        else:
            def f_alpha(alpha):
                set_alpha(alpha)
                with torch.enable_grad():
                    return float(closure())

        if self.mode == "fixed":
            alpha = alpha_max

        elif self.mode == "armijo":
            alpha = alpha_max
            for _ in range(self.armijo_max_iter):
                if f_alpha(alpha) <= cur_loss + self.armijo_c * alpha * gd:
                    break
                alpha *= self.armijo_beta

        else:  # gs+armijo
            phi = (1 + 5 ** 0.5) / 2
            a, b = 0.0, alpha_max
            c = b - (b - a) / phi
            e = a + (b - a) / phi
            fc, fe = f_alpha(c), f_alpha(e)
            for _ in range(self.gs_max_iter):
                if fc > fe:
                    a, c, fc = c, e, fe
                    e = a + (b - a) / phi
                    fe = f_alpha(e)
                else:
                    b, e, fe = e, c, fc
                    c = b - (b - a) / phi
                    fc = f_alpha(c)
                if abs(b - a) < self.gs_tol:
                    break
            alpha = 0.5 * (a + b)

            for _ in range(self.armijo_max_iter):
                if f_alpha(alpha) <= cur_loss + self.armijo_c * alpha * gd:
                    break
                alpha *= self.armijo_beta

        set_alpha(alpha)
        self.last_alpha = alpha
        with torch.enable_grad():
            return closure()
