# eos/master_scatter.py
#
# Reproduction artifact: produces runs/fig_master_scatter.png
#   -> Figure \label{fig:scatter} in armijo_curvature_probe.tex
#   Data: the pure-Armijo line-search runs (CIFAR-10, Fashion-MNIST, digits)
#   produced by run_mechanism_all.sh / run_all.sh, which also invoke this script.
#
# Message of the figure: the inverse line-search step 1/alpha tracks the local
# sharpness lambda_1 with a log-log slope close to 1 (hence the strong per-run
# correlation reported in Table tab:correlation), but sits a roughly constant
# factor BELOW the textbook 1/alpha = lambda_1 line, because the Armijo step
# inverts the directional curvature q = g^T H g / ||g||^2 <= lambda_1, not
# lambda_1 itself. We restrict to the pure-Armijo runs (the actual probe used by
# the safeguard); earlier line-search variants are not used for the reported results.

import os, sys, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Pure-Armijo runs only, grouped and coloured by dataset/architecture.
# `fit`: draw a per-architecture regression line + report r. The two
# architectures of Table tab:correlation are fitted; digits (a tiny MLP whose
# lambda_1 spans well under a decade) is shown only as context, no fit.
GROUPS = [
    ("CIFAR-10 / ResNet-18", "C0", "o", True,
     [f"eos/runs/cifar10_ggao_armijo_seed{s}" for s in (0, 1, 2)]),
    ("Fashion-MNIST / CNN", "C1", "s", True,
     [f"eos/runs/fashion_ggao_armijo_seed{s}" for s in (0, 1, 2)]),
    ("Imagenette / ResNet-18 (128px)", "C4", "v", True,
     [f"eos/runs/imagenette_ggao_armijo_seed{s}" for s in (0, 1, 2)]),
    ("digits / MLP", "C2", "^", False,
     ["eos/runs/digits_ggao_armijo_seed0"]),
]


def load(run_dir):
    p = os.path.join(run_dir, "trace.csv")
    if not os.path.exists(p):
        return None
    df = pd.read_csv(p)
    sub = df.dropna(subset=["mean_alpha_window", "lambda_1"])
    sub = sub[(sub["mean_alpha_window"] > 0) & (sub["lambda_1"] > 0)]
    return sub


def main(out_png):
    fig, ax = plt.subplots(figsize=(7, 5.5))
    notes = []
    for label, color, marker, fit, dirs in GROUPS:
        gl, gi = [], []
        for run_dir in dirs:
            sub = load(run_dir)
            if sub is None or len(sub) == 0:
                continue
            gl.extend(sub["lambda_1"].values)
            gi.extend(1.0 / sub["mean_alpha_window"].values)
        if not gl:
            continue
        gl = np.asarray(gl); gi = np.asarray(gi)
        ax.scatter(gl, gi, color=color, marker=marker, label=label,
                   s=42, alpha=0.75, edgecolors="black", linewidths=0.3)
        # Per-architecture log-log fit (the correlation is a WITHIN-run effect;
        # pooling across architectures would wash it out, so we never pool).
        if fit and len(gl) >= 5:
            ll, li = np.log10(gl), np.log10(gi)
            slope, intercept = np.polyfit(ll, li, 1)
            r = np.corrcoef(ll, li)[0, 1]
            xfit = np.logspace(np.log10(gl.min()), np.log10(gl.max()), 30)
            ax.plot(xfit, 10 ** intercept * xfit ** slope, color=color, lw=2)
            notes.append(rf"{label.split(' / ')[0]}: slope $={slope:.2f}$, "
                         rf"$r(\log\alpha,\log\lambda_1)={-r:.2f}$")

    # Reference lines for context: textbook quadratic relation and stability bound.
    xs = np.logspace(0, 4, 50)
    ax.plot(xs, xs, "k--", alpha=0.5, label=r"$1/\alpha = \lambda_1$ (textbook)")
    ax.plot(xs, 0.5 * xs, "k:", alpha=0.4, label=r"$1/\alpha = \lambda_1/2$ (stability)")

    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"$\lambda_1$ (top Hessian eigenvalue, probe batch)")
    ax.set_ylabel(r"$1/\alpha$ (inverse Armijo step)")
    ax.set_title(r"Within each architecture, $1/\alpha$ tracks local sharpness $\lambda_1$")
    ax.legend(loc="upper left", fontsize=8.5)
    ax.grid(True, which="both", alpha=0.2)
    if notes:
        ax.text(0.985, 0.60, "\n".join(notes),
                transform=ax.transAxes, ha="right", va="center", fontsize=8.5,
                bbox=dict(boxstyle="round", fc="white", ec="0.7", alpha=0.9))
    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    print(f"[plot] {out_png}")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "eos/runs/fig_master_scatter.png"
    main(out)
