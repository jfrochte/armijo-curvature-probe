# eos/probe.py
#
# Periodic probe of the top Hessian eigenvalue using PyHessian (Yao et al. 2020).
# Used during training to log local sharpness alongside the line-search alpha.

import torch
import torch.nn as nn
from pyhessian import hessian


class HessianProbe:
    """Probes top-k Hessian eigenvalues on a fixed batch.

    Uses PyHessian's power-iteration / Lanczos under the hood.
    Model is temporarily set to eval mode during the probe so BN/dropout don't
    contaminate the curvature estimate. Train state is restored afterwards.
    """
    def __init__(self, model, criterion, probe_inputs, probe_targets,
                 top_n=1, device="cuda"):
        self.model = model
        self.criterion = criterion
        self.probe_inputs = probe_inputs.to(device)
        self.probe_targets = probe_targets.to(device)
        self.top_n = top_n
        self.device = device

    @torch.no_grad()
    def _zero_grads(self):
        for p in self.model.parameters():
            if p.grad is not None:
                p.grad = None

    def __call__(self):
        was_training = self.model.training
        self.model.eval()
        self._zero_grads()
        H = hessian(
            self.model, self.criterion,
            data=(self.probe_inputs, self.probe_targets),
            cuda=(self.device == "cuda"),
        )
        eigenvalues, _ = H.eigenvalues(top_n=self.top_n)
        # also get the trace as a coarse "average curvature" measure
        try:
            trace = float(sum(H.trace(maxIter=20, tol=1e-3))) / max(
                sum(p.numel() for p in self.model.parameters()), 1)
        except Exception:
            trace = float("nan")
        self._zero_grads()
        if was_training:
            self.model.train()
        return {"eigenvalues": [float(x) for x in eigenvalues],
                "trace_over_n": trace}

    def directional_curvature(self):
        """Rayleigh quotient of the Hessian along the gradient on the probe batch:
        q = g^T H g / g^T g. This is the *directional* curvature the Armijo
        condition actually sees (d = -g), as opposed to the top eigenvalue
        lambda_1. Computed with one Hessian-vector product via autograd.
        Returns (q, grad_norm_sq)."""
        was_training = self.model.training
        self.model.eval()
        self._zero_grads()
        params = [p for p in self.model.parameters() if p.requires_grad]
        out = self.model(self.probe_inputs)
        loss = self.criterion(out, self.probe_targets)
        g = torch.autograd.grad(loss, params, create_graph=True)
        gnorm2 = sum((gi * gi).sum() for gi in g)
        # H g = grad( sum_i g_i . g_i^detach , params )
        gd = sum((gi * gi.detach()).sum() for gi in g)
        Hg = torch.autograd.grad(gd, params, retain_graph=False)
        gHg = sum((gi.detach() * hgi).sum() for gi, hgi in zip(g, Hg))
        q = (gHg / gnorm2).item()
        gn2 = float(gnorm2.item())
        self._zero_grads()
        if was_training:
            self.model.train()
        return q, gn2

    def armijo_alpha(self, c=1e-4, beta=0.5, alpha_max=1.0, max_iter=10):
        """Armijo backtracking step along -g on the probe batch, at the current
        parameters, with the same constants as the line-search optimiser. Returned on
        the *same* batch and point as directional_curvature(), so 1/alpha can be
        compared directly against q (apples-to-apples test of the local relation
        1/alpha = q / (2(1-c)) up to the backtracking factor beta)."""
        was_training = self.model.training
        self.model.eval()
        self._zero_grads()
        params = [p for p in self.model.parameters() if p.requires_grad]
        out = self.model(self.probe_inputs)
        loss0 = self.criterion(out, self.probe_targets)
        g = torch.autograd.grad(loss0, params)
        L0 = float(loss0.item())
        gnorm2 = float(sum((gi * gi).sum().item() for gi in g))
        x0 = [p.detach().clone() for p in params]

        def f(alpha):
            with torch.no_grad():
                for p, x, gi in zip(params, x0, g):
                    p.copy_(x - alpha * gi)
                val = float(self.criterion(self.model(self.probe_inputs),
                                           self.probe_targets).item())
            return val

        alpha = alpha_max
        for _ in range(max_iter):
            if f(alpha) <= L0 - c * alpha * gnorm2:
                break
            alpha *= beta
        with torch.no_grad():
            for p, x in zip(params, x0):
                p.copy_(x)
        self._zero_grads()
        if was_training:
            self.model.train()
        return alpha
