# eos/summarize_probe_variance.py
#
# Reproduction artifact: prints the LaTeX rows of Table \label{tab:probe-variance}
#   from eos/runs/probe_batch_variance.csv (written by
#   eos/probe_batch_variance.py, the GPU measurement). Split from the
#   measurement so that freeze_paper_data.py stays deterministic and cheap.
#
# Usage: python -m eos.summarize_probe_variance

import os
import pandas as pd

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
LABELS = {"cifar10": "CIFAR-10/ResNet-18", "fashion_mnist": "Fashion-MNIST/CNN",
          "agnews": "AG News/Transformer", "imagenette": "Imagenette/ResNet-18"}


def main():
    df = pd.read_csv(os.path.join(RUNS, "probe_batch_variance.csv"))
    print("\n  LaTeX rows (Benchmark & variant & median alpha & min & max"
          " & rung span & share within 1 rung):")
    for ds in ["cifar10", "fashion_mnist", "agnews", "imagenette"]:
        for direction, dl in [("grad", "raw gradient"), ("adam", "Adam-direction")]:
            s = df[(df.dataset == ds) & (df.direction == direction)]
            if not len(s):
                continue
            print(f"  {LABELS[ds]} & {dl}"
                  f" & ${s.alpha_median.median():.3g}$"
                  f" & ${s.alpha_min.min():.3g}$ & ${s.alpha_max.max():.3g}$"
                  f" & ${s.rung_range.max():.0f}$"
                  f" & ${100 * s.frac_within_1rung.mean():.0f}\\%$ \\\\")


if __name__ == "__main__":
    main()
