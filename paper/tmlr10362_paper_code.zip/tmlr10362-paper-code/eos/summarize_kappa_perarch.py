"""eos/summarize_kappa_perarch.py

Reproduction artifact: prints the LaTeX body of the per-architecture appendix table
  \\label{tab:kappa-perarch} (and writes runs/kappa_perarch_summary.csv).
  Data: runs/kappa_universality.csv.

The aggregate rows of tab:universal-kappa average accuracy over architectures
with different chance levels and task difficulties; this table breaks that down
per architecture at the 100x-too-large rate (the discriminating one), so the
aggregate can be read as a compact summary of per-architecture behaviour rather
than a single opaque mean. Mean test accuracy over 3 seeds; a divergent run
counts as 0; ``DIV.'' = all seeds diverged.
"""
import os, csv
import numpy as np
import pandas as pd

RUNS = "eos/runs"
PRETTY = {
    "cifar_bn": "ResNet-18 BN (CIFAR-10)", "fashion": "CNN (Fashion-MNIST)",
    "cifar_nobn": "ResNet-18 no-norm (CIFAR-10)", "resnet_gn_cifar": "ResNet-18 GN (CIFAR-10)",
    "vgg_bn_cifar": "VGG BN (CIFAR-10)", "mlp_fashion": "MLP (Fashion-MNIST)",
    "lstm_agnews": "LSTM (AG News)", "transformer_nowarmup": "Transformer no-warmup (AG News)",
    "transformer_wide": "Transformer wide (AG News)",
}
ORDER = ["cifar_bn", "vgg_bn_cifar", "resnet_gn_cifar", "cifar_nobn", "fashion",
         "mlp_fashion", "lstm_agnews", "transformer_nowarmup", "transformer_wide"]
# vanilla + grad-probe from kappa_universality.csv; Adam-dir column from the
# kappa-sweep at the RECOMMENDED kappa=2 (kappa_sweep_adamdir.csv).
VAR = [("vanilla", "vanilla Adam"), ("gradprobe_k0.25", "grad probe")]
ADAM_KAPPA = 2.0


def cell(d):
    n = len(d)
    if n == 0:
        return "--"
    ndiv = int(d.diverged.sum())
    if ndiv == n:
        return "DIV."
    acc = np.where(d.diverged == 1, 0.0, d.test_acc).mean()
    s = f"${acc:.2f}$"
    if ndiv > 0:
        s = f"{acc:.2f}\\,({ndiv}/{n} d.)"
    return s


def main():
    df = pd.read_csv(f"{RUNS}/kappa_universality.csv")
    sweep = pd.read_csv(f"{RUNS}/kappa_sweep_adamdir.csv")
    eta = 0.1
    rows = []
    print("=== LaTeX body (paste into tab:kappa-perarch), eta=100x (0.1) ===")
    print("Architecture & " + " & ".join(lbl for _, lbl in VAR)
          + f" & Adam-dir probe ($\\kappa={ADAM_KAPPA:g}$) \\\\")
    print("\\midrule")
    for arch in ORDER:
        cells = []
        rec = {"arch": arch}
        for v, _ in VAR:
            c = cell(df[(df.arch == arch) & (df.variant == v) & (np.isclose(df.eta, eta))])
            cells.append(c); rec[v] = c
        adam = cell(sweep[(sweep.arch == arch) & (np.isclose(sweep.kappa, ADAM_KAPPA))
                          & (np.isclose(sweep.eta, eta))])
        cells.append(adam); rec["adamprobe_k2"] = adam
        print(f"{PRETTY.get(arch, arch)} & " + " & ".join(cells) + " \\\\")
        rows.append(rec)
    with open(f"{RUNS}/kappa_perarch_summary.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["arch", "vanilla", "gradprobe_k0.25", "adamprobe_k2"])
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"\nSaved {RUNS}/kappa_perarch_summary.csv")


if __name__ == "__main__":
    main()
