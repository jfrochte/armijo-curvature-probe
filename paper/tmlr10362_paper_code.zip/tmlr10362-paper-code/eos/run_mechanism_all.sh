#!/usr/bin/env bash
# Re-run the canonical mechanism dataset (pure Armijo, CIFAR-10/ResNet-18 and
# Fashion-MNIST/CNN, 3 seeds each) WITH the new per-probe logging of the
# directional curvature q = g^T H g/||g||^2 and the on-batch Armijo step
# alpha_probe, alongside lambda_1. Deterministic training => the alpha<->lambda_1
# correlation (Table 5) is reproduced; q and alpha_probe enable the scoped-(a)
# proposition test (Appendix / Section 5.4).
set -uo pipefail
PY=${PY:-python}
GPU0=${GPU0:-0}
GPU1=${GPU1:-1}
cd "$(dirname "$0")/.."
mkdir -p eos/runs

run () {  # gpu dataset seed
    local gpu=$1 ds=$2 sd=$3
    local tag; [[ "$ds" == "cifar10" ]] && tag=cifar10 || tag=fashion
    local outdir="eos/runs/${tag}_ggao_armijo_seed${sd}"
    if [[ -f "$outdir/summary.json" ]]; then
        echo "[skip] $outdir (already present)"; return
    fi
    echo "[run gpu$gpu] $outdir"
    "$PY" -m eos.train --dataset "$ds" --optimizer ggao_armijo \
        --epochs 10 --probe-every 100 --probe-size 256 --batch-size 256 \
        --num-workers 4 --gpu "$gpu" --seed "$sd" --outdir "$outdir" \
        > "${outdir}.log" 2>&1 || echo "[FAIL] $outdir"
}

( run "$GPU0" cifar10 0; run "$GPU0" cifar10 1; run "$GPU0" cifar10 2 ) &
P0=$!
( run "$GPU1" fashion_mnist 0; run "$GPU1" fashion_mnist 1; run "$GPU1" fashion_mnist 2 ) &
P1=$!
wait $P0 $P1
echo "=== mechanism runs finished; analysing ==="
for sd in 0 1 2; do
    "$PY" -m eos.analyze eos/runs/cifar10_ggao_armijo_seed${sd} eos/runs/fashion_ggao_armijo_seed${sd} \
        > /dev/null 2>&1
done
echo "--- correlation rows (Table 5) ---"
"$PY" -m eos.summarize_mechanism eos/runs/cifar10_ggao_armijo_seed 0 1 2
"$PY" -m eos.summarize_mechanism eos/runs/fashion_ggao_armijo_seed 0 1 2
echo "--- proposition test (scoped-a) ---"
"$PY" -m eos.summarize_proposition "CIFAR-10/ResNet-18" eos/runs/cifar10_ggao_armijo_seed0 eos/runs/cifar10_ggao_armijo_seed1 eos/runs/cifar10_ggao_armijo_seed2
"$PY" -m eos.summarize_proposition "Fashion-MNIST/CNN" eos/runs/fashion_ggao_armijo_seed0 eos/runs/fashion_ggao_armijo_seed1 eos/runs/fashion_ggao_armijo_seed2
"$PY" -m eos.summarize_proposition "Both" eos/runs/cifar10_ggao_armijo_seed0 eos/runs/cifar10_ggao_armijo_seed1 eos/runs/cifar10_ggao_armijo_seed2 eos/runs/fashion_ggao_armijo_seed0 eos/runs/fashion_ggao_armijo_seed1 eos/runs/fashion_ggao_armijo_seed2
