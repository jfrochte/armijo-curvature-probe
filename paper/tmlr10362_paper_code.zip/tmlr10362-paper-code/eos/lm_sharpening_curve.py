# eos/lm_sharpening_curve.py
#
# Analysis artifact (decides between the "probationary probe" and
# "anchored micro-trial" fixes): does the Armijo reading
# alpha (Adam direction) FALL during the first steps of stable GPT-2
# training, i.e. does the landscape sharpen right after initialisation?
#
# Trains gpt2-<size> at a safe lr and re-runs the direction-matched probe
# at a schedule of steps. If alpha drops such that kappa=2*min(alpha) caps
# below the measured divergence boundary (0.03..0.04 for small), a
# probationary min-probe restores the fixed kappa=2 without calibration.
#
# Usage: python -m eos.lm_sharpening_curve --size small --lr 0.001 --gpu 0

import os, sys, argparse, json
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.lm import GPT2LM, lm_loss, BinBatches, TRAIN_BIN

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
PROBE_AT = [0, 5, 10, 20, 50, 100, 200, 350, 500]


def probe(model, params, xb, yb, ac):
    model.zero_grad(set_to_none=True)
    with ac:
        l0 = lm_loss(model, xb, yb)
    l0.backward()
    grads = [p.grad.detach().clone() for p in params]
    d = [-g / (g.abs() + 1e-8) for g in grads]
    gd = sum((g * di).sum().item() for g, di in zip(grads, d))
    x0 = [p.detach().clone() for p in params]
    L0 = float(l0.detach())
    alpha = 1.0
    for _ in range(8):
        with torch.no_grad():
            for p, x, dp in zip(params, x0, d):
                p.data.copy_(x + alpha * dp)
            with ac:
                lt = float(lm_loss(model, xb, yb))
        if lt <= L0 + 1e-4 * alpha * gd:
            break
        alpha *= 0.5
    with torch.no_grad():
        for p, x in zip(params, x0):
            p.data.copy_(x)
    model.zero_grad(set_to_none=True)
    return alpha, L0


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--size", default="small")
    p.add_argument("--lr", type=float, default=0.001)
    p.add_argument("--seeds", nargs="+", type=int, default=[0, 1])
    p.add_argument("--gpu", type=int, default=0)
    args = p.parse_args()
    torch.cuda.set_device(args.gpu)
    device = torch.device("cuda")
    ac = torch.autocast("cuda", dtype=torch.bfloat16)

    out = {}
    for seed in args.seeds:
        torch.manual_seed(seed)
        np.random.seed(seed)
        model = GPT2LM(args.size, block_size=512).to(device)
        model.train()
        params = [pp for pp in model.parameters() if pp.requires_grad]
        batches = BinBatches(TRAIN_BIN, 512, 16, device, seed=1000 + seed)
        opt = torch.optim.AdamW(model.parameters(), lr=args.lr)
        curve = []
        for step in range(0, PROBE_AT[-1] + 1):
            if step in PROBE_AT:
                xb, yb = batches.next()
                a, L0 = probe(model, params, xb, yb, ac)
                curve.append({"step": step, "alpha": a, "loss": L0})
                print(f"[{args.size} seed={seed} lr={args.lr}] step={step:4d} "
                      f"alpha={a:.5g} loss={L0:.3f}", flush=True)
            xb, yb = batches.next()
            opt.zero_grad(set_to_none=True)
            with ac:
                loss = lm_loss(model, xb, yb)
            loss.backward()
            opt.step()
        alphas = [c["alpha"] for c in curve]
        print(f"  seed {seed}: alpha_init={alphas[0]:.5g} min={min(alphas):.5g} "
              f"kappa2*min={2 * min(alphas):.5g}", flush=True)
        out[f"seed{seed}"] = curve
        del model, opt
        torch.cuda.empty_cache()

    path = os.path.join(RUNS, f"lm_sharpening_{args.size}_lr{args.lr}.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"[written] {path}")


if __name__ == "__main__":
    main()
