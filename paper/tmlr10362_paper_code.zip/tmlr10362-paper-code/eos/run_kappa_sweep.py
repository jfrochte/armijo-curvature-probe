"""eos/run_kappa_sweep.py

Reproduction artifact: produces runs/kappa_sweep_adamdir.csv for the kappa-sweep of the
Adam-direction probe (Table tab:kappa-universal-sweep). Aggregate with
summarize_kappa_sweep.py. The kappa=3.0 column is read from the existing
runs/kappa_universality.csv (already validated); this script adds the smaller,
more conservative kappa values so we can report a value with ZERO divergences.

Same nine architectures / two learning rates / three seeds and the same
armijo_cap + train + divergence criterion as validate_kappa_universality.py
(imported, not duplicated). Writes to eos/runs/ (canonical, not scratch).
"""
import os, sys, csv, time, traceback
import numpy as np
import torch, torch.nn as nn
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.data import (cifar_resnet18, make_cifar10_loaders, FashionCNN,
                      make_fashion_mnist_loaders, make_agnews_loaders, AGNewsTransformer)
from eos.validate_kappa_universality import (armijo_cap, train, MLP, vgg_bn,
                                             LSTMClf, strip_norm, bn_to_gn)

dev = "cuda"
RES = "eos/runs"
KAPPAS = [float(x) for x in os.environ.get("KAPPA_SWEEP", "1.0,2.0").split(",")]
SEEDS = int(os.environ.get("SEEDS", "3"))


def log(m): print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def main():
    cif_tl, cif_te = make_cifar10_loaders(batch_size=256, num_workers=3, seed=0)
    fas_tl, fas_te = make_fashion_mnist_loaders(batch_size=256, num_workers=3, seed=0)
    ag_tl, ag_te, vocab = make_agnews_loaders(batch_size=256, num_workers=2, seed=0)
    crit = nn.CrossEntropyLoss()
    ep, tsteps = 3, 600
    archs = [
        ("cifar_bn", lambda: cifar_resnet18(), cif_tl, cif_te, dict(epochs=ep)),
        ("fashion", lambda: FashionCNN(), fas_tl, fas_te, dict(epochs=ep)),
        ("cifar_nobn", lambda: strip_norm(cifar_resnet18()), cif_tl, cif_te, dict(epochs=ep)),
        ("transformer_nowarmup",
         lambda: AGNewsTransformer(vocab, num_classes=4, d_model=256, nhead=4,
                                   num_layers=8, dim_feedforward=1024, max_len=64),
         ag_tl, ag_te, dict(steps=tsteps)),
        ("mlp_fashion", lambda: MLP(784, 10), fas_tl, fas_te, dict(epochs=ep)),
        ("vgg_bn_cifar", lambda: vgg_bn(10), cif_tl, cif_te, dict(epochs=ep)),
        ("resnet_gn_cifar", lambda: bn_to_gn(cifar_resnet18()), cif_tl, cif_te, dict(epochs=ep)),
        ("lstm_agnews", lambda: LSTMClf(vocab), ag_tl, ag_te, dict(steps=tsteps)),
        ("transformer_wide", lambda: AGNewsTransformer(vocab, num_classes=4, d_model=384,
                              nhead=6, num_layers=6, dim_feedforward=1536, max_len=64),
         ag_tl, ag_te, dict(steps=tsteps)),
    ]
    etas = [1e-3, 0.1]
    path = f"{RES}/kappa_sweep_adamdir.csv"
    new = not os.path.exists(path); f = open(path, "a", newline="")
    w = csv.DictWriter(f, fieldnames=["arch", "kappa", "eta", "seed", "capped_lr",
                                      "alpha_bar", "diverged", "test_acc"])
    if new:
        w.writeheader(); f.flush()
    seen = set() if new else {(r["arch"], r["kappa"], r["eta"], r["seed"])
                             for r in csv.DictReader(open(path))}
    log(f"KAPPA-SWEEP START kappas={KAPPAS}")
    t0 = time.time()
    for arch, mf, tl, te, tk in archs:
        Xb = Yb = None
        for X, Y in tl:
            Xb, Yb = X[:256].to(dev), Y[:256].to(dev); break
        for eta in etas:
            for kappa in KAPPAS:
                for sd in range(SEEDS):
                    key = (arch, str(kappa), str(eta), str(sd))
                    if key in seen:
                        continue
                    try:
                        torch.manual_seed(sd)
                        model = mf().to(dev)
                        clr, ab = armijo_cap(model, crit, Xb, Yb, eta, kappa, "adam")
                        acc, div = train(model, tl, te, clr, **tk)
                        w.writerow(dict(arch=arch, kappa=kappa, eta=eta, seed=sd,
                                        capped_lr=round(clr, 7),
                                        alpha_bar=round(ab, 7) if ab == ab else "",
                                        diverged=int(div),
                                        test_acc=round(acc, 4) if acc == acc else "")); f.flush()
                    except Exception:
                        log(f"!!! {arch} k={kappa} eta={eta} s{sd}:\n{traceback.format_exc()}")
            log(f"done: {arch} eta={eta} ({(time.time()-t0)/60:.1f} min)")
    log(f"KAPPA-SWEEP DONE in {(time.time()-t0)/60:.1f} min")


if __name__ == "__main__":
    main()
