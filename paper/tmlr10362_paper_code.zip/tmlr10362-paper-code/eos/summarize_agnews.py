# eos/summarize_agnews.py
#
# Reproduction artifact: prints the LaTeX body of Table \label{tab:agnews-rescue}
#   in armijo_curvature_probe.tex.
#   Data: run_agnews.sh.
#
# Aggregate the AG News / small-Transformer sweep: a second,
# non-vision domain. Same structure as summarize_fashion.py: mean +/- std
# test accuracy and divergence rate over 5 seeds, six initial learning rates,
# all controllers plus the parameter-free baselines. Emits a console table and
# a paste-ready LaTeX block.

import os, json
import numpy as np

ROOT = "eos/runs"
OPTS = ["adam", "adam_init_only", "adam_watchdog", "adam_tracker",
        "adam_schedulefree", "prodigy"]
LRS = ["0.001", "0.01", "0.1", "0.3", "1.0", "3.0"]
SEEDS = [0, 1, 2, 3, 4]

PRETTY = {
    "adam": "Vanilla Adam",
    "adam_init_only": "Adam-InitOnly",
    "adam_watchdog": "Adam-Watchdog",
    "adam_tracker": "Adam-Tracker",
    "adam_schedulefree": "Schedule-Free Adam",
    "prodigy": "Prodigy",
}


def load(opt, lr, prefix="agnews"):
    accs, divs = [], []
    for sd in SEEDS:
        p = f"{ROOT}/{prefix}_{opt}_lr{lr}_seed{sd}/summary.json"
        if not os.path.exists(p):
            continue
        s = json.load(open(p))
        divs.append(int(s["diverged"]))
        accs.append(s["test_acc"] if not s["diverged"] else float("nan"))
    return {"accs": accs, "divs": divs}


def cell(opt, lr, prefix="agnews"):
    r = load(opt, lr, prefix)
    n = len(r["accs"])
    if n == 0:
        return "--"
    div_count = sum(r["divs"])
    valid = [a for a, d in zip(r["accs"], r["divs"]) if d == 0]
    if div_count == n:
        return "DIV."
    if not valid:
        return f"0.10$^*$\\,({div_count}/{n} div.)"
    mean, std = float(np.mean(valid)), float(np.std(valid))
    if div_count > 0:
        return f"{mean:.3f}\\,({div_count}/{n} div.)"
    return f"${mean:.3f} \\pm {std:.3f}$"


CALIB_OPTS = ["adam_init_only", "adam_watchdog", "adam_tracker"]


def print_console():
    print(f"\n{'Optimizer':<20}" + "".join(f"{('lr='+lr):<16}" for lr in LRS))
    print("-" * (20 + 16 * len(LRS)))
    print("[uncalibrated kappa=0.25]")
    for opt in OPTS:
        print(f"{PRETTY[opt]:<20}" + "".join(f"{cell(opt, lr):<16}" for lr in LRS))
    if any(os.path.exists(f"{ROOT}/agnews_calib_{o}_lr0.001_seed0/summary.json") for o in CALIB_OPTS):
        print("[calibrated kappa=0.05]")
        for opt in CALIB_OPTS:
            print(f"{PRETTY[opt]:<20}" + "".join(f"{cell(opt, lr, 'agnews_calib'):<16}" for lr in LRS))


def print_latex():
    print("\n=== LaTeX table (paste into paper) ===")
    print("\\begin{tabular}{lcccccc}")
    print("\\toprule")
    print(" & " + " & ".join(f"$\\eta={lr}$" for lr in LRS) + " \\\\")
    print("\\midrule")
    print("\\multicolumn{7}{l}{\\textit{Uncalibrated, $\\kappa = 0.25$ (CIFAR-10 default)}} \\\\")
    for opt in OPTS:
        cells = [cell(opt, lr) for lr in LRS]
        print(f"{PRETTY[opt]:<20} & {' & '.join(cells)} \\\\")
    if any(os.path.exists(f"{ROOT}/agnews_calib_{o}_lr0.001_seed0/summary.json") for o in CALIB_OPTS):
        print("\\midrule")
        print("\\multicolumn{7}{l}{\\textit{Calibrated, $\\kappa = 0.05$ (one extra divergence sweep)}} \\\\")
        for opt in CALIB_OPTS:
            cells = [cell(opt, lr, "agnews_calib") for lr in LRS]
            print(f"{PRETTY[opt]:<20} & {' & '.join(cells)} \\\\")
    print("\\bottomrule")
    print("\\end{tabular}")


if __name__ == "__main__":
    print_console()
    print_latex()
