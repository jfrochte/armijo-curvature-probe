#!/usr/bin/env bash
# eos/run_default_unsafe.sh
#
# Reproduction artifact: produces the run directories for Table \label{tab:default-unsafe}
#   ("Where the default learning rate is itself unsafe").
#   Aggregate with: python -m eos.summarize_default_unsafe
#
# Two regimes where Adam's framework-default eta=1e-3 is itself too large for the
# curvature at initialisation:
#   (1) a normalisation-free ResNet-18 on CIFAR-10 (3 epochs), and
#   (2) a warmup-free 12-layer Transformer on AG News (600-step short protocol).
# For each: vanilla Adam at the default 1e-3 (expected to fail/diverge), vanilla
# Adam at a best-tuned smaller lr, and Adam-InitOnly at the default 1e-3 with a
# per-architecture kappa set by a one-minute divergence sweep.
#
# Reuses the exact controller and divergence criterion of train_adam_sls.py via
# the new --no-norm / --tf-layers / --max-steps flags. Idempotent (skips runs
# whose summary.json already exists). Round-robins seeds across two GPUs.
set -u
cd "$(dirname "$0")/.."                     # repo root
mkdir -p eos/runs
PY=${PY:-python}
GPU0=${GPU0:-0}; GPU1=${GPU1:-1}
SEEDS=${SEEDS:-"0 1 2 3"}
RUNS=eos/runs

run () {  # $1 outdir-tag  $2.. = train args
  local tag=$1; shift
  local out=$RUNS/$tag
  if [ -f "$out/summary.json" ]; then echo "[skip] $tag"; return; fi
  echo "[run]  $tag"
  $PY -m eos.train_adam_sls "$@" --outdir "$out" >"$out.log" 2>&1 || echo "[FAIL] $tag (see $out.log)"
}

i=0
for s in $SEEDS; do
  gpu=$([ $((i % 2)) -eq 0 ] && echo $GPU0 || echo $GPU1); i=$((i+1))

  # ---- (1) normalisation-free ResNet-18 / CIFAR-10, 3 epochs ----
  for lr in 0.0001 0.0003 0.001; do
    run "dunsafe_resnet_nonorm_adam_lr${lr}_seed${s}" \
        --dataset cifar10 --no-norm --optimizer adam --lr $lr \
        --epochs 3 --batch-size 256 --num-workers 3 --seed $s --gpu $gpu
  done
  run "dunsafe_resnet_nonorm_init_lr0.001_k0.05_seed${s}" \
      --dataset cifar10 --no-norm --optimizer adam_init_only --init-safety 0.05 \
      --lr 0.001 --epochs 3 --batch-size 256 --num-workers 3 --seed $s --gpu $gpu

  # ---- (2) warmup-free 12-layer Transformer / AG News, 600 steps ----
  for lr in 0.0001 0.0003 0.001; do
    run "dunsafe_tf12_adam_lr${lr}_seed${s}" \
        --dataset agnews --tf-layers 12 --optimizer adam --lr $lr \
        --epochs 5 --max-steps 600 --batch-size 256 --num-workers 3 --seed $s --gpu $gpu
  done
  run "dunsafe_tf12_init_lr0.001_k0.005_seed${s}" \
      --dataset agnews --tf-layers 12 --optimizer adam_init_only --init-safety 0.005 \
      --lr 0.001 --epochs 5 --max-steps 600 --batch-size 256 --num-workers 3 --seed $s --gpu $gpu
done
echo "ALL DONE"
