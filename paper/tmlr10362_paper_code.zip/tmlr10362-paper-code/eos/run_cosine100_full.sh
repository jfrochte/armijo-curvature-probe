#!/usr/bin/env bash
# Long-schedule CIFAR-10/ResNet-18 learning-rate robustness table
# at a realistic training length. CIFAR-10/ResNet-18, 100 epochs, cosine
# annealing, 3 seeds. Vanilla Adam (works only at small lr) vs Adam-InitOnly
# (robust across the range) over the full six-lr grid.
#
# Reuses the single-seed cos100_* runs already on disk (idempotent).
set -uo pipefail
PY=${PY:-python}
GPU0=${GPU0:-0}
GPU1=${GPU1:-1}
SEEDS=${SEEDS:-"0 1 2"}
LRS=${LRS:-"0.001 0.01 0.1 0.3 1.0 3.0"}
cd "$(dirname "$0")/.."
mkdir -p eos/runs

JOBS=()
for opt in adam adam_init_only; do
    for lr in $LRS; do
        for sd in $SEEDS; do
            JOBS+=("eos/runs/cos100_${opt}_lr${lr}_seed${sd}|${opt}|${lr}|${sd}")
        done
    done
done

run_one () {
    local gpu=$1 spec=$2 outdir optimizer lr sd
    IFS='|' read -r outdir optimizer lr sd <<< "$spec"
    if [[ -f "$outdir/summary.json" ]]; then echo "[skip gpu$gpu] $outdir"; return; fi
    echo "[run  gpu$gpu] $outdir"
    "$PY" -m eos.train_adam_sls --dataset cifar10 --optimizer "$optimizer" --cosine \
        --epochs 100 --probe-every 50 --batch-size 256 --num-workers 4 \
        --gpu "$gpu" --seed "$sd" --lr "$lr" --outdir "$outdir" \
        > "${outdir}.log" 2>&1 || echo "[FAIL gpu$gpu] $outdir"
}

worker () {
    local gpu=$1 parity=$2 i=0
    for spec in "${JOBS[@]}"; do
        if (( i % 2 == parity )); then run_one "$gpu" "$spec"; fi
        ((i++))
    done
}

echo "=== launching ${#JOBS[@]} cosine-100 jobs across GPU$GPU0 and GPU$GPU1 ==="
worker "$GPU0" 0 &
P0=$!
worker "$GPU1" 1 &
P1=$!
wait $P0 $P1
echo "=== cosine-100 full grid finished ==="
"$PY" -m eos.summarize_cosine100
