# eos/summarize_mechanism.py
#
# Reproduction artifact: prints ONE LaTeX row of Table \label{tab:correlation}
#   in armijo_curvature_probe.tex (one invocation per run prefix / architecture).
#   Reads correlations.json written by analyze.py. Data: run_mechanism_all.sh.
# B: aggregate the alpha <-> lambda_1 correlation across seeds for a given run
# prefix, to produce one row of the mechanism table (tab:correlation). Reads the
# correlations.json written by eos/analyze.py.
#
# Usage: python -m eos.summarize_mechanism <prefix> <seed0> <seed1> ...
#   e.g. python -m eos.summarize_mechanism eos/runs/fashion_ggao_armijo_seed 0 1 2

import os, sys, json
import numpy as np


def main(prefix, seeds):
    pr, sr, pp, am = [], [], [], []
    for sd in seeds:
        p = f"{prefix}{sd}/correlations.json"
        if not os.path.exists(p):
            print(f"[skip] {p} missing"); continue
        c = json.load(open(p))["correlations"]
        if "pearson_log_alpha_vs_log_lambda1" not in c:
            print(f"[skip] {p}: too few valid probe points (n={c.get('n')})"); continue
        pr.append(c["pearson_log_alpha_vs_log_lambda1"])
        sr.append(c["spearman_log_alpha_vs_log_lambda1"])
        pp.append(c["pearson_log_p"])
        am.append(c["alpha_mean"])
    if not pr:
        print("no data"); return
    n = len(pr)
    print(f"\n=== mechanism summary ({n} seeds) for {prefix}* ===")
    print(f"  Pearson  log-alpha vs log-lambda1 : {np.mean(pr):.3f} +/- {np.std(pr):.3f}")
    print(f"  Spearman log-alpha vs log-lambda1 : {np.mean(sr):.3f} +/- {np.std(sr):.3f}")
    print(f"  mean p-value (log Pearson)        : {np.mean(pp):.2e}")
    print(f"  mean alpha                        : {np.mean(am):.3f}")
    print("\n  LaTeX row (Variant & rbar_logalpha,loglam & rbar_Spearman & pbar & abar):")
    pbar = np.mean(pp)
    # Report small mean p-values as decade thresholds instead of rounding them
    # to "0.000": pick the largest 10^{-k} that still bounds pbar from above.
    if pbar <= 0 or pbar < 1e-12:
        pstr = "< 10^{-12}"
    elif pbar < 1e-3:
        k = int(np.floor(-np.log10(pbar)))
        pstr = f"< 10^{{-{k}}}"
    else:
        pstr = f"{pbar:.3f}"
    print(f"  & ${np.mean(pr):.3f} \\pm {np.std(pr):.3f}$ & ${np.mean(sr):.2f} \\pm {np.std(sr):.2f}$ & ${pstr}$ & ${np.mean(am):.3f}$ \\\\")


if __name__ == "__main__":
    main(sys.argv[1], [int(s) for s in sys.argv[2:]])
