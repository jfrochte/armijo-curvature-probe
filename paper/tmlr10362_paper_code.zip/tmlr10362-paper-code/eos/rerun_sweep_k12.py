# eos/rerun_sweep_k12.py
#
# Validation artifact: re-establish the kappa-sweep columns
# kappa=1 and kappa=2 (STATIC cap, extend-on-saturation init reading -- the
# published protocol of tab:kappa-universal-sweep) under the unified 5x
# divergence criterion. kappa=3 is covered by Protocol A of
# eos/rerun_suite_protocols.py; the deployed variant by Protocol C.
#
# Motivation: under 5x, mlp_fashion diverges at eta=0.1 in Protocol C
# (kappa=2 + probation), so the published "zero divergences in all 54 runs
# at kappa=2" (computed under the suite's previous 8x criterion) needs re-checking
# per sweep column. Own CSV (rerun_sweep_k12.csv) to avoid append races
# with the concurrently running rerun_suite_protocols.py on the other GPU.
#
# Usage: CUDA_VISIBLE_DEVICES=0 python -m eos.rerun_sweep_k12

import csv
import os
import sys
import time
import traceback

import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.validate_kappa_universality import (armijo_cap, build_suite, train,
                                             dev, RUNS, SMOKE)

SEEDS = 1 if SMOKE else 3


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


JOBS = [
    ("S", "extend_static_k2", "adam", 2.0),
    ("S", "extend_static_k1", "adam", 1.0),
]


def main():
    crit = nn.CrossEntropyLoss()
    ep = 1 if SMOKE else 3
    tsteps = 100 if SMOKE else 600
    archs = build_suite(ep, tsteps)
    etas = [1e-3] if SMOKE else [1e-3, 0.1]

    path = os.path.join(RUNS, "rerun_sweep_k12.csv")
    new = not os.path.exists(path)
    f = open(path, "a", newline="")
    fields = ["protocol", "arch", "variant", "eta", "seed", "requested_lr",
              "effective_lr", "alpha_bar", "backtracks", "accepted",
              "cap_bound", "diverged", "test_acc"]
    w = csv.DictWriter(f, fieldnames=fields)
    if new:
        w.writeheader()
        f.flush()
    seen = set() if new else {(r["arch"], r["variant"], r["eta"], r["seed"])
                              for r in csv.DictReader(open(path))}
    log(f"SWEEP-K12 START (SMOKE={SMOKE}), {len(seen)} rows present")

    for proto, label, mode, kappa in JOBS:
        for arch, mf, tl, te, tk in archs:
            for X, Y in tl:
                Xb, Yb = X[:256].to(dev), Y[:256].to(dev)
                break
            for eta in etas:
                for sd in range(SEEDS):
                    if (arch, label, str(eta), str(sd)) in seen:
                        continue
                    try:
                        torch.manual_seed(sd)
                        model = mf().to(dev)
                        clr, ab, det = armijo_cap(model, crit, Xb, Yb, eta,
                                                  kappa, mode, max_iter=30,
                                                  return_details=True)
                        acc, div = train(model, tl, te, clr, **tk)
                        w.writerow(dict(
                            protocol=proto, arch=arch, variant=label, eta=eta,
                            seed=sd, requested_lr=eta,
                            effective_lr=round(clr, 7),
                            alpha_bar=round(ab, 7) if ab == ab else "",
                            backtracks=det["backtracks"],
                            accepted=det["accepted"],
                            cap_bound=det["cap_bound"], diverged=int(div),
                            test_acc=round(acc, 4) if acc == acc else ""))
                        f.flush()
                        log(f"{arch} {label} eta={eta} s{sd}: lr={clr:.5g} "
                            f"div={int(div)} acc={acc}")
                    except Exception:
                        log(f"!!! {arch} {label} eta={eta} s{sd} FAILED:\n"
                            f"{traceback.format_exc()}")
    log("SWEEP-K12 DONE")


if __name__ == "__main__":
    main()
