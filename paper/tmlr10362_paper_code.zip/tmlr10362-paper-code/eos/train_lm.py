# eos/train_lm.py
#
# Reproduction artifact: language-model rescue
# experiment behind Table \label{tab:lm-rescue}. GPT-2-style model on
# WikiText-103, AdamW WITHOUT warmup across the paper's learning-rate grid,
# vanilla vs. the direction-matched init probe (kappa = 2), fixed step
# budget, exactly the divergence criterion of the vision experiments
# (loss exceeds 5x its initial value or becomes non-finite).
#
# Mirrors train_adam_sls.py: same optimizer wrapper (AdamSLSControlled,
# base="adamw", probe_direction="adam"), same closure/eval_loss probe
# protocol, same trace.csv/summary.json layout. Training runs in bf16
# autocast (fp32 master weights); the probe's backtracking trials evaluate
# the loss under the same autocast, i.e. exactly what a practitioner would
# deploy.
#
# Usage (one run):
#   python -m eos.train_lm --model small --optimizer adamw_init_dir \
#       --lr 0.1 --seed 0 --steps 10000 --gpu 0 \
#       --outdir eos/runs/lm_small_adamw_init_dir_lr0.1_seed0
# Driver for the full grid: eos/run_lm_grid.sh

import os, sys, json, time, argparse, csv, math
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.adam_sls import AdamSLSControlled
from eos.lm import GPT2LM, lm_loss, BinBatches, sequential_val_batches, TRAIN_BIN

DIVERGENCE_FACTOR = 5.0  # eos/divergence.py convention

# Probationary probe (LM extension): re-probe at these steps
# and monotonically lower the cap to init_safety * min(alpha seen so far).
# Motivation: at LM initialisation the landscape along Adam's direction
# sharpens within a handful of steps (eos/lm_sharpening_curve.py: alpha
# falls 0.0625 -> beta^8 by step 5), so a step-0 reading alone is insufficient.
# On the classifier suite the init reading already sits at the probe floor
# beta^8, so the same rule is a no-op there.
PROBATION_STEPS = {1, 2, 3, 5, 8, 12, 20, 35, 50}


def make_optimizer(name, params, lr, init_safety, model=None):
    if name == "adamw":
        return torch.optim.AdamW(params, lr=lr), False
    if name == "adamw_warmup":
        # linear warmup baseline, mirrors train_adam_sls.py adam_warmup:
        # start at lr/100, ramp linearly to lr over --warmup-steps.
        return torch.optim.AdamW(params, lr=lr / 100.0), False
    if name in ("adamw_init_dir", "adamw_init_dir_probation"):
        return AdamSLSControlled(params, lr=lr, probe_every=0, model=model,
                                 mode="init_only", init_safety=init_safety,
                                 probe_direction="adam", base="adamw"), True
    if name == "adamw_warmup_probation":
        # Probe-guarded warmup: the probe (init + probation window) caps the
        # ramp TARGET, the driver ramps lr linearly toward the (possibly
        # shrinking) target. init_probe=False: the driver probes explicitly
        # before the first step so that step 1 already runs on the ramp.
        return AdamSLSControlled(params, lr=lr, probe_every=0, model=model,
                                 mode="init_only", init_probe=False,
                                 init_safety=init_safety,
                                 probe_direction="adam", base="adamw"), True
    raise ValueError(name)


@torch.no_grad()
def evaluate(model, device, block_size, batch_size, autocast):
    model.eval()
    losses, ntok = [], 0
    for xb, yb in sequential_val_batches(block_size, batch_size, device):
        with autocast:
            loss = lm_loss(model, xb, yb)
        losses.append(float(loss) * xb.numel())
        ntok += xb.numel()
    model.train()
    mean = sum(losses) / max(ntok, 1)
    return mean, math.exp(min(mean, 20.0)), ntok


def train(args):
    device = torch.device("cuda")
    torch.cuda.set_device(args.gpu)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    autocast = torch.autocast(device_type="cuda", dtype=torch.bfloat16,
                              enabled=not args.fp32)

    model = GPT2LM(args.model, block_size=args.block_size).to(device)
    nparams = sum(p.numel() for p in model.parameters())
    model.train()
    batches = BinBatches(TRAIN_BIN, args.block_size, args.batch_size,
                         device, seed=1000 + args.seed)
    optimizer, is_controlled = make_optimizer(
        args.optimizer, model.parameters(), args.lr, args.init_safety,
        model=model)

    os.makedirs(args.outdir, exist_ok=True)
    csv_f = open(os.path.join(args.outdir, "trace.csv"), "w", newline="")
    writer = csv.DictWriter(csv_f, fieldnames=["step", "wall_s", "loss", "lr", "alpha"])
    writer.writeheader()

    print(f"[run] model=gpt2-{args.model} ({nparams/1e6:.0f}M) opt={args.optimizer} "
          f"lr_init={args.lr} steps={args.steps} bs={args.batch_size}x{args.block_size} "
          f"seed={args.seed} init_safety={args.init_safety}", flush=True)

    t0 = time.time()
    initial_loss, diverged, step = None, False, 0
    ramp_target = None
    if args.optimizer == "adamw_warmup_probation":
        # explicit probe at initialisation, then start on the ramp
        xb, yb = batches.next()

        def _closure0():
            optimizer.zero_grad(set_to_none=True)
            with autocast:
                loss = lm_loss(model, xb, yb)
            loss.backward()
            return loss

        def _eval0():
            with torch.no_grad(), autocast:
                return lm_loss(model, xb, yb)

        optimizer._probe_at_current_params(_closure0, _eval0)
        ramp_target = min(args.lr, args.init_safety * optimizer.alpha_baseline)
        optimizer._set_lr(ramp_target / 100.0)
        print(f"[guarded-warmup] alpha_init={optimizer.alpha_baseline:.5g} "
              f"ramp target={ramp_target:.5g}", flush=True)
    while step < args.steps:
        xb, yb = batches.next()

        def closure():
            optimizer.zero_grad(set_to_none=True)
            with autocast:
                loss = lm_loss(model, xb, yb)
            loss.backward()
            return loss

        def eval_loss():
            with torch.no_grad(), autocast:
                return lm_loss(model, xb, yb)

        if is_controlled:
            loss = optimizer.step(closure, eval_loss)
        else:
            loss = closure()
            optimizer.step()
        step += 1
        if args.optimizer == "adamw_warmup" and step <= args.warmup_steps:
            ramp = step / args.warmup_steps
            cur = (1 - ramp) * (args.lr / 100.0) + ramp * args.lr
            for g in optimizer.param_groups:
                g["lr"] = cur
        if args.optimizer == "adamw_init_dir_probation" and step in PROBATION_STEPS:
            optimizer._probe_at_current_params(closure, eval_loss)
            target = args.init_safety * min(a for _, a in optimizer.alpha_history)
            if optimizer.current_lr > target:
                print(f"[probation] step={step} alpha={optimizer.last_alpha:.5g} "
                      f"cap {optimizer.current_lr:.5g} -> {target:.5g}", flush=True)
                optimizer._set_lr(target)
        if args.optimizer == "adamw_warmup_probation":
            if step in PROBATION_STEPS:
                optimizer._probe_at_current_params(closure, eval_loss)
                new_target = min(ramp_target, args.init_safety * min(
                    a for _, a in optimizer.alpha_history))
                if new_target < ramp_target:
                    print(f"[guarded-warmup] step={step} "
                          f"alpha={optimizer.last_alpha:.5g} target "
                          f"{ramp_target:.5g} -> {new_target:.5g}", flush=True)
                    ramp_target = new_target
            if step <= args.warmup_steps:
                r = step / args.warmup_steps
                optimizer._set_lr((1 - r) * ramp_target / 100.0 + r * ramp_target)
            else:
                optimizer._set_lr(ramp_target)
        cur_loss = float(loss.detach()) if torch.is_tensor(loss) else float(loss)
        if initial_loss is None:
            initial_loss = cur_loss

        if step % args.log_every == 0 or step == 1:
            lr_now = (optimizer.current_lr if is_controlled
                      else optimizer.param_groups[0]["lr"])
            alpha = optimizer.last_alpha if is_controlled else float("nan")
            writer.writerow({"step": step, "wall_s": time.time() - t0,
                             "loss": cur_loss, "lr": lr_now, "alpha": alpha})
            csv_f.flush()

        # eos/divergence.py: loss exceeds 5x its initial value, or NaN/Inf.
        if not math.isfinite(cur_loss) or cur_loss > DIVERGENCE_FACTOR * initial_loss:
            print(f"[diverged] step={step} loss={cur_loss:.4f}", flush=True)
            diverged = True
            break

    val_loss, val_ppl, val_tokens = (float("nan"),) * 3
    if not diverged:
        val_loss, val_ppl, val_tokens = evaluate(
            model, device, args.block_size, args.batch_size, autocast)
    elapsed = time.time() - t0
    csv_f.close()

    summary = {
        "dataset": "wikitext103", "model": f"gpt2-{args.model}",
        "n_params": nparams, "optimizer": args.optimizer,
        "lr_initial": args.lr, "steps_budget": args.steps, "steps_run": step,
        "batch_size": args.batch_size, "block_size": args.block_size,
        "tokens_per_step": args.batch_size * args.block_size,
        "seed": args.seed, "init_safety": args.init_safety,
        "diverged": diverged, "val_loss": val_loss, "val_ppl": val_ppl,
        "val_tokens": int(val_tokens) if val_tokens == val_tokens else 0,
        "wall_s": elapsed,
    }
    if is_controlled:
        summary["alpha_init"] = optimizer.alpha_baseline
        summary["lr_after_cap"] = optimizer.current_lr
    with open(os.path.join(args.outdir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print(f"[done] diverged={diverged} val_loss={val_loss:.4f} "
          f"val_ppl={val_ppl:.1f} wall={elapsed:.1f}s", flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--model", choices=["tiny", "mid", "small", "medium"],
                   default="small")
    p.add_argument("--optimizer",
                   choices=["adamw", "adamw_warmup", "adamw_init_dir",
                            "adamw_init_dir_probation",
                            "adamw_warmup_probation"],
                   default="adamw")
    p.add_argument("--warmup-steps", type=int, default=1000,
                   help="adamw_warmup: linear ramp length (10%% of the "
                        "10k budget, proportional to the vision baseline)")
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--steps", type=int, default=10000)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--block-size", type=int, default=512)
    p.add_argument("--init-safety", type=float, default=2.0)
    p.add_argument("--log-every", type=int, default=50)
    p.add_argument("--fp32", action="store_true",
                   help="disable bf16 autocast (robustness check)")
    p.add_argument("--gpu", type=int, default=0)
    p.add_argument("--outdir", required=True)
    train(p.parse_args())
