#!/usr/bin/env bash
# Reproduction artifact:
# alpha--lambda_1 correlation on INDEPENDENTLY GENERATED fixed-step
# trajectories. The manuscript's mechanism runs use pure-Armijo updates, so
# the line search both generates the trajectory and takes the measurement;
# here the trajectory comes from fixed-step Adam / AdamW / SGD and the probe
# (HessianProbe: lambda_1 via PyHessian, directional q via HVP, Armijo alpha
# on the same frozen probe batch, all in eval mode) is measurement-only.
#
# Rates: Adam 1e-3 (default) and 1e-2 (largest non-diverging grid rate =
# near-EoS regime), AdamW 1e-3, SGD(momentum 0.9) 5e-2. 3 seeds each,
# 10 epochs, probe every 50 steps (~40-47 observations per run).
#
# Usage: bash eos/run_fixed_mechanism.sh [GPU]
set -u
GPU=${1:-0}
PY=${PY:-python}
cd "$(dirname "$0")/.."

for ds in cifar10 fashion_mnist; do
  for cfg in adam:0.001 adam:0.01 adamw:0.001 sgd:0.05; do
    opt=${cfg%%:*}; lr=${cfg##*:}
    for seed in 0 1 2; do
      out="eos/runs/${ds}_${opt}_fixed_lr${lr}_seed${seed}"
      if [ -f "$out/summary.json" ]; then
        echo "=== skip $out (summary exists)"; continue
      fi
      echo "=== $ds $opt lr=$lr seed=$seed -> $out"
      "$PY" -m eos.train --dataset "$ds" --optimizer "$opt" --lr "$lr" \
        --epochs 10 --probe-every 50 --probe-size 512 \
        --seed "$seed" --gpu "$GPU" --outdir "$out" \
        || echo "!!! FAILED (continuing): $out"
    done
  done
done
echo "=== fixed-step mechanism runs finished ==="
