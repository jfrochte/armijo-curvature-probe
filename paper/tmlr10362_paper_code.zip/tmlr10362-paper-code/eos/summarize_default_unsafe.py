"""eos/summarize_default_unsafe.py

Reproduction artifact: prints the LaTeX body of Table \\label{tab:default-unsafe}
  in armijo_curvature_probe.tex, and writes runs/default_unsafe_summary.csv.
  Data: run_default_unsafe.sh.

Two regimes where Adam's framework-default eta=1e-3 is itself unsafe. For each
we report three cells: vanilla Adam at the default 1e-3, vanilla Adam at its
best-tuned smaller lr (highest mean test_acc among the non-diverged sweep
points), and Adam-InitOnly at the default 1e-3 with the per-architecture kappa.
Mean over the available seeds; divergence accounted exactly as elsewhere.
"""
import os, json, glob, csv
import numpy as np

RUNS = "eos/runs"


def cells(prefix_seed_glob):
    """Aggregate all seeds for a given run-tag pattern (one config)."""
    accs, divs = [], []
    for d in sorted(glob.glob(os.path.join(RUNS, prefix_seed_glob))):
        sj = os.path.join(d, "summary.json")
        if not os.path.exists(sj):
            continue
        s = json.load(open(sj))
        divs.append(int(s["diverged"]))
        if not s["diverged"]:
            accs.append(s["test_acc"])
    n = len(divs)
    return accs, divs, n


def fmt(accs, divs, n):
    if n == 0:
        return "--", None
    if sum(divs) == n:
        return f"DIV.\\ ({sum(divs)}/{n})", None
    mean = float(np.mean(accs))
    if sum(divs) > 0:
        return f"{mean:.3f}\\,({sum(divs)}/{n} div.)", mean
    return f"${mean:.3f}$", mean


def best_tuned(tag, lrs):
    """Pick the lr with the highest mean test_acc (non-diverged) from a sweep."""
    best = (None, -1.0, None)
    for lr in lrs:
        accs, divs, n = cells(f"{tag}_adam_lr{lr}_seed*")
        if n and sum(divs) < n:
            m = float(np.mean(accs))
            if m > best[1]:
                best = (lr, m, (accs, divs, n))
    return best  # (lr, mean, cellsdata)


def main():
    rows = []
    out = []
    # (label, run-tag, sweep lrs, init kappa-tag)
    settings = [
        ("ResNet-18, \\emph{no normalisation} (CIFAR-10)",
         "dunsafe_resnet_nonorm", ["0.0001", "0.0003", "0.001"],
         "dunsafe_resnet_nonorm_init_lr0.001_k0.05_seed*", "0.05"),
        ("Transformer, \\emph{no warmup} (AG News)",
         "dunsafe_tf12", ["0.0001", "0.0003", "0.001"],
         "dunsafe_tf12_init_lr0.001_k0.005_seed*", "0.005"),
    ]
    for label, tag, lrs, init_glob, kap in settings:
        da, dd, dn = cells(f"{tag}_adam_lr0.001_seed*")          # default 1e-3
        default_str, _ = fmt(da, dd, dn)
        blr, bmean, bcell = best_tuned(tag, lrs)                  # best tuned
        tuned_str = f"${bmean:.3f}$ ($\\eta{{=}}{float(blr):g}$)" if blr else "--"
        ia, idv, ineff = cells(init_glob)                        # InitOnly @1e-3
        init_str, imean = fmt(ia, idv, ineff)
        init_str = (init_str.replace("$", "") if "DIV" in init_str else init_str)
        init_cell = (f"{init_str} ($\\kappa{{=}}{kap}$)")
        out.append(f"{label} & {default_str} & {tuned_str} & {init_cell} \\\\")
        rows.append(dict(setting=label, default_1e3=default_str,
                         best_tuned_lr=blr, best_tuned_acc=bmean,
                         initonly_kappa=kap, initonly_acc=imean))
        print(f"{label}\n  default 1e-3: {default_str}\n  best tuned: {tuned_str}"
              f"\n  InitOnly: {init_cell}\n")

    print("=== LaTeX body (paste into tab:default-unsafe) ===")
    print("Setting & vanilla, default $10^{-3}$ & vanilla, best tuned "
          "& Adam-InitOnly @ $10^{-3}$ \\\\")
    print("\\midrule")
    for line in out:
        print(line)

    with open(os.path.join(RUNS, "default_unsafe_summary.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["setting", "default_1e3", "best_tuned_lr",
                                          "best_tuned_acc", "initonly_kappa", "initonly_acc"])
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"\nSaved {RUNS}/default_unsafe_summary.csv")


if __name__ == "__main__":
    main()
