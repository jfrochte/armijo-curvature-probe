"""eos/summarize_lowcost_baselines.py

Reproduction artifact: prints the LaTeX body of Table \\label{tab:lowcost-cross}
  and writes runs/lowcost_baselines_summary.csv.
  Data: the per-benchmark grid runs (runs/<ds>_<opt>_lr<lr>_seed<sd>);
  the arms missing from the original grids are produced by
  run_lowcost_baselines.sh.

Cross-benchmark comparison of the low-cost safeguards: vanilla Adam,
gradient-norm clipping, linear warmup, the two parameter-free optimisers,
and the direction-matched init probe, each at the framework default
eta = 1e-3 and at the 100x-too-large eta = 0.1, on all four benchmarks
(5 seeds, identical budgets and divergence rule as the grid tables).
The extra-cost column counts extra forward/backward passes, which is
architecture- and hardware-invariant.
"""
import os, csv, json
import numpy as np

RUNS = "eos/runs"
DATASETS = [("cifar", "CIFAR-10/RN18"),
            ("fashion", "Fashion/CNN"),
            ("agnews", "AG News/Transf."),
            ("imagenette", "Imagenette/RN18")]
LRS = ["0.001", "0.01", "0.1", "0.3", "1.0", "3.0"]
TABLE_LRS = ["0.001", "0.1"]
SEEDS = range(5)
ARMS = [("adam", "Vanilla Adam", "0"),
        ("adam_clip", "Adam + grad-clip ($\\|g\\| \\le 1$)", "0"),
        ("adam_warmup", "Adam + 200-step warmup", "0"),
        ("adam_schedulefree", "Schedule-Free AdamW", "0"),
        ("prodigy", "Prodigy", "0"),
        ("adam_init_dir", "Adam-InitOnly (dir., $\\kappa=2$)", "$1$\\,fb$+8$\\,f")]


def load(ds, opt, lr, seed):
    p = os.path.join(RUNS, f"{ds}_{opt}_lr{lr}_seed{seed}", "summary.json")
    if not os.path.exists(p):
        return None
    return json.load(open(p))


def cell(ds, opt, lr):
    runs = [load(ds, opt, lr, s) for s in SEEDS]
    runs = [r for r in runs if r is not None]
    if not runs:
        return None, None, None, "--"
    ndiv = sum(1 for r in runs if r.get("diverged"))
    accs = [r["test_acc"] for r in runs if not r.get("diverged")]
    if not accs:
        return len(runs), ndiv, (np.nan, np.nan), "DIV."
    m, sd = float(np.mean(accs)), float(np.std(accs))
    s = f"${m:.3f} \\pm {sd:.3f}$"
    if ndiv:
        s = f"${m:.3f}$\\,({ndiv}/{len(runs)} div.)"
    return len(runs), ndiv, (m, sd), s


def main():
    rows = []
    for ds, _ in DATASETS:
        for opt, _, _ in ARMS:
            for lr in LRS:
                n, ndiv, stat, _ = cell(ds, opt, lr)
                if n is None:
                    continue
                rows.append(dict(dataset=ds, opt=opt, lr=lr, n=n, div=ndiv,
                                 mean_acc=(round(stat[0], 4) if stat[0] == stat[0] else ""),
                                 std_acc=(round(stat[1], 4) if stat[1] == stat[1] else "")))
    path = f"{RUNS}/lowcost_baselines_summary.csv"
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

    print("=== LaTeX body (paste into tab:lowcost-cross) ===")
    heads = " & ".join(f"\\multicolumn{{2}}{{c}}{{{label}}}" for _, label in DATASETS)
    print(f"Method & extra passes & {heads} \\\\")
    sub = " & ".join(["$10^{-3}$ & $10^{-1}$"] * len(DATASETS))
    print(f" & & {sub} \\\\")
    print("\\midrule")
    for opt, pretty, cost in ARMS:
        cells = []
        for ds, _ in DATASETS:
            for lr in TABLE_LRS:
                cells.append(cell(ds, opt, lr)[3])
        print(f"{pretty} & {cost} & " + " & ".join(cells) + " \\\\")
    print(f"[csv] {path} ({len(rows)} rows)")


if __name__ == "__main__":
    main()
