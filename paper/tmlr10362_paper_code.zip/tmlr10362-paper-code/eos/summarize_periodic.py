"""eos/summarize_periodic.py

Reproduction artifact: prints the LaTeX body of Table \\label{tab:periodic}
  in armijo_curvature_probe.tex, and writes runs/periodic_summary.csv.

Periodic in-training probing across regimes at the default eta=1e-3:
  - Smooth CIFAR-10/ResNet-18  : test acc, from the verified main sweep CSV
    (runs/adam_sls_summary.csv) -- vanilla / watchdog / tracker.
  - Smooth AG News/Transformer : test acc, from the agnews_* run dirs.
  - Plateau XOR toy            : % solved, from runs/xor_periodic.csv
    (produced by run_xor_periodic.py).
Two real-task rows are READ from already-verified data (no re-run); only the XOR
row needs run_xor_periodic.py. Real-task Tracker uses the default K=50; the XOR
Tracker uses its best probe interval K.
"""
import os, json, glob, csv
import numpy as np
import pandas as pd

RUNS = "eos/runs"


def acc2(mean):
    return f"${mean:.3f}$"


def cifar_row():
    d = pd.read_csv(f"{RUNS}/adam_sls_summary.csv")
    d = d[d.lr == 0.001]
    out = {}
    for opt in ["adam", "adam_watchdog", "adam_tracker"]:
        r = d[d.opt == opt]
        if len(r) and r.div_rate.iloc[0] == 0:
            out[opt] = acc2(float(r.mean_acc.iloc[0]))
        elif len(r) and r.div_rate.iloc[0] == 1:
            out[opt] = "DIV.\\"
        else:
            out[opt] = f"{float(r.mean_acc.iloc[0]):.2f}\\,({r.div_rate.iloc[0]:.0%} div.)"
    return out


def agnews_row():
    out = {}
    for opt in ["adam", "adam_watchdog", "adam_tracker"]:
        accs, divs = [], []
        for d in sorted(glob.glob(f"{RUNS}/agnews_{opt}_lr0.001_seed*")):
            sj = os.path.join(d, "summary.json")
            if not os.path.exists(sj):
                continue
            s = json.load(open(sj)); divs.append(int(s["diverged"]))
            if not s["diverged"]:
                accs.append(s["test_acc"])
        n = len(divs)
        if n == 0:
            out[opt] = "--"
        elif sum(divs) == n:
            out[opt] = "DIV.\\"
        elif sum(divs) > 0:
            out[opt] = f"{np.mean(accs):.3f}\\,({sum(divs)}/{n} div.)"
        else:
            out[opt] = acc2(float(np.mean(accs)))
    return out


def xor_row():
    d = pd.read_csv(f"{RUNS}/xor_periodic.csv")
    van = d[(d.method == "vanilla")].pct.iloc[0]
    wd = d[(d.method == "watchdog")].pct.iloc[0]
    tr_rows = d[d.method == "tracker"]
    tr = tr_rows.pct.max(); tr_K = tr_rows.loc[tr_rows.pct.idxmax(), "K"]
    van_hi = d[d.method == "vanilla_hi"].pct
    van_hi = float(van_hi.iloc[0]) if len(van_hi) else None
    return van, wd, tr, tr_K, van_hi


def main():
    cif = cifar_row(); agn = agnews_row(); van, wd, tr, tr_K, van_hi = xor_row()
    body = [
        f"Smooth: CIFAR-10 / ResNet-18 (test acc) & {cif['adam']} & {cif['adam_watchdog']} & {cif['adam_tracker']} \\\\",
        f"Smooth: AG News / Transformer (test acc) & {agn['adam']} & {agn['adam_watchdog']} & {agn['adam_tracker']} \\\\",
        f"Plateau toy: $2$-$2$ XOR (\\% solved) & ${van:.0f}$ & ${wd:.0f}$ & ${tr:.0f}$ \\\\",
    ]
    print("=== LaTeX body (paste into tab:periodic) ===")
    print("Regime (default $\\eta = 10^{-3}$) & vanilla Adam & Watchdog & Tracker \\\\")
    print("\\midrule")
    for line in body:
        print(line)
    print(f"\n[note] XOR best Tracker K = {tr_K}; XOR fixed-higher-lr control "
          f"(eta=0.1) solved = {van_hi:.0f}%" if van_hi is not None else "")

    with open(f"{RUNS}/periodic_summary.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["regime", "vanilla", "watchdog", "tracker", "extra"])
        w.writerow(["cifar_resnet", cif["adam"], cif["adam_watchdog"], cif["adam_tracker"], ""])
        w.writerow(["agnews_tf", agn["adam"], agn["adam_watchdog"], agn["adam_tracker"], ""])
        w.writerow(["xor", f"{van:.0f}", f"{wd:.0f}", f"{tr:.0f}",
                    f"bestK={tr_K};vanilla_hi={van_hi}"])
    print(f"Saved {RUNS}/periodic_summary.csv")


if __name__ == "__main__":
    main()
