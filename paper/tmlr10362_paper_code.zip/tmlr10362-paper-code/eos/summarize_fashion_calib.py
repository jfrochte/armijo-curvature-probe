# eos/summarize_fashion_calib.py
#
# Reproduction artifact: prints the LaTeX body of Table \label{tab:fashion-rescue}
#   in armijo_curvature_probe.tex (uncalibrated kappa=0.25 vs calibrated block).
#   Data: run_new_baselines.sh.
#
# Aggregate the *calibrated* Fashion-MNIST sweep (kappa=0.005) for the 3
# controlled modes (init_only, watchdog, tracker), 6 lr, 5 seeds.
# Combine with the existing uncalibrated vanilla / clip / warmup results
# (kappa irrelevant for those) and produce a side-by-side table.

import os, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = "eos/runs"
LRS  = ["0.001", "0.01", "0.1", "0.3", "1.0", "3.0"]
SEEDS = [0, 1, 2, 3, 4]


def load(prefix, opt, lr):
    accs, divs, walls = [], [], []
    for sd in SEEDS:
        p = f"{ROOT}/{prefix}_{opt}_lr{lr}_seed{sd}/summary.json"
        if not os.path.exists(p):
            continue
        s = json.load(open(p))
        if s["diverged"]:
            divs.append(1); accs.append(0.0)
        else:
            divs.append(0); accs.append(s["test_acc"])
        walls.append(s["wall_s"])
    return dict(accs=accs, divs=divs, walls=walls)


def cell(prefix, opt, lr):
    r = load(prefix, opt, lr)
    n = len(r["accs"])
    if n == 0:
        return "--"
    div_count = sum(r["divs"])
    valid = [a for a, d in zip(r["accs"], r["divs"]) if d == 0]
    if div_count == n:
        return "DIV."
    elif valid and div_count > 0:
        m = float(np.mean(valid)); s = float(np.std(valid))
        return f"{m:.3f}\\,({div_count}/{n} div.)"
    else:
        m = float(np.mean(valid)); s = float(np.std(valid))
        # check for "stuck at random level"
        if abs(m - 0.10) < 0.005:
            return f"0.10$^*$"
        return f"${m:.3f} \\pm {s:.3f}$"


def cell_plain(prefix, opt, lr):
    """Plain-text cell for terminal."""
    r = load(prefix, opt, lr)
    n = len(r["accs"])
    if n == 0:
        return "--"
    div_count = sum(r["divs"])
    valid = [a for a, d in zip(r["accs"], r["divs"]) if d == 0]
    if div_count == n:
        return f"DIV ({n}/{n})"
    elif valid and div_count > 0:
        m = float(np.mean(valid))
        return f"{m:.3f} ({div_count}/{n} div)"
    else:
        m = float(np.mean(valid)); s = float(np.std(valid))
        return f"{m:.3f}+-{s:.3f}"


def print_terminal(opts_uncal, opts_cal):
    print(f"\n=== Uncalibrated (kappa=0.25) — same as before ===")
    print(f"{'Optimizer':<22} {'lr=0.001':<22} {'lr=0.01':<22} {'lr=0.1':<22} {'lr=0.3':<22} {'lr=1.0':<22} {'lr=3.0':<22}")
    for opt in opts_uncal:
        prefix = "fashion"
        cells = [cell_plain(prefix, opt, lr) for lr in LRS]
        print(f"{opt:<22} " + " ".join(f"{c:<22}" for c in cells))
    print(f"\n=== Calibrated (kappa=0.005) ===")
    print(f"{'Optimizer':<22} {'lr=0.001':<22} {'lr=0.01':<22} {'lr=0.1':<22} {'lr=0.3':<22} {'lr=1.0':<22} {'lr=3.0':<22}")
    for opt in opts_cal:
        prefix = "fashion_calib"
        cells = [cell_plain(prefix, opt, lr) for lr in LRS]
        print(f"{opt:<22} " + " ".join(f"{c:<22}" for c in cells))


def print_latex(opts_uncal, opts_cal):
    pretty = {
        "adam":           "Vanilla Adam",
        "adam_clip":      "Adam + grad-clip",
        "adam_warmup":    "Adam + warmup",
        "adam_init_only": "Adam-InitOnly",
        "adam_watchdog":  "Adam-Watchdog",
        "adam_tracker":   "Adam-Tracker",
    }
    print(r"\begin{tabular}{lcccccc}")
    print(r"\toprule")
    header = " & ".join(f"$\\eta={lr}$" for lr in LRS)
    print(f" & {header} \\\\")
    print(r"\midrule")
    print(r"\multicolumn{7}{l}{\textit{Uncalibrated, $\kappa = 0.25$ (CIFAR-10 default)}} \\")
    for opt in opts_uncal:
        cells = [cell("fashion", opt, lr) for lr in LRS]
        print(f"{pretty.get(opt, opt):<22} & {' & '.join(cells)} \\\\")
    print(r"\midrule")
    print(r"\multicolumn{7}{l}{\textit{Calibrated, $\kappa = 0.005$ (Fashion-MNIST/small CNN)}} \\")
    for opt in opts_cal:
        cells = [cell("fashion_calib", opt, lr) for lr in LRS]
        print(f"{pretty.get(opt, opt):<22} & {' & '.join(cells)} \\\\")
    print(r"\bottomrule")
    print(r"\end{tabular}")


if __name__ == "__main__":
    opts_uncal = ["adam", "adam_clip", "adam_warmup", "adam_watchdog", "adam_tracker"]
    opts_cal   = ["adam_init_only", "adam_watchdog", "adam_tracker"]
    print_terminal(opts_uncal, opts_cal)
    print()
    print_latex(opts_uncal, opts_cal)
