# eos/plot_headline_v2.py
#
# Reproduction artifact: produces runs/fig_rescue_headline.png (2x2 panels)
#   -> Figure \label{fig:rescue-headline} in armijo_curvature_probe.tex
# Top left:     CIFAR-10 rescue grid, all methods (as headline_plot.py) plus
#               the direction-matched probe at the fixed kappa=2.
# Top right:    Imagenette (real-resolution control), vanilla vs. dir-probe.
# Bottom left:  Fashion-MNIST, vanilla vs. calibrated raw probe vs. dir-probe.
# Bottom right: AG News, same three; the dir-probe's chance-level plateau for
#               eta >= 1e-2 makes the limit of the calibration-free recipe
#               visible (narrow stable range).
# Style inherited from eos/headline_plot.py; run from the repository root.

import os, json
import numpy as np
import matplotlib.pyplot as plt

ROOT = "eos/runs"
SEEDS = [0, 1, 2, 3, 4]
LRS = ["0.001", "0.01", "0.1", "0.3", "1.0", "3.0"]
LR_FLOAT = [float(x) for x in LRS]


def load(runkey, lr):
    """runkey is the full directory prefix before _lr, e.g.
    'cifar_adam' or 'fashion_calib_adam_init_only'."""
    accs, div_count = [], 0
    for sd in SEEDS:
        p = f"{ROOT}/{runkey}_lr{lr}_seed{sd}/summary.json"
        if not os.path.exists(p):
            continue
        s = json.load(open(p))
        if s["diverged"]:
            div_count += 1
            accs.append(0.0)
        else:
            accs.append(s["test_acc"])
    if not accs:
        return None
    return dict(mean=float(np.mean(accs)), std=float(np.std(accs)),
                div_count=div_count, n=len(accs))


CIFAR_CONFIG = [
    # runkey,                    label,                                     color, marker
    ("cifar_adam",               "Vanilla Adam",                            "C3",  "o"),
    ("cifar_adam_init_only",     "Adam-InitOnly (ours)",                    "C0",  "s"),
    ("cifar_adam_init_dir",      r"Adam-InitOnly (dir., $\kappa=2$, ours)", "C4",  "v"),
    ("cifar_adam_watchdog",      "Adam-Watchdog (ours)",                    "C9",  "P"),
    ("cifar_adam_tracker",       "Adam-Tracker (ours)",                     "C2",  "D"),
    ("cifar_adam_schedulefree",  "Schedule-Free AdamW",                     "C1",  "^"),
    ("cifar_prodigy",            "Prodigy",                                 "C6",  "*"),
]

INET_CONFIG = [
    ("imagenette_adam",          "Vanilla Adam",                            "C3", "o"),
    ("imagenette_adam_init_dir", r"Adam-InitOnly (dir., $\kappa=2$, ours)", "C4", "v"),
]

FASHION_CONFIG = [
    ("fashion_adam",                  "Vanilla Adam",                                  "C3", "o"),
    ("fashion_calib_adam_init_only",  r"Adam-InitOnly ($\kappa=0.005$ calib., ours)",  "C0", "s"),
    ("fashion_adam_init_dir",         r"Adam-InitOnly (dir., $\kappa=2$, ours)",       "C4", "v"),
]

AGNEWS_CONFIG = [
    ("agnews_adam",                 "Vanilla Adam",                                 "C3", "o"),
    ("agnews_calib_adam_init_only", r"Adam-InitOnly ($\kappa=0.05$ calib., ours)",  "C0", "s"),
    ("agnews_adam_init_dir",        r"Adam-InitOnly (dir., $\kappa=2$, ours)",      "C4", "v"),
]


def draw_panel(ax, config, chance, div_note=False):
    div_y = {}
    div_levels = [0.055, 0.025]
    for runkey, label, color, marker in config:
        means, stds, div_flags, lrs_used = [], [], [], []
        for lr_str, lr in zip(LRS, LR_FLOAT):
            r = load(runkey, lr_str)
            if r is None:
                continue
            lrs_used.append(lr)
            means.append(r["mean"])
            stds.append(r["std"])
            div_flags.append(r["div_count"] == r["n"])
        means = np.array(means); stds = np.array(stds)
        lrs_used = np.array(lrs_used); div_flags = np.array(div_flags)

        ok = ~div_flags
        if ok.any():
            ax.errorbar(lrs_used[ok], means[ok], yerr=stds[ok], fmt="-",
                        color=color, marker=marker, label=label, markersize=7,
                        linewidth=1.5, capsize=4)
        if div_flags.any():
            y = div_levels[len(div_y) % len(div_levels)]
            div_y[label] = (y, color)
            xd = lrs_used[div_flags]
            ax.scatter(xd, np.full(div_flags.sum(), y),
                       marker="x", color=color, s=100, linewidths=2.5, zorder=5)
            if ok.any():
                ax.plot([lrs_used[ok][-1], xd[0]], [means[ok][-1], y],
                        color=color, ls="--", lw=1.2, alpha=0.5, zorder=1)

    ax.set_xscale("log")
    ax.set_ylim(0.0, 0.98)
    ax.axhline(chance, color="gray", ls=":", alpha=0.6)
    ax.grid(True, which="both", alpha=0.2)
    if div_note:
        ax.text(0.0011, 0.035,
                r"$\times$ = training diverged (loss $\to\infty$ within 2 steps)",
                fontsize=8, color="dimgray", ha="left", va="center")


def main(out="eos/runs/fig_rescue_headline.png"):
    fig, axes = plt.subplots(2, 2, figsize=(12.5, 8.6), sharex=True)
    (axTL, axTR), (axBL, axBR) = axes

    draw_panel(axTL, CIFAR_CONFIG, chance=0.10, div_note=True)
    axTL.set_title(r"CIFAR-10 / ResNet-18 ($32\,$px, 10 epochs)")
    axTL.legend(loc="center left", fontsize=8)
    axTL.text(3.0, 0.125, "random guess (10%)", fontsize=8, color="gray", ha="right")

    draw_panel(axTR, INET_CONFIG, chance=0.10)
    axTR.set_title(r"Imagenette / standard ResNet-18 ($128\,$px, 20 epochs)")
    axTR.legend(loc="center left", fontsize=8)

    draw_panel(axBL, FASHION_CONFIG, chance=0.10)
    axBL.set_title("Fashion-MNIST / small CNN (10 epochs)")
    axBL.legend(loc="center left", fontsize=8)

    draw_panel(axBR, AGNEWS_CONFIG, chance=0.25)
    axBR.set_title("AG News / small Transformer (10 epochs)")
    axBR.legend(loc="center left", fontsize=8)
    axBR.text(3.0, 0.275, "random guess (25%)", fontsize=8, color="gray", ha="right")

    for ax in (axTL, axBL):
        ax.set_ylabel("Test accuracy")
    for ax in (axBL, axBR):
        ax.set_xlabel(r"Initial learning rate $\eta_{\rm init}$")

    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print(f"[plot] {out}")


if __name__ == "__main__":
    main()
