# eos/summarize_overhead.py
#
# Aggregate the controlled overhead benchmark written by run_overhead.sh and
# print the wall-clock overhead of each controller relative to vanilla Adam,
# for both the forward-only (FO) and forward+backward reference (FB)
# backtracking. Reproduces the numbers in the "Cost analysis" section of
# ./armijo_curvature_probe.tex.
#
# Usage: python -m eos.summarize_overhead runs/overhead_benchmark.csv

import csv, sys
from collections import defaultdict
from statistics import mean


def main(path):
    walls = defaultdict(list)
    accs = defaultdict(list)
    with open(path) as f:
        for r in csv.DictReader(f):
            key = (r["mode"], r["opt"])
            walls[key].append(float(r["wall_s"]))
            accs[key].append(float(r["test_acc"]))

    base = mean(walls[("FO", "adam")])
    print(f"vanilla Adam baseline: {base:.1f} s "
          f"(seeds: {[round(x, 1) for x in walls[('FO', 'adam')]]})\n")
    print(f"{'controller':<18}{'forward-only (deployed)':<28}{'forward+backward reference':<28}")
    for opt in ("adam_init_only", "adam_watchdog", "adam_tracker"):
        fo = mean(walls[("FO", opt)])
        cells = [f"{fo:.1f}s (+{100 * (fo / base - 1):.1f}%)"]
        if ("FB", opt) in walls:
            fb = mean(walls[("FB", opt)])
            cells.append(f"{fb:.1f}s (+{100 * (fb / base - 1):.1f}%)")
        else:
            cells.append("-")
        print(f"{opt:<18}{cells[0]:<28}{cells[1]:<28}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "runs/overhead_benchmark.csv")
