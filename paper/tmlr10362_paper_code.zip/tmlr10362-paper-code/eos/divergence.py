# eos/divergence.py
#
# Reproduction artifact: writes runs/divergence_*/divergence.json feeding the
#   divergence-boundary Table \label{tab:kappa} (Sec. 5.5) of
#   armijo_curvature_probe.tex. Note: the fine multiplier sweep that actually
#   populates that table is the heredoc in run_all.sh. Data: run_all.sh.
#
# Validate the practical claim of the EoS pivot: the line-search alpha from a
# short GGAO warmup predicts at which Adam learning rate the training diverges.
#
# Procedure:
#   1. Run GGAO for ~200 steps, record mean alpha (alpha_anchor).
#   2. Run Adam for `epochs` epochs at lr in {0.5, 1, 2, 5, 10, 20} * alpha_anchor.
#   3. Mark a run as "diverged" if loss > 5x initial or NaN at any point.
#   4. Plot final loss vs lr-multiple.

import os, sys, json, argparse, time
import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.optimizer import GGAO
from eos.data import (cifar_resnet18, make_cifar10_loaders,
                      DigitsMLP, make_digits_loaders)


def warmup_alpha(model_factory, train_loader, device, n_steps=200, seed=0):
    torch.manual_seed(seed); np.random.seed(seed)
    model = model_factory().to(device)
    optimizer = GGAO(model.parameters(), alpha_max=1.0, mode="gs+armijo", use_tanh=False)
    criterion = nn.CrossEntropyLoss()
    alphas = []
    it = iter(train_loader); step = 0
    while step < n_steps:
        try:
            Xb, yb = next(it)
        except StopIteration:
            it = iter(train_loader); Xb, yb = next(it)
        Xb = Xb.to(device); yb = yb.to(device)
        def closure():
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(Xb), yb); loss.backward(); return loss
        @torch.no_grad()
        def eval_loss():
            return criterion(model(Xb), yb).item()
        optimizer.step(closure, eval_loss)
        alphas.append(optimizer.last_alpha)
        step += 1
    return float(np.mean(alphas)), alphas


def run_adam(model_factory, train_loader, lr, epochs, device, seed=0,
             max_steps=None):
    torch.manual_seed(seed); np.random.seed(seed)
    model = model_factory().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()
    losses = []
    initial_loss = None
    diverged = False
    step = 0
    for ep in range(epochs):
        for Xb, yb in train_loader:
            Xb = Xb.to(device); yb = yb.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(Xb)
            loss = criterion(logits, yb)
            loss.backward()
            optimizer.step()
            l = float(loss.detach())
            losses.append(l)
            if initial_loss is None:
                initial_loss = l
            if not np.isfinite(l) or l > 5 * initial_loss:
                diverged = True
                return {"lr": lr, "diverged": True, "step_div": step,
                        "final_loss": l, "losses": losses}
            step += 1
            if max_steps and step >= max_steps:
                break
        if max_steps and step >= max_steps:
            break
    return {"lr": lr, "diverged": False, "step_div": -1,
            "final_loss": float(np.mean(losses[-50:])), "losses": losses}


def main(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.cuda.set_device(args.gpu)

    if args.dataset == "cifar10":
        train_loader, _ = make_cifar10_loaders(batch_size=args.batch_size,
                                               num_workers=args.num_workers,
                                               seed=args.seed)
        model_factory = lambda: cifar_resnet18(num_classes=10)
    else:
        train_loader, _ = make_digits_loaders(batch_size=args.batch_size, seed=args.seed)
        model_factory = lambda: DigitsMLP()

    print(f"[anchor] running {args.warmup_steps} GGAO warmup steps for alpha anchor",
          flush=True)
    alpha_anchor, alpha_log = warmup_alpha(model_factory, train_loader, device,
                                           n_steps=args.warmup_steps, seed=args.seed)
    print(f"[anchor] alpha_anchor = {alpha_anchor:.5f}", flush=True)

    multipliers = [0.5, 1.0, 2.0, 5.0, 10.0, 20.0]
    results = []
    for m in multipliers:
        lr = m * alpha_anchor
        print(f"[adam] m={m} lr={lr:.5f}", flush=True)
        t0 = time.time()
        r = run_adam(model_factory, train_loader, lr, args.adam_epochs, device,
                     seed=args.seed, max_steps=args.adam_max_steps)
        r["multiplier"] = m
        r["wall_s"] = time.time() - t0
        del r["losses"]   # keep summary small
        print(f"  -> diverged={r['diverged']} final_loss={r['final_loss']:.4f} "
              f"step_div={r['step_div']} wall={r['wall_s']:.1f}s", flush=True)
        results.append(r)

    out = {
        "dataset": args.dataset,
        "alpha_anchor": alpha_anchor,
        "warmup_steps": args.warmup_steps,
        "adam_epochs": args.adam_epochs,
        "results": results,
    }
    os.makedirs(args.outdir, exist_ok=True)
    with open(os.path.join(args.outdir, "divergence.json"), "w") as f:
        json.dump(out, f, indent=2)
    print(f"[done] saved {args.outdir}/divergence.json", flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", choices=["cifar10", "digits"], required=True)
    p.add_argument("--warmup-steps", type=int, default=200)
    p.add_argument("--adam-epochs", type=int, default=2)
    p.add_argument("--adam-max-steps", type=int, default=400)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--num-workers", type=int, default=2)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--gpu", type=int, default=0)
    p.add_argument("--outdir", required=True)
    args = p.parse_args()
    main(args)
