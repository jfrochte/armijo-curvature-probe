# eos/train.py
#
# Reproduction artifact: produces the mechanism runs (trace.csv with lambda_1,
#   dir_curv_q, alpha_probe) that feed Table \label{tab:correlation},
#   Figure \label{fig:scatter} and the Sec. 5.4 proposition test.
#   Drivers: run_mechanism_all.sh / run_mechanism_fashion.sh / run_all.sh.
#
# Main training loop with periodic Hessian probing for the Edge-of-Stability
# pivot. Logs (step, loss, mean_alpha_in_window, lambda_max, ||grad||) and
# writes one CSV row per probe.

import os, sys, json, time, argparse, csv
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, f1_score

# project imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.optimizer import GGAO
from eos.probe import HessianProbe
from eos.data import (cifar_resnet18, make_cifar10_loaders,
                      DigitsMLP, make_digits_loaders,
                      FashionCNN, make_fashion_mnist_loaders,
                      imagenette_resnet18, make_imagenette_loaders)


def fixed_probe_batch(loader, n=512):
    """Concatenates batches from `loader` until n samples are collected."""
    xs, ys = [], []
    total = 0
    for X, y in loader:
        xs.append(X); ys.append(y); total += X.size(0)
        if total >= n:
            break
    X = torch.cat(xs)[:n]; y = torch.cat(ys)[:n]
    return X, y


def make_optimizer(opt, params, lr):
    if opt == "ggao_gs_armijo":
        return GGAO(params, alpha_max=1.0, mode="gs+armijo", use_tanh=False)
    if opt == "ggao_gs_armijo_tanh":
        return GGAO(params, alpha_max=1.0, mode="gs+armijo", use_tanh=True)
    if opt == "ggao_armijo":
        return GGAO(params, alpha_max=1.0, mode="armijo", use_tanh=False)
    if opt == "ggao_fixed":
        return GGAO(params, alpha_max=lr, mode="fixed", use_tanh=False)
    if opt == "adam":
        return torch.optim.Adam(params, lr=lr)
    if opt == "adamw":
        return torch.optim.AdamW(params, lr=lr)
    if opt == "sgd":
        return torch.optim.SGD(params, lr=lr, momentum=0.9)
    raise ValueError(opt)


def evaluate(model, loader, device):
    model.eval()
    yt, yp = [], []
    with torch.no_grad():
        for X, y in loader:
            X = X.to(device, non_blocking=True)
            yp.extend(model(X).argmax(1).cpu().numpy())
            yt.extend(y.numpy())
    return accuracy_score(yt, yp), f1_score(yt, yp, average="macro")


def train(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(args.seed); np.random.seed(args.seed)

    # data + model
    if args.dataset == "cifar10":
        train_loader, test_loader = make_cifar10_loaders(
            batch_size=args.batch_size, num_workers=args.num_workers, seed=args.seed)
        model = cifar_resnet18(num_classes=10).to(device)
    elif args.dataset == "digits":
        train_loader, test_loader = make_digits_loaders(
            batch_size=args.batch_size, seed=args.seed)
        model = DigitsMLP(hidden=64, num_classes=10).to(device)
    elif args.dataset == "fashion_mnist":
        train_loader, test_loader = make_fashion_mnist_loaders(
            batch_size=args.batch_size, num_workers=args.num_workers, seed=args.seed)
        model = FashionCNN(num_classes=10).to(device)
    elif args.dataset == "imagenette":
        train_loader, test_loader = make_imagenette_loaders(
            batch_size=args.batch_size, num_workers=args.num_workers, seed=args.seed)
        model = imagenette_resnet18(num_classes=10).to(device)
    else:
        raise ValueError(args.dataset)

    criterion = nn.CrossEntropyLoss()
    optimizer = make_optimizer(args.optimizer, model.parameters(), lr=args.lr)
    is_ggao = args.optimizer.startswith("ggao") and args.optimizer != "ggao_fixed" or \
              args.optimizer == "ggao_fixed"

    # probe
    probe_X, probe_y = fixed_probe_batch(train_loader, n=args.probe_size)
    probe = HessianProbe(model, criterion, probe_X, probe_y,
                         top_n=args.top_n, device=device.type)

    # output dir + csv
    os.makedirs(args.outdir, exist_ok=True)
    csv_path = os.path.join(args.outdir, "trace.csv")
    json_path = os.path.join(args.outdir, "summary.json")
    csv_f = open(csv_path, "w", newline="")
    fieldnames = ["step", "epoch", "wall_s", "loss",
                  "mean_alpha_window", "alpha_last", "gnorm",
                  "lambda_1", "lambda_max_top_n", "trace_over_n", "dir_curv_q",
                  "alpha_probe"]
    writer = csv.DictWriter(csv_f, fieldnames=fieldnames)
    writer.writeheader()

    print(f"[run] dataset={args.dataset} opt={args.optimizer} "
          f"epochs={args.epochs} bs={args.batch_size} probe_every={args.probe_every} "
          f"seed={args.seed} outdir={args.outdir}", flush=True)

    t0 = time.time()
    step = 0
    alpha_window = []
    loss_window = []
    last_loss = float("nan")

    # initial probe (epoch 0)
    res = probe()
    q0, _ = probe.directional_curvature()
    a0 = probe.armijo_alpha()
    writer.writerow({
        "step": step, "epoch": 0, "wall_s": time.time() - t0,
        "loss": last_loss,
        "mean_alpha_window": float("nan"),
        "alpha_last": float("nan"),
        "gnorm": float("nan"),
        "lambda_1": res["eigenvalues"][0],
        "lambda_max_top_n": json.dumps(res["eigenvalues"]),
        "trace_over_n": res["trace_over_n"],
        "dir_curv_q": q0,
        "alpha_probe": a0,
    })
    csv_f.flush()
    print(f"[probe] step={step} lambda_1={res['eigenvalues'][0]:.3f}", flush=True)

    for ep in range(args.epochs):
        model.train()
        for Xb, yb in train_loader:
            Xb = Xb.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)

            def closure():
                optimizer.zero_grad(set_to_none=True)
                logits = model(Xb)
                loss = criterion(logits, yb)
                loss.backward()
                return loss

            if is_ggao:
                @torch.no_grad()
                def eval_loss():
                    return criterion(model(Xb), yb).item()
                loss_t = optimizer.step(closure, eval_loss)
                alpha_window.append(optimizer.last_alpha)
            else:
                loss_t = closure()
                optimizer.step()

            loss_val = float(loss_t.detach()) if torch.is_tensor(loss_t) else float(loss_t)
            last_loss = loss_val
            loss_window.append(loss_val)
            step += 1

            if step % args.probe_every == 0:
                res = probe()
                q_dir, _ = probe.directional_curvature()
                a_probe = probe.armijo_alpha()
                row = {
                    "step": step, "epoch": ep + 1, "wall_s": time.time() - t0,
                    "loss": float(np.mean(loss_window)) if loss_window else float("nan"),
                    "mean_alpha_window": float(np.mean(alpha_window)) if alpha_window else float("nan"),
                    "alpha_last": getattr(optimizer, "last_alpha", float("nan")),
                    "gnorm": getattr(optimizer, "last_gnorm", float("nan")),
                    "lambda_1": res["eigenvalues"][0],
                    "lambda_max_top_n": json.dumps(res["eigenvalues"]),
                    "trace_over_n": res["trace_over_n"],
                    "dir_curv_q": q_dir,
                    "alpha_probe": a_probe,
                }
                writer.writerow(row); csv_f.flush()
                print(f"[probe] step={step} ep={ep+1} loss={row['loss']:.4f} "
                      f"alpha_w={row['mean_alpha_window']:.4f} "
                      f"lam1={row['lambda_1']:.3f}", flush=True)
                alpha_window.clear(); loss_window.clear()

    # final eval
    acc, f1 = evaluate(model, test_loader, device)
    elapsed = time.time() - t0
    summary = {
        "dataset": args.dataset, "optimizer": args.optimizer,
        "epochs": args.epochs, "batch_size": args.batch_size,
        "probe_every": args.probe_every, "seed": args.seed, "lr": args.lr,
        "test_acc": acc, "test_f1": f1, "wall_s": elapsed,
    }
    with open(json_path, "w") as f:
        json.dump(summary, f, indent=2)
    csv_f.close()
    print(f"[done] acc={acc:.4f} f1={f1:.4f} wall={elapsed:.1f}s", flush=True)
    print(f"[done] csv={csv_path} summary={json_path}", flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", choices=["cifar10", "digits", "fashion_mnist", "imagenette"], required=True)
    p.add_argument("--optimizer", required=True,
                   choices=["ggao_gs_armijo", "ggao_gs_armijo_tanh",
                            "ggao_armijo", "ggao_fixed", "adam", "adamw", "sgd"])
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--probe-every", type=int, default=100)
    p.add_argument("--probe-size", type=int, default=512)
    p.add_argument("--top-n", type=int, default=1)
    p.add_argument("--lr", type=float, default=1e-2)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--outdir", required=True)
    p.add_argument("--gpu", type=int, default=0)
    args = p.parse_args()
    if torch.cuda.is_available():
        torch.cuda.set_device(args.gpu)
    train(args)
