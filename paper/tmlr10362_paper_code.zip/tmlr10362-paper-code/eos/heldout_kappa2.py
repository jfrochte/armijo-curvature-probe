# eos/heldout_kappa2.py
#
# Validation artifact: a held-out
# test of the fixed safety factor kappa=2. The nine-architecture suite was
# used to SELECT kappa=2 (Table kappa-universal-sweep), so it cannot also
# validate the transfer claim. The three architectures below were never part
# of any selection or tuning step in this project, and kappa is FIXED at 2
# before running -- no per-architecture adjustment of any kind:
#
#   vit_cifar        small ViT (patch 4, d=192, depth 6, dropout 0.1), CIFAR-10
#   gru_agnews       2-layer GRU classifier, AG News
#   mobilenetv2_cifar torchvision MobileNetV2 (stride-1 stem for 32x32), CIFAR-10
#
# Variants per architecture (identical to the suite):
#   vanilla                 Adam, no cap
#   adamprobe_k2            static init cap, direction-matched, kappa=2
#                           (init probe extends backtracking on saturation,
#                            max_iter=30 -- the deployed init reading)
#   adam_probation_k2       deployed protocol: init cap + probationary
#                           re-probes over the first 50 steps (K=8)
#
# Rates {1e-3, 0.1} x seeds {0,1,2}, training 3 epochs (CIFAR) / 600 steps
# (AG News) -- the suite's short protocol. Writes eos/runs/heldout_kappa2.csv.
#
# Usage: CUDA_VISIBLE_DEVICES=1 python -m eos.heldout_kappa2

import csv
import os
import sys
import time
import traceback

import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.data import make_cifar10_loaders, make_agnews_loaders
from eos.validate_kappa_universality import (armijo_cap, train, train_probation,
                                             dev, RUNS)

SMOKE = os.environ.get("SMOKE", "0") == "1"
SEEDS = 1 if SMOKE else 3


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


class ViTSmall(nn.Module):
    """Minimal ViT for 32x32: patch 4 -> 64 tokens + CLS, pre-norm encoder."""
    def __init__(self, num_classes=10, dim=192, depth=6, heads=3, patch=4):
        super().__init__()
        self.patch = nn.Conv2d(3, dim, patch, patch)
        self.cls = nn.Parameter(torch.zeros(1, 1, dim))
        self.pos = nn.Parameter(torch.zeros(1, (32 // patch) ** 2 + 1, dim))
        enc = nn.TransformerEncoderLayer(dim, heads, dim * 4, dropout=0.1,
                                         batch_first=True, norm_first=True)
        self.enc = nn.TransformerEncoder(enc, depth)
        self.norm = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, num_classes)
        nn.init.trunc_normal_(self.pos, std=0.02)
        nn.init.trunc_normal_(self.cls, std=0.02)

    def forward(self, x):
        t = self.patch(x).flatten(2).transpose(1, 2)
        t = torch.cat([self.cls.expand(x.size(0), -1, -1), t], 1) + self.pos
        return self.head(self.norm(self.enc(t)[:, 0]))


class GRUClf(nn.Module):
    """GRU counterpart of the suite's LSTMClf (recurrence without gates' cell
    state; never used anywhere in the paper's selection or tuning)."""
    def __init__(self, vocab, nc=4, d=128):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.gru = nn.GRU(d, d, num_layers=2, batch_first=True)
        self.head = nn.Linear(d, nc)

    def forward(self, x):
        o, _ = self.gru(self.emb(x))
        return self.head(o[:, -1])


def mobilenetv2_cifar(num_classes=10):
    from torchvision.models import mobilenet_v2
    m = mobilenet_v2(weights=None, num_classes=num_classes)
    # 32x32 adaptation: stride-1 stem so the resolution is not destroyed.
    m.features[0][0].stride = (1, 1)
    return m


def main():
    cif_tl, cif_te = make_cifar10_loaders(batch_size=256, num_workers=3, seed=0)
    ag_tl, ag_te, vocab = make_agnews_loaders(batch_size=256, num_workers=2, seed=0)
    crit = nn.CrossEntropyLoss()
    ep = 1 if SMOKE else 3
    tsteps = 100 if SMOKE else 600
    kappa = 2.0

    archs = [
        ("vit_cifar", lambda: ViTSmall(), cif_tl, cif_te, dict(epochs=ep)),
        ("gru_agnews", lambda: GRUClf(vocab), ag_tl, ag_te, dict(steps=tsteps)),
        ("mobilenetv2_cifar", lambda: mobilenetv2_cifar(), cif_tl, cif_te,
         dict(epochs=ep)),
    ]
    variants = ["vanilla", "adamprobe_k2", "adam_probation_k2"]
    etas = [1e-3, 0.1]

    out = os.path.join(RUNS, "heldout_kappa2.csv")
    log(f"HELDOUT START (SMOKE={SMOKE}) -> {out}")
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["arch", "variant", "eta", "seed",
                                          "capped_lr", "alpha_bar", "diverged",
                                          "test_acc"])
        w.writeheader()
        for arch, mf, tl, te, tk in archs:
            Xb, Yb = next(iter(tl))
            Xb, Yb = Xb.to(dev), Yb.to(dev)
            for label in variants:
                for eta in etas:
                    for sd in range(SEEDS):
                        try:
                            torch.manual_seed(sd)
                            model = mf().to(dev)
                            if label == "vanilla":
                                clr, ab = eta, float("nan")
                                acc, div = train(model, tl, te, clr, **tk)
                            elif label == "adamprobe_k2":
                                clr, ab = armijo_cap(model, crit, Xb, Yb, eta,
                                                     kappa, "adam", max_iter=30)
                                acc, div = train(model, tl, te, clr, **tk)
                            else:  # deployed protocol
                                clr, ab = armijo_cap(model, crit, Xb, Yb, eta,
                                                     kappa, "adam", max_iter=30)
                                acc, div, clr = train_probation(
                                    model, tl, te, clr, kappa, Xb, Yb, crit, **tk)
                            w.writerow(dict(arch=arch, variant=label, eta=eta,
                                            seed=sd, capped_lr=round(clr, 7),
                                            alpha_bar=round(ab, 7) if ab == ab else "",
                                            diverged=int(div),
                                            test_acc=round(acc, 4) if acc == acc else ""))
                            f.flush()
                            log(f"{arch} {label} eta={eta} s{sd}: "
                                f"clr={clr:.5g} div={int(div)} acc={acc}")
                        except Exception:
                            log(f"!!! {arch} {label} eta={eta} s{sd} FAILED:\n"
                                f"{traceback.format_exc()}")
    log("HELDOUT DONE")


if __name__ == "__main__":
    main()
