# eos/detrend_correlation.py
#
# Reproduction artifact: prints the LaTeX rows of Table \label{tab:correlation-detrended}
#   in armijo_curvature_probe.tex.
#
# Motivation: the raw log-log Pearson between the
# line-search step alpha and lambda_1 could be inflated by a shared time trend
# (both drift over training). This script removes the trend two ways and
# reports per-run significance:
#   (a) linear detrend: regress log(alpha) and log(lambda_1) each on the step
#       index, correlate the residuals (= partial correlation given time),
#       p-value with dof reduced by the trend fit (n - 3);
#   (b) first differences: Pearson on (delta log alpha, delta log lambda_1),
#       immune to any monotone shared drift.
# Per architecture we aggregate over seeds (mean +/- std) and combine the
# per-run p-values with Fisher's method.
#
# Usage: python -m eos.detrend_correlation <prefix> <seed0> <seed1> ...
#   e.g. python -m eos.detrend_correlation eos/runs/fashion_ggao_armijo_seed 0 1 2
# Row selection mirrors eos/summarize_mechanism.py / freeze_paper_data.py.

import os, sys, json
import numpy as np
import pandas as pd
from scipy import stats


def load_pairs(run_dir):
    """Same filter as analyze.py::compute_correlations."""
    df = pd.read_csv(os.path.join(run_dir, "trace.csv"))
    sub = df.dropna(subset=["mean_alpha_window", "lambda_1"])
    sub = sub[(sub["mean_alpha_window"] > 0) & (sub["lambda_1"] > 0)]
    return (sub["step"].values.astype(float),
            np.log(sub["mean_alpha_window"].values),
            np.log(sub["lambda_1"].values))


def _pearson_p(r, dof):
    """Two-sided p for a Pearson r with the given residual dof (t-test)."""
    if dof <= 0 or abs(r) >= 1.0:
        return float("nan")
    t = r * np.sqrt(dof / (1.0 - r * r))
    return float(2.0 * stats.t.sf(abs(t), dof))


def detrended_stats(step, la, ll):
    """Residual correlation after removing a linear-in-step trend from both."""
    n = len(la)
    if n < 5:
        return None
    res_a = la - np.polyval(np.polyfit(step, la, 1), step)
    res_l = ll - np.polyval(np.polyfit(step, ll, 1), step)
    r = float(np.corrcoef(res_a, res_l)[0, 1])
    # dof: n - 2 (correlation) - 1 (linear trend removed from each series)
    return {"r": r, "p": _pearson_p(r, n - 3), "n": n}


def firstdiff_stats(la, ll):
    """Pearson on first differences of the log series."""
    da, dl = np.diff(la), np.diff(ll)
    n = len(da)
    if n < 4:
        return None
    r, p = stats.pearsonr(da, dl)
    return {"r": float(r), "p": float(p), "n": n}


def analyze_run(run_dir):
    step, la, ll = load_pairs(run_dir)
    raw_r, raw_p = stats.pearsonr(la, ll) if len(la) >= 4 else (float("nan"),) * 2
    out = {
        "run": run_dir,
        "n": int(len(la)),
        "raw": {"r": float(raw_r), "p": float(raw_p)},
        "detrended": detrended_stats(step, la, ll),
        "firstdiff": firstdiff_stats(la, ll),
    }
    return out


def fisher(ps):
    # p == 0.0 (numerical underflow of an extreme correlation) must be CLIPPED,
    # not dropped: dropping it removes the strongest evidence and inflates the
    # combined p. Clip to the smallest positive double instead.
    ps = [max(p, np.finfo(float).tiny) for p in ps if np.isfinite(p)]
    if not ps:
        return float("nan")
    chi2 = -2.0 * np.sum(np.log(ps))
    return float(stats.chi2.sf(chi2, 2 * len(ps)))


def _pstr(p):
    """Decade-threshold formatting, mirrors summarize_mechanism.py."""
    if not np.isfinite(p):
        return "--"
    if p <= 0 or p < 1e-12:
        return "< 10^{-12}"
    if p < 1e-3:
        return f"< 10^{{-{int(np.floor(-np.log10(p)))}}}"
    return f"{p:.3f}"


def main(prefix, seeds):
    per_run = []
    for sd in seeds:
        d = f"{prefix}{sd}"
        if not os.path.isdir(d):
            print(f"[skip] {d} missing")
            continue
        per_run.append(analyze_run(d))
    per_run = [r for r in per_run if r["detrended"] and r["firstdiff"]]
    if not per_run:
        print("no data")
        return

    raw = [r["raw"]["r"] for r in per_run]
    det = [r["detrended"]["r"] for r in per_run]
    dif = [r["firstdiff"]["r"] for r in per_run]
    det_p = [r["detrended"]["p"] for r in per_run]
    dif_p = [r["firstdiff"]["p"] for r in per_run]
    ns = [r["n"] for r in per_run]

    k = len(per_run)
    print(f"\n=== detrended mechanism summary ({k} seeds) for {prefix}* ===")
    for r in per_run:
        print(f"  {os.path.basename(r['run'])}: n={r['n']}  raw r={r['raw']['r']:+.3f}"
              f"  detrended r={r['detrended']['r']:+.3f} (p={r['detrended']['p']:.2e})"
              f"  first-diff r={r['firstdiff']['r']:+.3f} (p={r['firstdiff']['p']:.2e})")
    print(f"  raw        : {np.mean(raw):+.3f} +/- {np.std(raw):.3f}")
    print(f"  detrended  : {np.mean(det):+.3f} +/- {np.std(det):.3f}  Fisher p = {fisher(det_p):.2e}")
    print(f"  first-diff : {np.mean(dif):+.3f} +/- {np.std(dif):.3f}  Fisher p = {fisher(dif_p):.2e}")

    print("\n  LaTeX row (Variant & n & raw & detrended & p_F & first-diff & p_F):")
    print(f"  & {int(np.mean(ns))} & ${np.mean(raw):.3f} \\pm {np.std(raw):.3f}$"
          f" & ${np.mean(det):.3f} \\pm {np.std(det):.3f}$ & ${_pstr(fisher(det_p))}$"
          f" & ${np.mean(dif):.3f} \\pm {np.std(dif):.3f}$ & ${_pstr(fisher(dif_p))}$ \\\\")


if __name__ == "__main__":
    main(sys.argv[1], [int(s) for s in sys.argv[2:]])
