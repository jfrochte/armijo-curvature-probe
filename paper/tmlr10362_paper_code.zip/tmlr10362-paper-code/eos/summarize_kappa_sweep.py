"""eos/summarize_kappa_sweep.py

Reproduction artifact: prints the LaTeX body of Table \\label{tab:kappa-universal-sweep}
  and writes runs/kappa_sweep_summary.csv.
  Data: run_kappa_sweep.py (kappa in {1,2}) + the kappa=3 adam-probe column of
  validate_kappa_universality.py (runs/kappa_universality.csv).

Sweeps the safety factor of the Adam-direction probe to find a value with ZERO
divergences across the nine architectures. For each kappa: divergent runs at the
default and 100x-too-large rate (of 27 each, 54 total) and mean test accuracy
(divergent run counted as 0).
"""
import os, csv
import numpy as np
import pandas as pd

RUNS = "eos/runs"


def block(d):
    """d: rows for one kappa with columns eta, diverged, test_acc."""
    out = {}
    for eta in [0.001, 0.1]:
        s = d[np.isclose(d.eta, eta)]
        div = int(s.diverged.sum())
        acc = float(np.where(s.diverged == 1, 0.0, s.test_acc).mean())
        out[eta] = (div, len(s), round(acc, 3))
    tot = int(d.diverged.sum())
    return out, tot, len(d)


def main():
    sweep = pd.read_csv(f"{RUNS}/kappa_sweep_adamdir.csv")
    uni = pd.read_csv(f"{RUNS}/kappa_universality.csv")
    k3 = uni[uni.variant == "adamprobe_k3"][["eta", "diverged", "test_acc"]].copy()
    k3["kappa"] = 3.0

    kappas = sorted(set(sweep.kappa.unique()) | {3.0})
    by_k = {}
    for k in kappas:
        d = sweep[np.isclose(sweep.kappa, k)] if k != 3.0 else k3
        by_k[k] = block(d[["eta", "diverged", "test_acc"]])

    rows = []
    print("=== LaTeX body (paste into tab:kappa-universal-sweep) ===")
    hdr = " & ".join(f"$\\kappa={k:g}$" for k in kappas)
    print(f"Adam-direction probe & {hdr} \\\\")
    print("\\midrule")
    # divergence rows
    line_def = "divergences at default $10^{-3}$ (of 27)"
    line_big = "divergences at $100\\times$ (of 27)"
    line_tot = "total divergences (of 54)"
    acc_def = "mean acc at default $10^{-3}$"
    acc_big = "mean acc at $100\\times$"
    for k in kappas:
        (o, tot, n) = by_k[k]
        line_def += f" & {o[0.001][0]}"
        line_big += f" & {o[0.1][0]}"
        line_tot += f" & {tot}"
        acc_def += f" & {o[0.001][2]:.3f}"
        acc_big += f" & {o[0.1][2]:.3f}"
        rows.append(dict(kappa=k, div_default=o[0.001][0], div_100x=o[0.1][0],
                         div_total=tot, acc_default=o[0.001][2], acc_100x=o[0.1][2]))
    for ln in [line_def, line_big, line_tot]:
        print(ln + " \\\\")
    print("\\midrule")
    for ln in [acc_def, acc_big]:
        print(ln + " \\\\")

    with open(f"{RUNS}/kappa_sweep_summary.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["kappa", "div_default", "div_100x",
                                          "div_total", "acc_default", "acc_100x"])
        w.writeheader()
        for r in rows:
            w.writerow(r)
    zero = [k for k in kappas if by_k[k][1] == 0]
    print(f"\n[note] kappa with 0 total divergences: {zero or 'none'}")
    print(f"Saved {RUNS}/kappa_sweep_summary.csv")


if __name__ == "__main__":
    main()
