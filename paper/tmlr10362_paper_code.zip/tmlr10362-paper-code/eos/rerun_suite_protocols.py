# eos/rerun_suite_protocols.py
#
# Validation artifact. Two purposes in one
# sweep over the identical nine-architecture suite (build_suite), with the
# HARDENED probe (probe_state_guard) and full per-run records (returned
# alpha, backtracks, Armijo acceptance vs saturation, requested and
# effective learning rate, whether the cap bound, divergence, accuracy):
#
#   Protocol B ("k8_static", "k8_probation") -- run FIRST, it answers the
#     open question: init probe capped strictly at Algorithm 1's K=8
#     ("keep last candidate" saturation), kappa=2, once static and once
#     with the probationary window (the deployed protocol). Shows whether
#     the suite's extend-on-saturation init reading was necessary (expected:
#     the ultra-sharp normalisation-free nets saturate at beta^8, so the
#     static K=8 cap lands ~2 decades above their true reading) and whether
#     the unified deployed protocol restores the conclusion.
#
#   Protocol A ("extend30" for all three published variants) -- replication
#     of the published Tables (universal-kappa / kappa-universal-sweep /
#     kappa-perarch protocol) under the hardened probe, providing the
#     requested per-run records for the published numbers.
#
# Writes eos/runs/rerun_suite_protocols.csv (append + resume on restart).
#
# Usage: CUDA_VISIBLE_DEVICES=1 python -m eos.rerun_suite_protocols

import csv
import os
import sys
import time
import traceback

import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.validate_kappa_universality import (armijo_cap, build_suite, train,
                                             train_probation, dev, RUNS, SMOKE)

SEEDS = 1 if SMOKE else 3


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


# (protocol, variant label, probe mode, kappa, init max_iter, probation?)
# NOTE: the first launch of this script still ran with the
# suite's 8x divergence criterion; those rows are archived as
# rerun_suite_protocols_8xcriterion.csv. The criterion is now unified to the
# paper's 5x (eos/divergence.py convention) and everything below reruns
# under it, including Protocol C = the deployed recommendation, so that the
# published probation claim is also re-established under 5x.
JOBS = [
    # --- Protocol B first: the open question -------------------------------
    ("B", "k8_static_k2", "adam", 2.0, 8, False),
    ("B", "k8_probation_k2", "adam", 2.0, 8, True),
    # --- Protocol C: deployed recommendation (extend init + probation) -----
    ("C", "extend_probation_k2", "adam", 2.0, 30, True),
    # --- Protocol A: replication of the published protocol -----------------
    ("A", "vanilla", None, None, None, False),
    ("A", "gradprobe_k0.25", "grad", 0.25, 30, False),
    ("A", "adamprobe_k3", "adam", 3.0, 30, False),
]


def main():
    crit = nn.CrossEntropyLoss()
    ep = 1 if SMOKE else 3
    tsteps = 100 if SMOKE else 600
    archs = build_suite(ep, tsteps)
    etas = [1e-3] if SMOKE else [1e-3, 0.1]

    path = os.path.join(RUNS, "rerun_suite_protocols.csv")
    new = not os.path.exists(path)
    f = open(path, "a", newline="")
    fields = ["protocol", "arch", "variant", "eta", "seed", "requested_lr",
              "effective_lr", "alpha_bar", "backtracks", "accepted",
              "cap_bound", "diverged", "test_acc"]
    w = csv.DictWriter(f, fieldnames=fields)
    if new:
        w.writeheader()
        f.flush()
    seen = set() if new else {(r["protocol"], r["arch"], r["variant"],
                               r["eta"], r["seed"])
                              for r in csv.DictReader(open(path))}
    log(f"RERUN START (SMOKE={SMOKE}), {len(seen)} rows already present")

    for proto, label, mode, kappa, k_init, probation in JOBS:
        for arch, mf, tl, te, tk in archs:
            for X, Y in tl:
                Xb, Yb = X[:256].to(dev), Y[:256].to(dev)
                break
            for eta in etas:
                for sd in range(SEEDS):
                    key = (proto, arch, label, str(eta), str(sd))
                    if key in seen:
                        continue
                    try:
                        torch.manual_seed(sd)
                        model = mf().to(dev)
                        det = {"backtracks": "", "accepted": "",
                               "cap_bound": ""}
                        if mode is None:
                            clr, ab = eta, float("nan")
                            acc, div = train(model, tl, te, clr, **tk)
                        else:
                            clr, ab, det = armijo_cap(
                                model, crit, Xb, Yb, eta, kappa, mode,
                                max_iter=k_init, return_details=True)
                            if probation:
                                acc, div, clr = train_probation(
                                    model, tl, te, clr, kappa, Xb, Yb, crit,
                                    **tk)
                            else:
                                acc, div = train(model, tl, te, clr, **tk)
                        w.writerow(dict(
                            protocol=proto, arch=arch, variant=label, eta=eta,
                            seed=sd, requested_lr=eta,
                            effective_lr=round(clr, 7),
                            alpha_bar=round(ab, 7) if ab == ab else "",
                            backtracks=det["backtracks"],
                            accepted=det["accepted"],
                            cap_bound=det["cap_bound"], diverged=int(div),
                            test_acc=round(acc, 4) if acc == acc else ""))
                        f.flush()
                        log(f"[{proto}] {arch} {label} eta={eta} s{sd}: "
                            f"lr={clr:.5g} div={int(div)} acc={acc}")
                    except Exception:
                        log(f"!!! [{proto}] {arch} {label} eta={eta} s{sd} "
                            f"FAILED:\n{traceback.format_exc()}")
    log("RERUN DONE")


if __name__ == "__main__":
    main()
