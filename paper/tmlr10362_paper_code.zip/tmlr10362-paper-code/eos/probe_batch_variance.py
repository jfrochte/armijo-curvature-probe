# eos/probe_batch_variance.py
#
# Reproduction artifact: prints the LaTeX rows of Table \label{tab:probe-variance}
#   in armijo_curvature_probe.tex and writes eos/runs/probe_batch_variance.csv.
#
# Motivation: the init probe reads alpha on a
# single mini-batch; how noisy is that reading across batches? For each
# benchmark and init seed we rebuild the model exactly as train_adam_sls.py
# does, then run the Armijo probe on K different training batches at the
# frozen initialisation, for both variants (raw gradient d = -g and
# Adam-direction d = -g/(|g|+eps)), with the deployed constants
# (c = 1e-4, beta = 0.5, alpha_max = 1, max backtracks 8). The model stays in
# train mode, as in deployment, so the reading includes all run-time noise
# sources (batch composition, dropout in the AG News transformer).
#
# Because alpha is quantised to powers of beta, we report the spread in
# backtracking rungs: median alpha, the log_{1/beta} range across batches,
# and the fraction of batches within one rung of the median. The implied cap
# kappa*alpha inherits exactly this multiplicative spread.
#
# Usage: python -m eos.probe_batch_variance [--batches 50] [--seeds 0 1 2]
#          [--datasets cifar10 fashion_mnist agnews imagenette] [--gpu 0]

import os, sys, argparse, itertools
import numpy as np
import pandas as pd
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.data import (cifar_resnet18, make_cifar10_loaders,
                      FashionCNN, make_fashion_mnist_loaders,
                      AGNewsTransformer, make_agnews_loaders,
                      imagenette_resnet18, make_imagenette_loaders)

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
LABELS = {"cifar10": "CIFAR-10/ResNet-18", "fashion_mnist": "Fashion-MNIST/CNN",
          "agnews": "AG News/Transformer", "imagenette": "Imagenette/ResNet-18"}
C, BETA, ALPHA_MAX, MAX_ITER, EPS = 1e-4, 0.5, 1.0, 8, 1e-8


def build(dataset, seed, batch_size, num_workers):
    """Model + train loader exactly as train_adam_sls.py::train builds them."""
    torch.manual_seed(seed)
    np.random.seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if dataset == "cifar10":
        loader, _ = make_cifar10_loaders(batch_size=batch_size,
                                         num_workers=num_workers, seed=seed)
        model = cifar_resnet18(num_classes=10).to(device)
    elif dataset == "fashion_mnist":
        loader, _ = make_fashion_mnist_loaders(batch_size=batch_size,
                                               num_workers=num_workers, seed=seed)
        model = FashionCNN(num_classes=10).to(device)
    elif dataset == "agnews":
        loader, _, vocab_eff = make_agnews_loaders(batch_size=batch_size,
                                                   num_workers=num_workers, seed=seed)
        model = AGNewsTransformer(vocab_eff, num_classes=4, num_layers=4).to(device)
    elif dataset == "imagenette":
        loader, _ = make_imagenette_loaders(batch_size=batch_size,
                                            num_workers=num_workers, seed=seed)
        model = imagenette_resnet18(num_classes=10).to(device)
    else:
        raise ValueError(dataset)
    return model, loader, device


def armijo_alpha(model, criterion, xb, yb, direction):
    """One Armijo probe at the current params, mirroring
    adam_sls.py::_probe_at_current_params (train mode, params restored)."""
    params = [p for p in model.parameters() if p.requires_grad]
    x0 = [p.detach().clone() for p in params]
    model.zero_grad(set_to_none=True)
    loss0 = criterion(model(xb), yb)
    loss0.backward()
    grads = [p.grad.detach().clone() if p.grad is not None else torch.zeros_like(p)
             for p in params]
    if direction == "adam":
        d = [-g / (g.abs() + EPS) for g in grads]
    else:
        d = [-g for g in grads]
    gd = sum((g * di).sum().item() for g, di in zip(grads, d))
    L0 = float(loss0.item())

    def f(alpha):
        with torch.no_grad():
            for p, x, dp in zip(params, x0, d):
                p.data.copy_(x + alpha * dp)
            return float(criterion(model(xb), yb).item())

    alpha = ALPHA_MAX
    for _ in range(MAX_ITER):
        if f(alpha) <= L0 + C * alpha * gd:
            break
        alpha *= BETA
    with torch.no_grad():
        for p, x in zip(params, x0):
            p.data.copy_(x)
    model.zero_grad(set_to_none=True)
    return alpha


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+",
                    default=["cifar10", "fashion_mnist", "agnews", "imagenette"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--batches", type=int, default=50)
    ap.add_argument("--batch-size", type=int, default=256)
    ap.add_argument("--num-workers", type=int, default=2)
    ap.add_argument("--gpu", type=int, default=0)
    args = ap.parse_args()
    if torch.cuda.is_available():
        torch.cuda.set_device(args.gpu)
    criterion = nn.CrossEntropyLoss()

    rows = []
    for ds in args.datasets:
        for seed in args.seeds:
            model, loader, device = build(ds, seed, args.batch_size,
                                          args.num_workers)
            model.train()
            batches = list(itertools.islice(iter(loader), args.batches))
            for direction in ["grad", "adam"]:
                alphas = []
                for xb, yb in batches:
                    xb, yb = xb.to(device), yb.to(device)
                    alphas.append(armijo_alpha(model, criterion, xb, yb,
                                               direction))
                a = np.array(alphas)
                rung = np.log(a) / np.log(BETA)          # 0, 1, 2, ... rungs
                med_rung = np.median(rung)
                rows.append({
                    "dataset": ds, "seed": seed, "direction": direction,
                    "n_batches": len(a), "alpha_median": float(np.median(a)),
                    "alpha_min": float(a.min()), "alpha_max": float(a.max()),
                    "rung_range": float(rung.max() - rung.min()),
                    "frac_within_1rung": float(np.mean(np.abs(rung - med_rung) <= 1.0)),
                })
                r = rows[-1]
                print(f"[{ds} seed={seed} {direction}] median={r['alpha_median']:.4g} "
                      f"min={r['alpha_min']:.4g} max={r['alpha_max']:.4g} "
                      f"rungs={r['rung_range']:.0f} within1={r['frac_within_1rung']:.2f}",
                      flush=True)
            del model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    df = pd.DataFrame(rows)
    out = os.path.join(RUNS, "probe_batch_variance.csv")
    df.to_csv(out, index=False)
    print(f"[written] {out}")

    print("\n  LaTeX rows (Benchmark & variant & median alpha & min & max"
          " & rung span & share within 1 rung):")
    for ds in args.datasets:
        for direction, dl in [("grad", "raw gradient"), ("adam", "Adam-direction")]:
            s = df[(df.dataset == ds) & (df.direction == direction)]
            if not len(s):
                continue
            print(f"  {LABELS[ds]} & {dl}"
                  f" & ${s.alpha_median.median():.3g}$"
                  f" & ${s.alpha_min.min():.3g}$ & ${s.alpha_max.max():.3g}$"
                  f" & ${s.rung_range.max():.0f}$"
                  f" & ${100 * s.frac_within_1rung.mean():.0f}\\%$ \\\\")


if __name__ == "__main__":
    main()
