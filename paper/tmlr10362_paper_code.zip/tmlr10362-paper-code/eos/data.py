# eos/data.py
#
# Dataset loaders + models for all four domains:
#   CIFAR-10 (ResNet-18), Digits (MLP), Fashion-MNIST (CNN),
#   AG News (small word-level Transformer; needs the `datasets` package and
#   the HuggingFace repo fancyzhx/ag_news on first use, then a local cache).
# CIFAR-10 expects a pre-downloaded data/ folder (download=False); the other
# datasets fetch/build themselves. Use `python -m eos.setup_data` to populate
# data/ when it was not shipped. DATA_ROOT below must stay a sibling of eos/.

import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from torchvision.datasets import CIFAR10, FashionMNIST
from torchvision import transforms
from torchvision.models import resnet18
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split


# Same path the previous CIFAR scripts used (already extracted by tar).
DATA_ROOT = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")


def cifar_resnet18(num_classes=10, norm=True):
    """CIFAR-adapted ResNet-18. With norm=False every BatchNorm2d is replaced by
    Identity, giving the normalisation-free network used in tab:default-unsafe
    (the regime where the framework-default lr is itself unsafe)."""
    m = resnet18(weights=None, num_classes=num_classes)
    m.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    m.maxpool = nn.Identity()
    if not norm:
        for name, module in m.named_modules():
            for child_name, child in module.named_children():
                if isinstance(child, nn.BatchNorm2d):
                    setattr(module, child_name, nn.Identity())
    return m


def make_cifar10_loaders(batch_size=256, num_workers=4, seed=0):
    mean = (0.4914, 0.4822, 0.4465)
    std  = (0.2470, 0.2435, 0.2616)
    train_tf = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    test_tf = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    train_ds = CIFAR10(DATA_ROOT, train=True,  download=False, transform=train_tf)
    test_ds  = CIFAR10(DATA_ROOT, train=False, download=False, transform=test_tf)
    g = torch.Generator(); g.manual_seed(seed)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                              num_workers=num_workers, pin_memory=True,
                              persistent_workers=num_workers > 0, generator=g)
    test_loader  = DataLoader(test_ds,  batch_size=batch_size, shuffle=False,
                              num_workers=num_workers, pin_memory=True,
                              persistent_workers=num_workers > 0)
    return train_loader, test_loader


def imagenette_resnet18(num_classes=10):
    """Standard (full-stem) ResNet-18 for Imagenette at 128px: 7x7 stride-2
    conv + max-pool, i.e. the unmodified torchvision architecture. This is
    deliberately NOT the CIFAR adaptation: Imagenette serves as the
    real-resolution control, so the network keeps its ImageNet stem."""
    return resnet18(weights=None, num_classes=num_classes)


def make_imagenette_loaders(batch_size=256, num_workers=4, seed=0):
    """Imagenette v2 (fastai), 160px variant, trained/evaluated at 128px.
    Expects data/imagenette2-160/{train,val} as extracted from
    https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-160.tgz"""
    from torchvision.datasets import ImageFolder
    mean = (0.485, 0.456, 0.406)   # ImageNet statistics
    std  = (0.229, 0.224, 0.225)
    train_tf = transforms.Compose([
        transforms.RandomResizedCrop(128, scale=(0.35, 1.0)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    test_tf = transforms.Compose([
        transforms.Resize(160),
        transforms.CenterCrop(128),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    root = os.path.join(DATA_ROOT, "imagenette2-160")
    train_ds = ImageFolder(os.path.join(root, "train"), transform=train_tf)
    test_ds  = ImageFolder(os.path.join(root, "val"),   transform=test_tf)
    g = torch.Generator(); g.manual_seed(seed)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                              num_workers=num_workers, pin_memory=True,
                              persistent_workers=num_workers > 0, generator=g)
    test_loader  = DataLoader(test_ds,  batch_size=batch_size, shuffle=False,
                              num_workers=num_workers, pin_memory=True,
                              persistent_workers=num_workers > 0)
    return train_loader, test_loader


class DigitsMLP(nn.Module):
    def __init__(self, hidden=64, num_classes=10):
        super().__init__()
        self.fc1 = nn.Linear(64, hidden)
        self.fc2 = nn.Linear(hidden, num_classes)

    def forward(self, x):
        return self.fc2(F.relu(self.fc1(x)))


class FashionCNN(nn.Module):
    """Small 2-conv 2-FC CNN for Fashion-MNIST (28x28 grayscale)."""
    def __init__(self, num_classes=10):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.flatten(1)
        x = F.relu(self.fc1(x))
        return self.fc2(x)


def make_fashion_mnist_loaders(batch_size=128, num_workers=4, seed=0):
    mean, std = (0.2860,), (0.3530,)
    train_tf = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    test_tf = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    train_ds = FashionMNIST(DATA_ROOT, train=True,  download=True, transform=train_tf)
    test_ds  = FashionMNIST(DATA_ROOT, train=False, download=True, transform=test_tf)
    g = torch.Generator(); g.manual_seed(seed)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                              num_workers=num_workers, pin_memory=True,
                              persistent_workers=num_workers > 0, generator=g)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False,
                             num_workers=num_workers, pin_memory=True,
                             persistent_workers=num_workers > 0)
    return train_loader, test_loader


def make_digits_loaders(batch_size=128, seed=42):
    digits = load_digits()
    X = digits.data / 16.0
    y = digits.target
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=seed)
    train_ds = TensorDataset(torch.tensor(X_train, dtype=torch.float32),
                             torch.tensor(y_train, dtype=torch.long))
    test_ds = TensorDataset(torch.tensor(X_test, dtype=torch.float32),
                            torch.tensor(y_test, dtype=torch.long))
    g = torch.Generator(); g.manual_seed(seed)
    return (DataLoader(train_ds, batch_size=batch_size, shuffle=True, generator=g),
            DataLoader(test_ds, batch_size=batch_size))


# ---------------------------------------------------------------------------
# AG News text classification: a second, non-vision domain.
# A word-level tokenizer (built once from the train split, frequency-capped)
# plus a small from-scratch Transformer encoder. Tokenised tensors are cached
# to disk so the 6 lr x 5 seeds x N optimiser sweep does not re-tokenise 120k
# texts on every run.
# ---------------------------------------------------------------------------
import re as _re
import json as _json
import collections as _collections

_AGNEWS_REPO = "fancyzhx/ag_news"
# Hub revision used for the reported results (pinned so a re-upload on the
# Hub cannot silently change the vocabulary or the tensor cache).
_AGNEWS_REVISION = "eb185aade064a813bc0b7f42de02595523103ca4"
_TOKEN_RE = _re.compile(r"[a-z0-9]+")
_PAD, _UNK = 0, 1


def _agnews_tokenize(text):
    return _TOKEN_RE.findall(text.lower())


def _agnews_vocab_path(vocab_size):
    return os.path.join(DATA_ROOT, f"agnews_vocab_V{vocab_size}.json")


def _agnews_build_vocab(train_texts, vocab_size):
    path = _agnews_vocab_path(vocab_size)
    if os.path.exists(path):
        with open(path) as f:
            return _json.load(f)
    counter = _collections.Counter()
    for t in train_texts:
        counter.update(_agnews_tokenize(t))
    itos = ["<pad>", "<unk>"] + [w for w, _ in counter.most_common(vocab_size - 2)]
    stoi = {w: i for i, w in enumerate(itos)}
    os.makedirs(DATA_ROOT, exist_ok=True)
    with open(path, "w") as f:
        _json.dump(stoi, f)
    return stoi


def _agnews_encode(text, stoi, max_len):
    ids = [stoi.get(tok, _UNK) for tok in _agnews_tokenize(text)][:max_len]
    if len(ids) < max_len:
        ids += [_PAD] * (max_len - len(ids))
    return ids


def make_agnews_loaders(batch_size=256, num_workers=4, seed=0,
                        max_len=64, vocab_size=20000):
    """Returns (train_loader, test_loader, vocab_size_effective)."""
    cache = os.path.join(DATA_ROOT, f"agnews_cache_L{max_len}_V{vocab_size}.pt")
    if os.path.exists(cache):
        blob = torch.load(cache)
        Xtr, ytr, Xte, yte, vocab_eff = (blob["Xtr"], blob["ytr"],
                                         blob["Xte"], blob["yte"], blob["vocab"])
    else:
        from datasets import load_dataset
        ds = load_dataset(_AGNEWS_REPO, revision=_AGNEWS_REVISION)
        stoi = _agnews_build_vocab(ds["train"]["text"], vocab_size)
        vocab_eff = len(stoi)

        def enc(texts):
            return torch.tensor([_agnews_encode(t, stoi, max_len) for t in texts],
                                dtype=torch.long)
        Xtr = enc(ds["train"]["text"]); ytr = torch.tensor(ds["train"]["label"], dtype=torch.long)
        Xte = enc(ds["test"]["text"]);  yte = torch.tensor(ds["test"]["label"],  dtype=torch.long)
        os.makedirs(DATA_ROOT, exist_ok=True)
        torch.save({"Xtr": Xtr, "ytr": ytr, "Xte": Xte, "yte": yte, "vocab": vocab_eff}, cache)

    train_ds = TensorDataset(Xtr, ytr)
    test_ds = TensorDataset(Xte, yte)
    g = torch.Generator(); g.manual_seed(seed)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                              num_workers=num_workers, pin_memory=True,
                              persistent_workers=num_workers > 0, generator=g)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False,
                             num_workers=num_workers, pin_memory=True,
                             persistent_workers=num_workers > 0)
    return train_loader, test_loader, vocab_eff


class AGNewsTransformer(nn.Module):
    """Small from-scratch encoder-only Transformer (4 layers, d_model 128)."""
    def __init__(self, vocab_size, num_classes=4, d_model=128, nhead=4,
                 num_layers=4, dim_feedforward=256, max_len=64, dropout=0.1):
        super().__init__()
        self.pad_idx = _PAD
        self.max_len = max_len
        self.embed = nn.Embedding(vocab_size, d_model, padding_idx=_PAD)
        self.pos = nn.Embedding(max_len, d_model)
        layer = nn.TransformerEncoderLayer(
            d_model, nhead, dim_feedforward, dropout=dropout,
            batch_first=True, activation="gelu")
        self.encoder = nn.TransformerEncoder(layer, num_layers)
        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, num_classes)

    def forward(self, x):  # x: [B, L] long token ids
        B, L = x.shape
        pad_mask = (x == self.pad_idx)              # [B, L] True at padding
        pos_ids = torch.arange(L, device=x.device).unsqueeze(0).expand(B, L)
        h = self.embed(x) + self.pos(pos_ids)
        h = self.encoder(h, src_key_padding_mask=pad_mask)
        keep = (~pad_mask).unsqueeze(-1).float()    # mean-pool over real tokens
        h = (h * keep).sum(1) / keep.sum(1).clamp(min=1.0)
        return self.head(self.norm(h))
