#!/usr/bin/env bash
# Reproduce the MECHANISM and DIVERGENCE experiments of
# ./armijo_curvature_probe.tex: the alpha-lambda_1 correlation runs, the
# master scatter, and the divergence-boundary (kappa) sweep. The main rescue
# tables (baselines, Fashion calibration, AG News, 100-epoch cosine) are
# produced by the per-experiment drivers listed in eos/REPRODUCE.md, NOT here.
#
# Idempotent: existing output directories with summary.json are skipped.
# Set PY to override the python interpreter (default: `python` on PATH).
# Set GPU0 / GPU1 to choose CUDA devices (default 0 and 1).

set -euo pipefail

PY=${PY:-python}
GPU0=${GPU0:-0}
GPU1=${GPU1:-1}

cd "$(dirname "$0")/.."   # project root

run () {
    local outdir=$1; shift
    if [[ -f "$outdir/summary.json" ]]; then
        echo "[skip] $outdir (already done)"; return
    fi
    echo "[run]  $outdir"
    "$PY" "$@" --outdir "$outdir"
}

mkdir -p eos/runs

# ============================================================
# Section 5.1 / 5.2 — alpha-lambda_1 correlation experiments
# ============================================================
echo "=== Headline correlation runs ==="

# CIFAR-10, three line-search variants, multiple seeds for pure Armijo
for sd in 0 1 2; do
    run eos/runs/cifar10_ggao_armijo_seed${sd} \
        -m eos.train --dataset cifar10 --optimizer ggao_armijo \
        --epochs 10 --probe-every 100 --probe-size 256 --batch-size 256 \
        --gpu $GPU0 --seed $sd
done

run eos/runs/cifar10_ggao_gs_armijo_seed0 \
    -m eos.train --dataset cifar10 --optimizer ggao_gs_armijo \
    --epochs 10 --probe-every 100 --probe-size 256 --batch-size 256 \
    --gpu $GPU0 --seed 0

run eos/runs/cifar10_ggao_tanh_seed0 \
    -m eos.train --dataset cifar10 --optimizer ggao_gs_armijo_tanh \
    --epochs 10 --probe-every 100 --probe-size 256 --batch-size 256 \
    --gpu $GPU0 --seed 0

run eos/runs/cifar10_adam_seed0 \
    -m eos.train --dataset cifar10 --optimizer adam \
    --epochs 10 --probe-every 100 --probe-size 256 --batch-size 256 \
    --gpu $GPU0 --seed 0 --lr 0.001

# Digits, three variants
for opt in ggao_gs_armijo ggao_gs_armijo_tanh ggao_armijo; do
    run eos/runs/digits_${opt}_seed0 \
        -m eos.train --dataset digits --optimizer $opt \
        --epochs 20 --probe-every 30 --probe-size 200 --batch-size 128 \
        --gpu $GPU0 --seed 0
done

# ============================================================
# Section 5.3 — Adam-SLS controller sweep
# ============================================================
echo "=== Adam-SLS controller sweep ==="

# Three controllers x six lr x two seeds = 36 runs
for lr in 0.001 0.01 0.1 0.3 1.0 3.0; do
    for opt in adam adam_watchdog adam_tracker; do
        for sd in 0 1; do
            run eos/runs/cifar_${opt}_lr${lr}_seed${sd} \
                -m eos.train_adam_sls --optimizer $opt \
                --epochs 10 --probe-every 50 --batch-size 256 --num-workers 4 \
                --gpu $GPU0 --seed $sd --lr $lr
        done
    done
done

# Baselines: gradient clipping and linear warmup (5 lr x 2 seeds x 2 baselines = 20 runs)
for lr in 0.001 0.01 0.1 0.3 1.0; do
    for opt in adam_clip adam_warmup; do
        for sd in 0 1; do
            run eos/runs/cifar_${opt}_lr${lr}_seed${sd} \
                -m eos.train_adam_sls --optimizer $opt \
                --epochs 10 --batch-size 256 --num-workers 4 \
                --gpu $GPU1 --seed $sd --lr $lr
        done
    done
done

# ============================================================
# Section 5.4 — Adam divergence sweep
# ============================================================
echo "=== Adam divergence sweep ==="

run eos/runs/divergence_cifar10 \
    -m eos.divergence --dataset cifar10 \
    --warmup-steps 200 --adam-epochs 1 --adam-max-steps 400 \
    --batch-size 256 --gpu $GPU1

# Fine-grained sweep around the divergence boundary
if [[ ! -f eos/runs/divergence_cifar10_fine/divergence.json ]]; then
    echo "[run]  divergence_cifar10_fine (one-off)"
    "$PY" - <<'PYEOF'
import os, sys, json, time
sys.path.insert(0, ".")
import torch, numpy as np
from eos.data import cifar_resnet18, make_cifar10_loaders
from eos.divergence import warmup_alpha, run_adam
device = torch.device("cuda"); torch.cuda.set_device(int(os.environ.get("GPU1",1)))
train_loader, _ = make_cifar10_loaders(batch_size=256, num_workers=4, seed=0)
mf = lambda: cifar_resnet18(num_classes=10)
anchor, _ = warmup_alpha(mf, train_loader, device, n_steps=200, seed=0)
results = []
for m in [0.25, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.5, 2.0, 5.0]:
    r = run_adam(mf, train_loader, m * anchor, epochs=1, device=device, seed=0, max_steps=400)
    r["multiplier"] = m; del r["losses"]
    results.append(r)
os.makedirs("eos/runs/divergence_cifar10_fine", exist_ok=True)
with open("eos/runs/divergence_cifar10_fine/divergence.json", "w") as f:
    json.dump({"alpha_anchor": anchor, "results": results}, f, indent=2)
PYEOF
fi

# ============================================================
# Aggregation and figures
# ============================================================
echo "=== Aggregating results ==="
"$PY" -m eos.analyze \
    eos/runs/cifar10_ggao_armijo_seed0 \
    eos/runs/cifar10_ggao_armijo_seed1 \
    eos/runs/cifar10_ggao_armijo_seed2 \
    eos/runs/cifar10_ggao_gs_armijo_seed0 \
    eos/runs/cifar10_ggao_tanh_seed0 \
    eos/runs/digits_ggao_armijo_seed0 \
    eos/runs/digits_ggao_gs_armijo_seed0 \
    eos/runs/digits_ggao_tanh_seed0

"$PY" -m eos.summarize_adam_sls
"$PY" eos/master_scatter.py eos/runs/fig_master_scatter.png

echo "Done. Verify the frozen snapshot with: python results/verify_tables.py"
