# eos/lm_kappa_ladder.py
#
# Analysis artifact: is the shrinking safety
# margin kappa* = (divergence boundary)/(alpha_init) at GPT-2 a DOMAIN effect
# (decoder LM as such) or a SCALE effect (parameter count)? Within the fixed
# LM domain (WikiText-103, GPT-2 architecture family) this script measures,
# per model size:
#   (1) alpha_init along the Adam direction (median over N probe batches),
#   (2) the divergence boundary of vanilla AdamW (no warmup, no clipping) by
#       running short budgets over an eta ladder around alpha_init,
# and reports kappa* per size. A flat kappa* across sizes = domain effect; a
# kappa* falling with size = scale effect.
#
# Boundary runs use eos/train_lm.py semantics inline (same divergence rule).
#
# Usage: python -m eos.lm_kappa_ladder --sizes tiny mid --gpu 0
#        (small/medium numbers come from the main grid / earlier scans)

import os, sys, json, argparse, math, time
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.lm import GPT2LM, lm_loss, BinBatches, TRAIN_BIN

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
DIVERGENCE_FACTOR = 5.0
ETAS = [0.02, 0.04, 0.0625, 0.125, 0.25, 0.5]


def probe_alpha(model, params, batches, ac, n=10):
    alphas = []
    for _ in range(n):
        xb, yb = batches.next()
        model.zero_grad(set_to_none=True)
        with ac:
            l0 = lm_loss(model, xb, yb)
        l0.backward()
        grads = [p.grad.detach().clone() for p in params]
        d = [-g / (g.abs() + 1e-8) for g in grads]
        gd = sum((g * di).sum().item() for g, di in zip(grads, d))
        x0 = [p.detach().clone() for p in params]
        L0 = float(l0.detach())
        alpha = 1.0
        for _ in range(8):
            with torch.no_grad():
                for p, x, dp in zip(params, x0, d):
                    p.data.copy_(x + alpha * dp)
                with ac:
                    lt = float(lm_loss(model, xb, yb))
            if lt <= L0 + 1e-4 * alpha * gd:
                break
            alpha *= 0.5
        with torch.no_grad():
            for p, x in zip(params, x0):
                p.data.copy_(x)
        alphas.append(alpha)
    model.zero_grad(set_to_none=True)
    return alphas


def run_short(size, lr, seed, steps, device, ac):
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = GPT2LM(size, block_size=512).to(device)
    model.train()
    batches = BinBatches(TRAIN_BIN, 512, 16, device, seed=1000 + seed)
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    initial = None
    for step in range(1, steps + 1):
        xb, yb = batches.next()
        opt.zero_grad(set_to_none=True)
        with ac:
            loss = lm_loss(model, xb, yb)
        loss.backward()
        opt.step()
        cur = float(loss.detach())
        if initial is None:
            initial = cur
        if not math.isfinite(cur) or cur > DIVERGENCE_FACTOR * initial:
            del model, opt
            torch.cuda.empty_cache()
            return True, step
    del model, opt
    torch.cuda.empty_cache()
    return False, steps


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--sizes", nargs="+", default=["tiny", "mid"])
    p.add_argument("--seeds", nargs="+", type=int, default=[0, 1])
    p.add_argument("--steps", type=int, default=1000)
    p.add_argument("--gpu", type=int, default=0)
    args = p.parse_args()
    device = torch.device("cuda")
    torch.cuda.set_device(args.gpu)
    ac = torch.autocast("cuda", dtype=torch.bfloat16)

    results = {}
    for size in args.sizes:
        torch.manual_seed(0)
        np.random.seed(0)
        model = GPT2LM(size, block_size=512).to(device)
        model.train()
        nparams = sum(pp.numel() for pp in model.parameters())
        params = [pp for pp in model.parameters() if pp.requires_grad]
        batches = BinBatches(TRAIN_BIN, 512, 16, device, seed=1000)
        alphas = probe_alpha(model, params, batches, ac, n=10)
        alpha_med = float(np.median(alphas))
        del model
        torch.cuda.empty_cache()
        print(f"[{size}] {nparams/1e6:.0f}M  alpha_init median={alpha_med:.5g} "
              f"(min {min(alphas):.5g} max {max(alphas):.5g})", flush=True)

        rows = []
        for lr in ETAS:
            divs = []
            for seed in args.seeds:
                d, st = run_short(size, lr, seed, args.steps, device, ac)
                divs.append((d, st))
            ndiv = sum(1 for d, _ in divs if d)
            rows.append((lr, ndiv, len(divs)))
            print(f"  eta={lr:<8g} diverged {ndiv}/{len(divs)} "
                  f"{[st for _, st in divs]}", flush=True)
        stable = [lr for lr, nd, n in rows if nd == 0]
        divergent = [lr for lr, nd, n in rows if nd == n]
        lo = max(stable) if stable else float("nan")
        hi = min(divergent) if divergent else float("nan")
        results[size] = {"n_params": nparams, "alpha_init": alpha_med,
                         "alphas": alphas, "boundary_low": lo,
                         "boundary_high": hi, "rows": rows,
                         "kappa_low": lo / alpha_med, "kappa_high": hi / alpha_med}
        print(f"  => boundary in ({lo:g}, {hi:g}]  kappa* in "
              f"({lo/alpha_med:.2f}, {hi/alpha_med:.2f}]", flush=True)

    out = os.path.join(RUNS, "lm_kappa_ladder.json")
    with open(out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"[written] {out}")


if __name__ == "__main__":
    main()
