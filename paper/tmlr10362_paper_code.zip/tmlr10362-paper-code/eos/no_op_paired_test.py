# eos/no_op_paired_test.py
#
# Verification artifact: verify that the init
# probe is a bit-exact no-op whenever the cap does not bind.
#
# For each of the nine suite architectures:
#   T1 (state identity): hash parameters, non-parameter buffers and the torch
#      RNG state (CPU+CUDA) before and after armijo_cap(). Reported separately
#      for the HARDENED probe (probe_state_guard) and for a local copy of the
#      UNGUARDED pre-review implementation, to document what the hardening
#      fixed (BN running stats + RNG drift).
#   T2 (first-update identity): two fresh models from the same seed and the
#      same first batch; run A probes then takes one Adam step, run B takes
#      the Adam step directly. If the cap does not bind, the resulting
#      parameters+buffers must be bit-identical. A no-probe self-test (B vs
#      B') guards against platform nondeterminism being misread as a probe
#      effect.
#
# Output: eos/runs/no_op_paired_test.csv + human-readable log on stdout.
#
# Usage: CUBLAS_WORKSPACE_CONFIG=:4096:8 python -m eos.no_op_paired_test [--gpu 0]

import argparse
import hashlib
import os
import sys

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.data import (cifar_resnet18, make_cifar10_loaders, FashionCNN,
                      make_fashion_mnist_loaders, make_agnews_loaders,
                      AGNewsTransformer)
from eos.validate_kappa_universality import (MLP, LSTMClf, vgg_bn, strip_norm,
                                             bn_to_gn, armijo_cap, EPS, C)

torch.use_deterministic_algorithms(True, warn_only=True)
torch.backends.cudnn.benchmark = False


def sha(t):
    return hashlib.sha256(t.detach().cpu().contiguous().numpy().tobytes()).hexdigest()


def state_hashes(model):
    params = hashlib.sha256()
    for _, p in sorted(model.named_parameters()):
        params.update(sha(p).encode())
    bufs = hashlib.sha256()
    for _, b in sorted(model.named_buffers()):
        bufs.update(sha(b).encode())
    rng = hashlib.sha256(bytes(torch.get_rng_state().numpy().tobytes()))
    if torch.cuda.is_available():
        for s in torch.cuda.get_rng_state_all():
            rng.update(bytes(s.numpy().tobytes()))
    return params.hexdigest(), bufs.hexdigest(), rng.hexdigest()


def armijo_cap_unguarded(model, crit, X, Y, lr, kappa, mode,
                         beta=0.5, amax=1.0, max_iter=30):
    """Local copy of the PRE-REVIEW implementation (params restored, buffers
    and RNG not). Kept here verbatim to document the before/after contrast."""
    params = [p for p in model.parameters() if p.requires_grad]
    model.zero_grad(set_to_none=True)
    loss0 = crit(model(X), Y)
    g = torch.autograd.grad(loss0, params)
    L0 = float(loss0.detach())
    d = [-gi for gi in g] if mode == "grad" else [-gi / (gi.abs() + EPS) for gi in g]
    gTd = float(sum((gi * di).sum() for gi, di in zip(g, d)))
    x0 = [p.detach().clone() for p in params]

    def f(a):
        with torch.no_grad():
            for p, x, di in zip(params, x0, d):
                p.copy_(x + a * di)
            v = float(crit(model(X), Y).detach())
        return v
    a = amax
    for _ in range(max_iter):
        if f(a) <= L0 + C * a * gTd:
            break
        a *= beta
    with torch.no_grad():
        for p, x in zip(params, x0):
            p.copy_(x)
    return min(lr, kappa * a), a


def fresh(mf, seed):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    return mf().to(DEV)


def one_adam_step(model, crit, X, Y, lr):
    model.train()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    opt.zero_grad(set_to_none=True)
    loss = crit(model(X), Y)
    loss.backward()
    opt.step()
    return opt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gpu", type=int, default=0)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    global DEV
    DEV = f"cuda:{args.gpu}" if torch.cuda.is_available() else "cpu"

    cif_tl, _ = make_cifar10_loaders(batch_size=256, num_workers=0, seed=0)
    fas_tl, _ = make_fashion_mnist_loaders(batch_size=256, num_workers=0, seed=0)
    ag_tl, _, vocab = make_agnews_loaders(batch_size=256, num_workers=0, seed=0)
    batch = {}
    for name, tl in [("cifar", cif_tl), ("fashion", fas_tl), ("agnews", ag_tl)]:
        X, Y = next(iter(tl))
        batch[name] = (X.to(DEV), Y.to(DEV))
    crit = nn.CrossEntropyLoss()

    archs = [
        ("cifar_bn", lambda: cifar_resnet18(), "cifar"),
        ("fashion", lambda: FashionCNN(), "fashion"),
        ("cifar_nobn", lambda: strip_norm(cifar_resnet18()), "cifar"),
        ("transformer_nowarmup",
         lambda: AGNewsTransformer(vocab, num_classes=4, d_model=256, nhead=4,
                                   num_layers=8, dim_feedforward=1024, max_len=64),
         "agnews"),
        ("mlp_fashion", lambda: MLP(784, 10), "fashion"),
        ("vgg_bn_cifar", lambda: vgg_bn(10), "cifar"),
        ("resnet_gn_cifar", lambda: bn_to_gn(cifar_resnet18()), "cifar"),
        ("lstm_agnews", lambda: LSTMClf(vocab), "agnews"),
        ("transformer_wide",
         lambda: AGNewsTransformer(vocab, num_classes=4, d_model=384, nhead=6,
                                   num_layers=6, dim_feedforward=1536, max_len=64),
         "agnews"),
    ]

    eta, kappa = 1e-3, 2.0
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "runs", "no_op_paired_test.csv")
    import csv as _csv
    with open(out, "w", newline="") as f:
        w = _csv.DictWriter(f, fieldnames=[
            "arch", "cap_binds", "alpha_bar",
            "t1_guarded_params", "t1_guarded_buffers", "t1_guarded_rng",
            "t1_unguarded_params", "t1_unguarded_buffers", "t1_unguarded_rng",
            "t2_selftest_identical", "t2_probe_vs_noprobe_identical"])
        w.writeheader()
        for name, mf, ds in archs:
            X, Y = batch[ds]

            # ---- T1: state identity around the probe --------------------
            row = {"arch": name}
            for tag, fn in [("guarded", armijo_cap),
                            ("unguarded", armijo_cap_unguarded)]:
                m = fresh(mf, args.seed)
                m.train()
                h0 = state_hashes(m)
                clr, ab = fn(m, crit, X, Y, eta, kappa, "adam")
                h1 = state_hashes(m)
                for part, i in [("params", 0), ("buffers", 1), ("rng", 2)]:
                    row[f"t1_{tag}_{part}"] = "identical" if h0[i] == h1[i] else "CHANGED"
                if tag == "guarded":
                    row["cap_binds"] = int(clr < eta)
                    row["alpha_bar"] = ab

            # ---- T2: first Adam update, probe vs no probe ---------------
            def update_hash(do_probe):
                m = fresh(mf, args.seed)
                m.train()
                if do_probe:
                    clr, _ = armijo_cap(m, crit, X, Y, eta, kappa, "adam")
                    assert clr == eta, "cap binds; T2 not applicable"
                one_adam_step(m, crit, X, Y, eta)
                p, b, _ = state_hashes(m)
                return p + b

            if row["cap_binds"]:
                row["t2_selftest_identical"] = ""
                row["t2_probe_vs_noprobe_identical"] = "skipped (cap binds)"
            else:
                row["t2_selftest_identical"] = int(
                    update_hash(False) == update_hash(False))
                row["t2_probe_vs_noprobe_identical"] = int(
                    update_hash(True) == update_hash(False))
            w.writerow(row)
            f.flush()
            print(f"[{name}] cap_binds={row['cap_binds']} "
                  f"guarded: p={row['t1_guarded_params']} b={row['t1_guarded_buffers']} "
                  f"rng={row['t1_guarded_rng']} | unguarded: "
                  f"b={row['t1_unguarded_buffers']} rng={row['t1_unguarded_rng']} | "
                  f"T2 self={row['t2_selftest_identical']} "
                  f"probe-vs-none={row['t2_probe_vs_noprobe_identical']}", flush=True)
    print(f"[written] {out}", file=sys.stderr)


if __name__ == "__main__":
    main()
