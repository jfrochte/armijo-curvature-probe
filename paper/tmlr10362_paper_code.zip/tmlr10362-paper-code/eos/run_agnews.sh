#!/usr/bin/env bash
# AG News robustness experiment with a small from-scratch
# Transformer (4 layers, d_model 128) -- a second, non-vision domain to test
# whether the init-probe rescue transfers. Full sweep: all controllers plus the
# parameter-free baselines x 6 initial lr x 5 seeds.
#
# PARALLEL: jobs split round-robin (index parity) across two GPUs. Idempotent.
# Env overrides: PY, GPU0, GPU1, SEEDS, LRS, OPTS, KAPPA.

set -uo pipefail
PY=${PY:-python}
GPU0=${GPU0:-0}
GPU1=${GPU1:-1}
SEEDS=${SEEDS:-"0 1 2 3 4"}
LRS=${LRS:-"0.001 0.01 0.1 0.3 1.0 3.0"}
OPTS=${OPTS:-"adam adam_init_only adam_watchdog adam_tracker adam_schedulefree prodigy"}
KAPPA=${KAPPA:-0.25}
TAG=${TAG:-agnews}        # output prefix; use agnews_calib for a recalibrated kappa

cd "$(dirname "$0")/.."
mkdir -p eos/runs

JOBS=()
for opt in $OPTS; do
    for lr in $LRS; do
        for sd in $SEEDS; do
            JOBS+=("$opt $lr $sd")
        done
    done
done

run_one () {
    local gpu=$1 opt=$2 lr=$3 sd=$4
    local outdir="eos/runs/${TAG}_${opt}_lr${lr}_seed${sd}"
    if [[ -f "$outdir/summary.json" ]]; then echo "[skip gpu$gpu] $outdir"; return; fi
    echo "[run  gpu$gpu] $outdir"
    "$PY" -m eos.train_adam_sls --dataset agnews --optimizer "$opt" \
        --epochs 10 --probe-every 50 --batch-size 256 --num-workers 4 \
        --init-safety "$KAPPA" --gpu "$gpu" --seed "$sd" --lr "$lr" --outdir "$outdir" \
        > "${outdir}.log" 2>&1 || echo "[FAIL gpu$gpu] $outdir"
}

worker () {
    local gpu=$1 parity=$2 i=0
    for job in "${JOBS[@]}"; do
        if (( i % 2 == parity )); then run_one "$gpu" $job; fi
        ((i++))
    done
    echo "[worker gpu$gpu] done"
}

echo "=== launching ${#JOBS[@]} AG News jobs across GPU$GPU0 and GPU$GPU1 (kappa=$KAPPA, tag=$TAG) ==="
worker "$GPU0" 0 &
P0=$!
worker "$GPU1" 1 &
P1=$!
wait $P0 $P1
echo "=== AG News sweep finished ==="
"$PY" -m eos.summarize_agnews
