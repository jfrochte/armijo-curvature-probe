# eos/headline_plot.py
#
# Reproduction artifact: produces runs/fig_rescue_headline.png
#   -> Figure \label{fig:rescue-headline} in armijo_curvature_probe.tex
#   Run from the repository root. Data: adam_init_only / controller runs of
#   run_cifar_seeds_kappa.sh + run_new_baselines.sh.
#
# Generate the main learning-rate robustness figure:
# accuracy vs initial lr, on log-x axis, with vanilla Adam, Watchdog,
# Tracker, and the two cheap baselines (clip, warmup).
#
# Diverged runs are plotted at acc = 0.05 with an "x" marker (visible above
# the axis). Means and 1-sigma bars over the five seeds (SEEDS = 0..4).

import os, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = "eos/runs"
SEEDS = [0, 1, 2, 3, 4]


def load(opt, lr):
    accs = []
    div_count = 0
    for sd in SEEDS:
        p = f"{ROOT}/cifar_{opt}_lr{lr}_seed{sd}/summary.json"
        if not os.path.exists(p):
            continue
        s = json.load(open(p))
        if s["diverged"]:
            div_count += 1
            accs.append(0.0)
        else:
            accs.append(s["test_acc"])
    if not accs:
        return None
    return dict(mean=float(np.mean(accs)), std=float(np.std(accs)),
                div_count=div_count, n=len(accs))


CONFIG = [
    # opt_key,           label,                       color, marker
    ("adam",             "Vanilla Adam",              "C3",  "o"),
    ("adam_init_only",   "Adam-InitOnly (ours)",      "C0",  "s"),
    ("adam_watchdog",    "Adam-Watchdog (ours)",      "C9",  "P"),
    ("adam_tracker",     "Adam-Tracker (ours)",       "C2",  "D"),
    ("adam_schedulefree","Schedule-Free AdamW",        "C1",  "^"),
    ("prodigy",          "Prodigy",                   "C6",  "*"),
]

LRS = ["0.001", "0.01", "0.1", "0.3", "1.0", "3.0"]
LR_FLOAT = [float(x) for x in LRS]


def main(out="eos/runs/fig_rescue_headline.png"):
    fig, ax = plt.subplots(figsize=(8.5, 5))
    # Methods that fully diverge share the same x-positions; stagger their "x"
    # markers vertically so each diverging method stays visible.
    div_y = {}
    div_levels = [0.055, 0.025]
    for opt, label, color, marker in CONFIG:
        means, stds, div_flags, lrs_used = [], [], [], []
        for lr_str, lr in zip(LRS, LR_FLOAT):
            r = load(opt, lr_str)
            if r is None:
                continue
            lrs_used.append(lr)
            means.append(r["mean"])
            stds.append(r["std"])
            div_flags.append(r["div_count"] == r["n"])  # all diverged
        means = np.array(means); stds = np.array(stds)
        lrs_used = np.array(lrs_used); div_flags = np.array(div_flags)

        # plot non-diverged points with errorbar
        ok = ~div_flags
        if ok.any():
            ax.errorbar(lrs_used[ok], means[ok], yerr=stds[ok], fmt="-",
                        color=color, marker=marker, label=label, markersize=8,
                        linewidth=1.5, capsize=4)
        # plot diverged points as x markers, staggered per method so overlapping
        # divergent methods (vanilla Adam and Schedule-Free) are both visible.
        if div_flags.any():
            y = div_levels[len(div_y) % len(div_levels)]
            div_y[label] = (y, color)
            xd = lrs_used[div_flags]
            ax.scatter(xd, np.full(div_flags.sum(), y),
                       marker="x", color=color, s=110, linewidths=2.5, zorder=5)
            # Connect the last surviving point to the first divergence with a
            # dashed "cliff", so each x is visibly tied to its own curve.
            if ok.any():
                ax.plot([lrs_used[ok][-1], xd[0]], [means[ok][-1], y],
                        color=color, ls="--", lw=1.2, alpha=0.5, zorder=1)

    ax.set_xscale("log")
    ax.set_xlabel(r"Initial learning rate $\eta_{\rm init}$")
    ax.set_ylabel("Test accuracy after 10 epochs")
    ax.set_ylim(0.0, 0.95)
    ax.axhline(0.10, color="gray", ls=":", alpha=0.6)
    ax.text(3.0, 0.12, "random-guess level (10%)", fontsize=8, color="gray", ha="right")
    ax.set_title(r"CIFAR-10 / ResNet-18: robustness across a $3000\times$ range of initial learning rates")
    ax.legend(loc="center left", fontsize=9)
    ax.grid(True, which="both", alpha=0.2)

    # diverged-run annotation, placed bottom-left clear of the markers and legend.
    ax.text(0.0011, 0.035,
            r"$\times$ = training diverged (loss $\to\infty$ within 2 steps)",
            fontsize=8.5, color="dimgray", ha="left", va="center")

    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print(f"[plot] {out}")


if __name__ == "__main__":
    main()
