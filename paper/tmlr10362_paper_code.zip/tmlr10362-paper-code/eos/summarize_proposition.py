# eos/summarize_proposition.py
#
# Reproduction artifact: console-only. Produces the inline prose numbers of the
#   "What the line search actually inverts" paragraph (Sec. 5.4) of
#   armijo_curvature_probe.tex: band-containment %, median 1/alpha / q ratio,
#   and q vs lambda_1. No table/figure. Data: run_mechanism_all.sh.
# Scoped-(a) test: does the probe step alpha invert the *directional* curvature
# q = g^T H g / ||g||^2, as the local-quadratic Armijo bound predicts?
#
# Proposition: on a quadratic, Armijo backtracking (constant c, factor beta,
# from alpha_max) returns alpha with
#       q / (2(1-c))  <=  1/alpha  <=  q / (2 beta (1-c))      (when the
# constraint binds, i.e. alpha < alpha_max). We test band containment, the
# median ratio to the lower edge, and how close q is to lambda_1 (the EoS
# alignment that turns 1/alpha ~ q into 1/alpha ~ lambda_1).
#
# Usage: python -m eos.summarize_proposition <label> <run_dir> [<run_dir> ...]

import os, sys
import numpy as np
import pandas as pd

C, BETA, ALPHA_MAX = 1e-4, 0.5, 1.0


def collect(run_dirs):
    rows = []
    for d in run_dirs:
        p = os.path.join(d, "trace.csv")
        if not os.path.exists(p):
            continue
        df = pd.read_csv(p)
        if "alpha_probe" not in df or "dir_curv_q" not in df:
            continue
        df = df.dropna(subset=["alpha_probe", "dir_curv_q", "lambda_1"])
        df = df[(df.alpha_probe > 0) & (df.dir_curv_q > 0) & (df.lambda_1 > 0)]
        rows.append(df)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def main(label, run_dirs):
    df = collect(run_dirs)
    if df.empty:
        print(f"[{label}] no data with alpha_probe/dir_curv_q"); return
    inva = 1.0 / df.alpha_probe.values
    q = df.dir_curv_q.values
    lam = df.lambda_1.values
    active = df.alpha_probe.values < 0.99 * ALPHA_MAX
    n_all, n_act = len(df), int(active.sum())

    lo = q / (2 * (1 - C))
    hi = q / (2 * BETA * (1 - C))
    in_band = (inva >= lo * 0.97) & (inva <= hi * 1.03)
    band_pct_active = 100.0 * np.mean(in_band[active]) if n_act else float("nan")
    ratio = inva / lo  # expected in [1, 1/beta] = [1, 2]
    med_ratio = float(np.median(ratio[active])) if n_act else float("nan")
    q_over_lam = float(np.median((q / lam)[active])) if n_act else float("nan")

    print(f"\n=== proposition test: {label} ===")
    print(f"  probe points: {n_all} total, {n_act} with active Armijo constraint (alpha<alpha_max)")
    print(f"  in predicted band [q/(2(1-c)), q/(2*beta*(1-c))] : {band_pct_active:.0f}% of active points")
    print(f"  median (1/alpha)/(q/(2(1-c)))                    : {med_ratio:.2f}   (predicted in [1, {1/BETA:.0f}])")
    print(f"  median q / lambda_1 (EoS alignment)              : {q_over_lam:.2f}")
    # Distribution of the ratio: out-of-band points are
    # the measured gap between the segment-averaged curvature q_bar (what
    # Armijo inverts exactly) and the point quantity q (what the HVP measures),
    # plus minibatch stochasticity -- so also report HOW FAR outside they sit,
    # on the SAME selection as the binary band rate above.
    if n_act:
        r_act = ratio[active]
        p90, p95 = np.percentile(r_act, [90, 95])
        within2 = 100.0 * np.mean((r_act >= 0.5) & (r_act <= 4.0))
        print(f"  ratio distribution (active): p90 {p90:.2f} | p95 {p95:.2f} | max {float(np.max(r_act)):.2f}  (band edge {1/BETA:.0f})")
        print(f"  within factor 2 of the band ([0.5, 4])           : {within2:.0f}% of active points")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2:])
