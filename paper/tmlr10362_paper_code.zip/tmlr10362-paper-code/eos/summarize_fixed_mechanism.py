# eos/summarize_fixed_mechanism.py
#
# Reproduction artifact: alpha--lambda_1
# correlation statistics on INDEPENDENTLY GENERATED fixed-step trajectories
# (runs from eos/run_fixed_mechanism.sh), with two methodological
# upgrades over the plain analysis:
#
#   * autocorrelation-robust p-values: the classical Pearson t-test treats
#     probe checkpoints as independent; we additionally report p computed
#     with the effective sample size of Pyper & Peterman (1998) / Bartlett,
#     AR(1) form  n_eff = n * (1 - r1a*r1b) / (1 + r1a*r1b),  where r1a/r1b
#     are the lag-1 autocorrelations of the two (residual) series;
#   * censoring: probe points with alpha at the search ceiling
#     (alpha >= 0.99 * alpha_max) carry no curvature information and are
#     excluded; their fraction is reported.
#
# The same script also re-evaluates the published pure-Armijo mechanism runs
# (--alpha-col window) so both trajectory types are analysed identically.
#
# Usage:
#   python -m eos.summarize_fixed_mechanism --alpha-col probe \
#       <label> <run_dir> [<run_dir> ...]
#   python -m eos.summarize_fixed_mechanism --alpha-col window \
#       "Pure Armijo CIFAR" eos/runs/cifar10_ggao_armijo_seed{0,1,2}

import argparse
import os
import sys

import numpy as np
import pandas as pd
from scipy import stats

ALPHA_MAX = 1.0


def load(run_dir, alpha_col):
    df = pd.read_csv(os.path.join(run_dir, "trace.csv"))
    col = "alpha_probe" if alpha_col == "probe" else "mean_alpha_window"
    sub = df.dropna(subset=[col, "lambda_1"])
    sub = sub[(sub[col] > 0) & (sub["lambda_1"] > 0)]
    n_before = len(sub)
    censored = sub[col] >= 0.99 * ALPHA_MAX
    sub = sub[~censored]
    return (sub["step"].values.astype(float), np.log(sub[col].values),
            np.log(sub["lambda_1"].values), n_before, int(censored.sum()))


def lag1(x):
    x = x - x.mean()
    d = float(np.dot(x, x))
    return float(np.dot(x[:-1], x[1:]) / d) if d > 0 else 0.0


def robust_p(r, xa, xb):
    """Two-sided p for Pearson r with AR(1)-effective sample size of the two
    series (Pyper & Peterman 1998). Conservative floor n_eff >= 4."""
    r1 = np.clip(lag1(xa) * lag1(xb), -0.99, 0.99)
    n_eff = max(len(xa) * (1.0 - r1) / (1.0 + r1), 4.0)
    dof = n_eff - 2.0
    if abs(r) >= 1.0:
        return 0.0, n_eff
    t = r * np.sqrt(dof / (1.0 - r * r))
    return float(2.0 * stats.t.sf(abs(t), dof)), float(n_eff)


def fisher(ps):
    ps = [max(p, np.finfo(float).tiny) for p in ps if np.isfinite(p)]
    if not ps:
        return float("nan")
    return float(stats.chi2.sf(-2.0 * np.sum(np.log(ps)), 2 * len(ps)))


def per_run(run_dir, alpha_col):
    step, la, ll, n_before, n_cens = load(run_dir, alpha_col)
    n = len(la)
    if n < 5:
        return None
    out = {"run": os.path.basename(run_dir), "n": n, "censored": n_cens,
           "n_before": n_before}
    r_raw = float(np.corrcoef(la, ll)[0, 1])
    out["raw"] = (r_raw,) + robust_p(r_raw, la, ll)
    res_a = la - np.polyval(np.polyfit(step, la, 1), step)
    res_l = ll - np.polyval(np.polyfit(step, ll, 1), step)
    r_det = float(np.corrcoef(res_a, res_l)[0, 1])
    out["det"] = (r_det,) + robust_p(r_det, res_a, res_l)
    da, dl = np.diff(la), np.diff(ll)
    r_dif = float(np.corrcoef(da, dl)[0, 1])
    out["dif"] = (r_dif,) + robust_p(r_dif, da, dl)
    return out


RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")

# PAPER MODE: the fixed rows of \label{tab:correlation-robust} -- the three
# pure-Armijo mechanism runs re-analysed under the stricter protocol, plus
# the eight independently generated fixed-step cells.
PAPER_ROWS = [
    ("Pure Armijo, CIFAR-10/ResNet-18", "window", "cifar10_ggao_armijo_seed", (0, 1, 2)),
    ("Pure Armijo, Fashion-MNIST/CNN", "window", "fashion_ggao_armijo_seed", (0, 1, 2)),
    ("Pure Armijo, Imagenette/ResNet-18", "window", "imagenette_ggao_armijo_seed", (0, 1, 2)),
    ("Adam $10^{-3}$, CIFAR-10/ResNet-18", "probe", "cifar10_adam_fixed_lr0.001_seed", (0, 1, 2)),
    ("Adam $10^{-2}$ (near-EoS), CIFAR-10/ResNet-18", "probe", "cifar10_adam_fixed_lr0.01_seed", (0, 1, 2)),
    ("AdamW $10^{-3}$, CIFAR-10/ResNet-18", "probe", "cifar10_adamw_fixed_lr0.001_seed", (0, 1, 2)),
    ("SGD-m $5{\\cdot}10^{-2}$, CIFAR-10/ResNet-18", "probe", "cifar10_sgd_fixed_lr0.05_seed", (0, 1, 2)),
    ("Adam $10^{-3}$, Fashion-MNIST/CNN", "probe", "fashion_mnist_adam_fixed_lr0.001_seed", (0, 1, 2)),
    ("Adam $10^{-2}$ (near-EoS), Fashion-MNIST/CNN", "probe", "fashion_mnist_adam_fixed_lr0.01_seed", (0, 1, 2)),
    ("AdamW $10^{-3}$, Fashion-MNIST/CNN", "probe", "fashion_mnist_adamw_fixed_lr0.001_seed", (0, 1, 2)),
    ("SGD-m $5{\\cdot}10^{-2}$, Fashion-MNIST/CNN", "probe", "fashion_mnist_sgd_fixed_lr0.05_seed", (0, 1, 2)),
]


def _pstr(p):
    if not np.isfinite(p):
        return "--"
    if p < 1e-3:
        return f"< 10^{{-{int(np.floor(-np.log10(p)))}}}"
    return f"{p:.3f}"


def paper_mode():
    """Print the LaTeX body of tab:correlation-robust."""
    for label, col, prefix, seeds in PAPER_ROWS:
        rows = [r for sd in seeds
                if (r := per_run(os.path.join(RUNS, f"{prefix}{sd}"), col))]
        if not rows:
            print(f"% MISSING: {label}")
            continue
        n_mean = int(np.mean([r["n"] for r in rows]))
        cens = sum(r["censored"] for r in rows)
        total = sum(r["n_before"] for r in rows)
        rs = lambda k: ([r[k][0] for r in rows], fisher([r[k][1] for r in rows]))
        (raw_r, _), (det_r, det_p), (dif_r, dif_p) = rs("raw"), rs("det"), rs("dif")
        print(f"{label} & {n_mean} & {100.0 * cens / total:.0f}\\%"
              f" & ${np.mean(raw_r):.2f}$"
              f" & ${np.mean(det_r):.2f} \\pm {np.std(det_r):.2f}$ & ${_pstr(det_p)}$"
              f" & ${np.mean(dif_r):.2f} \\pm {np.std(dif_r):.2f}$ & ${_pstr(dif_p)}$ \\\\")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--alpha-col", choices=["probe", "window"], default="probe")
    ap.add_argument("--paper", action="store_true",
                    help="print the LaTeX body of tab:correlation-robust")
    ap.add_argument("label", nargs="?")
    ap.add_argument("run_dirs", nargs="*")
    args = ap.parse_args()
    if args.paper:
        paper_mode()
        return
    if not args.label or not args.run_dirs:
        ap.error("label and run_dirs required unless --paper")

    rows = [r for d in args.run_dirs if (r := per_run(d, args.alpha_col))]
    if not rows:
        print("no usable runs")
        sys.exit(1)

    print(f"\n=== fixed-mechanism stats: {args.label} "
          f"(alpha = {args.alpha_col}, {len(rows)} runs) ===")
    for r in rows:
        print(f"  {r['run']}: n={r['n']} (+{r['censored']} censored at ceiling)"
              f"  raw r={r['raw'][0]:+.3f} (p_rob={r['raw'][1]:.1e},"
              f" n_eff={r['raw'][2]:.0f})"
              f"  det r={r['det'][0]:+.3f} (p_rob={r['det'][1]:.1e})"
              f"  diff r={r['dif'][0]:+.3f} (p_rob={r['dif'][1]:.1e})")

    def agg(key):
        rs = [r[key][0] for r in rows]
        pf = fisher([r[key][1] for r in rows])
        return np.mean(rs), np.std(rs), pf

    n_mean = int(np.mean([r["n"] for r in rows]))
    cens = sum(r["censored"] for r in rows)
    total = sum(r["n_before"] for r in rows)
    mr, sr, pr = agg("raw")
    md, sd_, pd_ = agg("det")
    mf, sf, pf = agg("dif")
    print(f"  censored at alpha ceiling: {cens}/{total} probe points"
          f" ({100.0 * cens / max(total, 1):.0f}%)")
    print(f"  raw       : {mr:+.3f} +/- {sr:.3f}   Fisher(p_rob) = {pr:.1e}")
    print(f"  detrended : {md:+.3f} +/- {sd_:.3f}   Fisher(p_rob) = {pd_:.1e}")
    print(f"  first-diff: {mf:+.3f} +/- {sf:.3f}   Fisher(p_rob) = {pf:.1e}")
    print("\n  LaTeX row (Variant & n & raw & detrended & p_F & first-diff & p_F):")
    print(f"  & {n_mean} & ${mr:.3f} \\pm {sr:.3f}$ & ${md:.3f} \\pm {sd_:.3f}$"
          f" & ${pd_:.1e}$ & ${mf:.3f} \\pm {sf:.3f}$ & ${pf:.1e}$ \\\\")


if __name__ == "__main__":
    main()
