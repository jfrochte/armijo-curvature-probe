# eos/summarize_cosine100.py
#
# Reproduction artifact: prints the LaTeX body of Table \label{tab:longrun}
#   (100-epoch cosine schedule) in armijo_curvature_probe.tex.
#   Data: run_cosine100_full.sh.
# A: aggregate the 100-epoch cosine-annealing grid (cos100_{opt}_lr{lr}_seed{s})
# into a vanilla-Adam vs Adam-InitOnly lr-robustness table at realistic length.

import os, json
import numpy as np

ROOT = "eos/runs"
OPTS = [("adam", "Vanilla Adam"), ("adam_init_only", "Adam-InitOnly")]
LRS = ["0.001", "0.01", "0.1", "0.3", "1.0", "3.0"]
SEEDS = [0, 1, 2]


def cell(opt, lr):
    accs, divs = [], []
    for sd in SEEDS:
        p = f"{ROOT}/cos100_{opt}_lr{lr}_seed{sd}/summary.json"
        if not os.path.exists(p):
            continue
        s = json.load(open(p))
        divs.append(int(s["diverged"]))
        if not s["diverged"]:
            accs.append(s["test_acc"])
    n = len(divs)
    if n == 0:
        return "--"
    if sum(divs) == n:
        return "DIV."
    mean, std = float(np.mean(accs)), float(np.std(accs))
    if sum(divs) > 0:
        return f"{mean:.3f}\\,({sum(divs)}/{n} div.)"
    return f"${mean:.3f} \\pm {std:.3f}$"


def main():
    print("\n=== 100-epoch cosine grid (console) ===")
    print(f"{'Method':<16}" + "".join(f"{('lr='+lr):<18}" for lr in LRS))
    for opt, _ in OPTS:
        print(f"{opt:<16}" + "".join(f"{cell(opt, lr):<18}" for lr in LRS))

    print("\n=== LaTeX table ===")
    print("\\begin{tabular}{lcccccc}")
    print("\\toprule")
    print("$\\eta_{\\text{init}}$ & " + " & ".join(f"${lr}$" for lr in LRS) + " \\\\")
    print("\\midrule")
    for opt, label in OPTS:
        cells = [cell(opt, lr) for lr in LRS]
        print(f"{label:<16} & {' & '.join(cells)} \\\\")
    print("\\bottomrule")
    print("\\end{tabular}")


if __name__ == "__main__":
    main()
