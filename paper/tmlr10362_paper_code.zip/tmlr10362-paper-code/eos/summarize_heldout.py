# eos/summarize_heldout.py
#
# Reproduction artifact: produces the LaTeX body of \label{tab:heldout-kappa2}
# (genuine held-out validation of the fixed kappa=2).
# Data: eos/runs/heldout_kappa2.csv from
# eos/heldout_kappa2.py. Conventions follow tab:rescue: mean over seeds,
# "DIV." = all seeds diverged, "x/n div." = partial divergence with the
# surviving-seed mean.
#
# Usage: python -m eos.summarize_heldout

import os
import sys

import numpy as np
import pandas as pd

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")

NAMES = {
    "vit_cifar": "ViT small (CIFAR-10)",
    "gru_agnews": "GRU (AG News)",
    "mobilenetv2_cifar": "MobileNetV2 (CIFAR-10)",
}
VARIANTS = [("vanilla", "vanilla Adam"),
            ("adamprobe_k2", "Adam-InitOnly (dir., $\\kappa=2$)"),
            ("adam_probation_k2", "+ probation")]
ETAS = [0.001, 0.1]


def cell(sub):
    n = len(sub)
    ndiv = int(sub.diverged.sum())
    if ndiv == n:
        return "DIV."
    acc = sub.loc[sub.diverged == 0, "test_acc"]
    m, s = acc.mean(), acc.std(ddof=0)
    if ndiv:
        return f"{m:.3f}\\,({ndiv}/{n} div.)"
    return f"${m:.3f} \\pm {s:.3f}$"


def main():
    d = pd.read_csv(os.path.join(RUNS, "heldout_kappa2.csv"))
    print(f"[read] {len(d)} rows; divergences per variant:")
    print(d.groupby("variant").diverged.sum().to_string())
    total_capped = d[d.variant != "vanilla"]
    print(f"capped runs: {len(total_capped)}, diverged: "
          f"{int(total_capped.diverged.sum())}")
    print("\nLaTeX rows (arch blocks; columns = eta 0.001, 0.1 per variant):")
    for arch, disp in NAMES.items():
        cells = []
        for var, _ in VARIANTS:
            for eta in ETAS:
                sub = d[(d.arch == arch) & (d.variant == var) & (d.eta == eta)]
                cells.append(cell(sub))
        print(f"{disp} & " + " & ".join(cells) + " \\\\")
    # alpha_bar per arch (init reading, static variant)
    print("\nInit readings alpha_bar (static kappa=2):")
    a = d[d.variant == "adamprobe_k2"].groupby("arch").alpha_bar.mean()
    for arch, v in a.items():
        print(f"  {arch}: {v:.5g}")


if __name__ == "__main__":
    main()
