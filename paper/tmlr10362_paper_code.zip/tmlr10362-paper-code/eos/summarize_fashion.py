# eos/summarize_fashion.py
#
# Reproduction artifact: produces runs/fig_fashion_headline.png
#   -> Figure \label{fig:fashion-headline} in armijo_curvature_probe.tex.
#   (The LaTeX table it prints is the uncalibrated companion; the table that
#   actually appears in the paper, \label{tab:fashion-rescue}, is built by
#   summarize_fashion_calib.py.)
#   Data: run_new_baselines.sh.
#
# Aggregate the Fashion-MNIST sweep (5 optimizers x 6 lr x 5 seeds = 150 runs)
# into a table and a headline figure analogous to the CIFAR rescue results.

import os, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = "eos/runs"
OPTS = ["adam", "adam_clip", "adam_warmup", "adam_watchdog", "adam_tracker",
        "adam_schedulefree", "prodigy"]
LRS  = ["0.001", "0.01", "0.1", "0.3", "1.0", "3.0"]
SEEDS = [0, 1, 2, 3, 4]


def load(opt, lr):
    accs, divs, walls = [], [], []
    for sd in SEEDS:
        p = f"{ROOT}/fashion_{opt}_lr{lr}_seed{sd}/summary.json"
        if not os.path.exists(p):
            continue
        s = json.load(open(p))
        if s["diverged"]:
            divs.append(1)
            accs.append(0.0)
        else:
            divs.append(0)
            accs.append(s["test_acc"])
        walls.append(s["wall_s"])
    return dict(accs=accs, divs=divs, walls=walls)


def summarize():
    rows = []
    for opt in OPTS:
        for lr in LRS:
            r = load(opt, lr)
            n = len(r["accs"])
            div_count = sum(r["divs"])
            valid_accs = [a for a, d in zip(r["accs"], r["divs"]) if d == 0]
            mean = float(np.mean(valid_accs)) if valid_accs else float("nan")
            std = float(np.std(valid_accs)) if valid_accs else float("nan")
            rows.append(dict(opt=opt, lr=lr, n=n, div_count=div_count,
                             mean_acc=mean, std_acc=std,
                             mean_wall=float(np.mean(r["walls"])) if r["walls"] else float("nan")))
    return pd.DataFrame(rows)


def print_table(df):
    print(f"\n{'Optimizer':<18} {'lr':<8} {'acc (mean±std, n)':<26} {'div':<8} {'wall(s)':<8}")
    print("-" * 78)
    for _, r in df.iterrows():
        if r["n"] == 0:
            acc_s = "no runs"
        elif r["div_count"] == r["n"]:
            acc_s = f"DIV ({r['div_count']}/{r['n']})"
        else:
            div_marker = f", div={r['div_count']}/{r['n']}" if r["div_count"] > 0 else ""
            acc_s = f"{r['mean_acc']:.4f} ± {r['std_acc']:.4f}{div_marker}"
        print(f"{r['opt']:<18} {r['lr']:<8} {acc_s:<26} {r['div_count']}/{r['n']}    {r['mean_wall']:<8.1f}")


def headline_plot(out="eos/runs/fig_fashion_headline.png"):
    fig, ax = plt.subplots(figsize=(8.5, 5))
    cfg = {
        "adam":          ("Vanilla Adam",        "C3", "o"),
        "adam_clip":     ("Adam + grad-clip",    "C5", "v"),
        "adam_warmup":   ("Adam + 200-step warmup", "C4", "P"),
        "adam_watchdog": ("Adam-Watchdog (ours)","C0", "s"),
        "adam_tracker":  ("Adam-Tracker (ours)", "C2", "D"),
        "adam_schedulefree": ("Schedule-Free AdamW", "C1", "^"),
        "prodigy":       ("Prodigy",              "C6", "*"),
    }
    LR_FLOAT = [float(x) for x in LRS]
    for opt in OPTS:
        label, color, marker = cfg[opt]
        means, stds, divs, lrs_used = [], [], [], []
        for lr_s, lr_f in zip(LRS, LR_FLOAT):
            r = load(opt, lr_s)
            if not r["accs"]:
                continue
            div_count = sum(r["divs"])
            valid = [a for a, d in zip(r["accs"], r["divs"]) if d == 0]
            lrs_used.append(lr_f)
            divs.append(div_count == len(r["accs"]))
            if valid:
                means.append(float(np.mean(valid)))
                stds.append(float(np.std(valid)))
            else:
                means.append(0.0)
                stds.append(0.0)
        means = np.array(means); stds = np.array(stds); divs = np.array(divs)
        lrs_used = np.array(lrs_used)
        ok = ~divs
        if ok.any():
            ax.errorbar(lrs_used[ok], means[ok], yerr=stds[ok], fmt="-",
                        color=color, marker=marker, label=label, markersize=8,
                        linewidth=1.5, capsize=4)
        if divs.any():
            ax.scatter(lrs_used[divs], np.full(divs.sum(), 0.05),
                       marker="x", color=color, s=100, linewidths=2.5)
    ax.set_xscale("log")
    ax.set_xlabel(r"Initial learning rate $\eta_{\rm init}$")
    ax.set_ylabel("Test accuracy after 10 epochs")
    ax.set_ylim(0.0, 1.0)
    ax.axhline(0.10, color="gray", ls=":", alpha=0.5)
    ax.text(0.0011, 0.115, "random-guess (10%)", fontsize=8, color="gray")
    ax.set_title("Fashion-MNIST / small CNN: robustness across initial learning rates (5 seeds)")
    ax.legend(loc="lower left", fontsize=9)
    ax.grid(True, which="both", alpha=0.2)
    ax.text(3.0, 0.06, r"$\times$ = diverged", fontsize=9, color="dimgray", ha="right")
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print(f"[plot] {out}")


def latex_row(opt, df_opt):
    """One row of the LaTeX rescue table for a given optimizer."""
    cells = []
    for lr in LRS:
        r = df_opt[df_opt["lr"] == lr]
        if r.empty:
            cells.append("--")
            continue
        r = r.iloc[0]
        if r["n"] == 0:
            cells.append("--")
        elif r["div_count"] == r["n"]:
            cells.append("DIV.")
        else:
            cells.append(f"${r['mean_acc']:.3f} \\pm {r['std_acc']:.3f}$")
    return cells


def print_latex_table(df):
    print("\n=== LaTeX table (paste into paper) ===")
    print("\\begin{tabular}{lcccccc}")
    print("\\toprule")
    print(" & " + " & ".join(f"$\\eta={lr}$" for lr in LRS) + " \\\\")
    print("\\midrule")
    pretty = {
        "adam": "Vanilla Adam",
        "adam_clip": "Adam + grad-clip",
        "adam_warmup": "Adam + warmup",
        "adam_watchdog": "Adam-Watchdog",
        "adam_tracker": "Adam-Tracker",
        "adam_schedulefree": "Schedule-Free AdamW",
        "prodigy": "Prodigy",
    }
    for opt in OPTS:
        cells = latex_row(opt, df[df["opt"] == opt])
        print(f"{pretty[opt]:<25} & {' & '.join(cells)} \\\\")
    print("\\bottomrule")
    print("\\end{tabular}")


if __name__ == "__main__":
    df = summarize()
    print_table(df)
    df.to_csv("eos/runs/fashion_summary.csv", index=False)
    print_latex_table(df)
    headline_plot()
