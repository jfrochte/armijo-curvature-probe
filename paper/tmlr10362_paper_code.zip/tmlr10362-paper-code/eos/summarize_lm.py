# eos/summarize_lm.py
#
# Reproduction artifact: prints the LaTeX rows of Table \label{tab:lm-rescue} from
# the run directories produced by eos/run_lm_grid.sh / eos/train_lm.py, and
# writes eos/runs/lm_rescue_summary.csv.
#
# Layout mirrors tab:rescue: one row per (model, optimizer), one column per
# initial learning rate; cell = validation perplexity after the fixed step
# budget, mean +/- std over seeds; "DIV." if every seed diverged, "x/n div."
# with the surviving-seed mean otherwise.
#
# Usage: python -m eos.summarize_lm

import os, sys, json, glob, re
import numpy as np
import pandas as pd

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
LRS = [0.001, 0.01, 0.1, 0.3, 1.0, 3.0]
ROWS = [("small", "adamw", "Vanilla AdamW (124M)"),
        ("small", "adamw_warmup", "AdamW + linear warmup (124M)"),
        ("small", "adamw_init_dir_k2", "AdamW-InitOnly (dir., $\\kappa=2$, 124M)"),
        ("small", "adamw_init_dir_k0.5", "AdamW-InitOnly (dir., $\\kappa=0.5$, 124M)"),
        ("small", "adamw_init_dir_probation", "AdamW-Probation (dir., $\\kappa=2$, 124M)"),
        ("small", "adamw_warmup_probation", "AdamW guarded warmup (124M)"),
        ("medium", "adamw", "Vanilla AdamW (355M)"),
        ("medium", "adamw_warmup", "AdamW + linear warmup (355M)"),
        ("medium", "adamw_init_dir_k2", "AdamW-InitOnly (dir., $\\kappa=2$, 355M)"),
        ("medium", "adamw_init_dir_k0.5", "AdamW-InitOnly (dir., $\\kappa=0.5$, 355M)"),
        ("medium", "adamw_init_dir_probation", "AdamW-Probation (dir., $\\kappa=2$, 355M)"),
        ("medium", "adamw_warmup_probation", "AdamW guarded warmup (355M)")]


def load_all():
    recs = []
    for d in sorted(glob.glob(os.path.join(RUNS, "lm_*_seed*"))):
        p = os.path.join(d, "summary.json")
        if not os.path.isdir(d) or not os.path.exists(p):
            continue
        s = json.load(open(p))
        m = re.match(r"lm_(small|medium)_(adamw(?:_warmup_probation|_warmup"
                     r"|_init_dir_k[0-9.]+|_init_dir_probation)?)_lr([0-9.]+)_seed(\d+)",
                     os.path.basename(d))
        if not m:
            continue
        recs.append({"model": m.group(1), "opt": m.group(2),
                     "lr": float(m.group(3)), "seed": int(m.group(4)),
                     "diverged": bool(s.get("diverged")),
                     "val_ppl": s.get("val_ppl", float("nan")),
                     "val_loss": s.get("val_loss", float("nan")),
                     "steps_run": s.get("steps_run"),
                     "alpha_init": s.get("alpha_init"),
                     "lr_after_cap": s.get("lr_after_cap")})
    return pd.DataFrame(recs)


def cell(sub):
    if not len(sub):
        return "--"
    n = len(sub)
    div = sub.diverged.sum()
    if div == n:
        return "DIV.\\"
    ok = sub[~sub.diverged].val_ppl
    if div:
        return f"{ok.mean():.1f}\\,({div}/{n} div.)"
    if n == 1:
        return f"${ok.mean():.1f}$"
    return f"${ok.mean():.1f} \\pm {ok.std(ddof=0):.1f}$"


def main():
    df = load_all()
    if not len(df):
        print("no data")
        return
    out = os.path.join(RUNS, "lm_rescue_summary.csv")
    df.sort_values(["model", "opt", "lr", "seed"]).to_csv(out, index=False)
    # Side-effect message goes to stderr: freeze_paper_data.py captures this
    # script's stdout verbatim as the canonical table body, and an absolute
    # path has no business in that frozen snapshot.
    print(f"[written] {out}  ({len(df)} runs)", file=sys.stderr)

    caps = df[df.opt == "adamw_init_dir"].dropna(subset=["alpha_init"])
    if len(caps):
        for model in ["small", "medium"]:
            c = caps[caps.model == model]
            if len(c):
                print(f"  gpt2-{model}: alpha_init={c.alpha_init.mean():.5f} "
                      f"(min {c.alpha_init.min():.5f} max {c.alpha_init.max():.5f}), "
                      f"cap kappa*alpha={2 * c.alpha_init.mean():.5f}")

    print("\n  LaTeX rows (val perplexity; columns = lr grid "
          + " ".join(str(x) for x in LRS) + "):")
    for model, opt, label in ROWS:
        cells = []
        for lr in LRS:
            sub = df[(df.model == model) & (df.opt == opt) & np.isclose(df.lr, lr)]
            cells.append(cell(sub))
        print(f"  {label} & " + " & ".join(cells) + " \\\\")


if __name__ == "__main__":
    main()
