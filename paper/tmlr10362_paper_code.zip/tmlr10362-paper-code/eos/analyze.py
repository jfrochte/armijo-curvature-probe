# eos/analyze.py
#
# Reproduction artifact: intermediate. Writes per-run correlations.json (alpha vs
#   lambda_1) consumed by summarize_mechanism.py -> Table
#   \label{tab:correlation}. Per-run PNGs are diagnostics, not in the paper.
#
# Analyze trace.csv from one or more runs:
#   - compute Pearson and Spearman correlations between alpha and lambda_1
#     (using log-transformed values, since both span orders of magnitude)
#   - plot alpha and lambda_1 over training step (twin axis)
#   - scatter 1/alpha vs lambda_1 with linear fit and correlation in caption

import os, sys, json, argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import pearsonr, spearmanr


def load_trace(run_dir):
    csv_path = os.path.join(run_dir, "trace.csv")
    summary_path = os.path.join(run_dir, "summary.json")
    df = pd.read_csv(csv_path)
    summary = json.load(open(summary_path)) if os.path.exists(summary_path) else {}
    return df, summary


def compute_correlations(df):
    # use rows where alpha is finite and >0 and lambda_1 is finite
    sub = df.dropna(subset=["mean_alpha_window", "lambda_1"])
    sub = sub[(sub["mean_alpha_window"] > 0) & (sub["lambda_1"] > 0)]
    if len(sub) < 4:
        return {"n": len(sub)}
    log_a = np.log(sub["mean_alpha_window"].values)
    log_l = np.log(sub["lambda_1"].values)
    pr, pp = pearsonr(log_a, log_l)
    sr, sp = spearmanr(log_a, log_l)
    inv_a_pr, inv_a_pp = pearsonr(1.0 / sub["mean_alpha_window"].values,
                                  sub["lambda_1"].values)
    return {
        "n": int(len(sub)),
        "pearson_log_alpha_vs_log_lambda1": float(pr),
        "pearson_log_p": float(pp),
        "spearman_log_alpha_vs_log_lambda1": float(sr),
        "spearman_p": float(sp),
        "pearson_inv_alpha_vs_lambda1": float(inv_a_pr),
        "pearson_inv_alpha_vs_lambda1_p": float(inv_a_pp),
        "alpha_mean": float(sub["mean_alpha_window"].mean()),
        "alpha_median": float(sub["mean_alpha_window"].median()),
        "lambda1_mean": float(sub["lambda_1"].mean()),
        "lambda1_max": float(sub["lambda_1"].max()),
    }


def plot_traces(df, summary, out_png):
    fig, ax1 = plt.subplots(figsize=(8, 4.5))
    ax2 = ax1.twinx()
    sub = df.dropna(subset=["mean_alpha_window"])
    if len(sub) > 0:
        ax1.plot(sub["step"], sub["mean_alpha_window"], "C0-o", label=r"$\alpha$ (line search)", markersize=3)
    ax2.plot(df["step"], df["lambda_1"], "C3-s", label=r"$\lambda_1$ (Hessian top)", markersize=3, alpha=0.85)
    ax1.set_xlabel("Step")
    ax1.set_ylabel(r"Line-search step size $\alpha$", color="C0")
    ax2.set_ylabel(r"Top Hessian eigenvalue $\lambda_1$", color="C3")
    ax1.tick_params(axis="y", labelcolor="C0")
    ax2.tick_params(axis="y", labelcolor="C3")
    ax2.set_yscale("log")
    title = f"{summary.get('dataset', '?')} / {summary.get('optimizer', '?')} (seed={summary.get('seed','?')})"
    plt.title(title)
    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    plt.close(fig)


def plot_scatter(df, summary, out_png, corr):
    sub = df.dropna(subset=["mean_alpha_window", "lambda_1"])
    sub = sub[(sub["mean_alpha_window"] > 0) & (sub["lambda_1"] > 0)]
    if len(sub) < 4:
        return
    fig, ax = plt.subplots(figsize=(5.5, 5))
    inv_a = 1.0 / sub["mean_alpha_window"].values
    lam = sub["lambda_1"].values
    ax.scatter(lam, inv_a, c=sub["step"].values, cmap="viridis")
    cb = plt.colorbar(ax.collections[0], ax=ax, label="Step")
    # linear fit on log-log
    lx = np.log(lam); ly = np.log(inv_a)
    a, b = np.polyfit(lx, ly, 1)
    xx = np.linspace(lam.min(), lam.max(), 100)
    ax.plot(xx, np.exp(a * np.log(xx) + b), "k--",
            label=f"log-log fit slope={a:.2f}")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"$\lambda_1$ (Hessian top eigenvalue)")
    ax.set_ylabel(r"$1/\alpha$ (inverse line-search step)")
    pr = corr.get("pearson_log_alpha_vs_log_lambda1", float("nan"))
    sr = corr.get("spearman_log_alpha_vs_log_lambda1", float("nan"))
    ax.set_title(
        f"{summary.get('dataset','?')} / {summary.get('optimizer','?')}\n"
        f"Pearson(log α, log λ₁) = {pr:.3f}, Spearman = {sr:.3f}, n={corr.get('n','?')}")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    plt.close(fig)


def analyze_run(run_dir):
    df, summary = load_trace(run_dir)
    corr = compute_correlations(df)
    out_dir = os.path.join(run_dir, "figs")
    os.makedirs(out_dir, exist_ok=True)
    plot_traces(df, summary, os.path.join(out_dir, "trace.png"))
    plot_scatter(df, summary, os.path.join(out_dir, "scatter.png"), corr)
    out_json = os.path.join(run_dir, "correlations.json")
    with open(out_json, "w") as f:
        json.dump({"summary": summary, "correlations": corr}, f, indent=2)
    print(f"[analyze] {run_dir}")
    print(json.dumps(corr, indent=2))
    return corr


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("run_dirs", nargs="+", help="Run directories with trace.csv files")
    args = p.parse_args()
    for d in args.run_dirs:
        if os.path.isdir(d):
            analyze_run(d)
        else:
            print(f"[skip] {d} not a directory")
