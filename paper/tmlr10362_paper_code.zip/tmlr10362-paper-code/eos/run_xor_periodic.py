"""eos/run_xor_periodic.py

Reproduction artifact: produces the XOR-toy row of Table \\label{tab:periodic}
  (and writes eos/runs/xor_periodic.csv). The two real-task rows of that table
  (CIFAR-10/ResNet-18 and AG News/Transformer at the default eta=1e-3) are NOT
  produced here -- they are read from the already-verified main sweep by
  summarize_periodic.py.

Plateau-dominated toy: a 2-hidden-unit network on the 4-point XOR problem, the
classic non-convex landscape with bad init-dependent local minima. We train
full-batch at the default eta=1e-3 and measure the fraction of 100 random seeds
that SOLVE XOR (all four points classified correctly with loss < 0.05 within the
budget). This is the one regime where the Tracker's step-size growth helps; the
real-task rows show it hurts. Tracker uses its best probe interval K.

Reuses the exact AdamSLSControlled controller (watchdog / tracker) and the same
divergence accounting as the rest of the paper. CPU is fine (tiny net); set
EOS_XOR_SEEDS to change the seed count.
"""
import os, csv
import numpy as np
import torch, torch.nn as nn
from eos.adam_sls import AdamSLSControlled

DEV = "cpu"
N_SEEDS = int(os.environ.get("EOS_XOR_SEEDS", "100"))
STEPS = int(os.environ.get("EOS_XOR_STEPS", "3000"))   # budget at which vanilla@1e-3 plateaus (~65%)
LR = 1e-3
LR_HI = 0.1            # the "fixed higher lr" control mentioned in the prose
SOLVE_LOSS = 0.05
RUNS = "eos/runs"

X = torch.tensor([[0., 0.], [0., 1.], [1., 0.], [1., 1.]])
Y = torch.tensor([0, 1, 1, 0])


def net(seed):
    torch.manual_seed(seed)
    return nn.Sequential(nn.Linear(2, 2), nn.Tanh(), nn.Linear(2, 2))


def solved(model):
    with torch.no_grad():
        logits = model(X)
        acc = (logits.argmax(1) == Y).float().mean().item()
        loss = nn.functional.cross_entropy(logits, Y).item()
    return acc == 1.0 and loss < SOLVE_LOSS


def run(method, seed, K=10):
    model = net(seed).to(DEV)
    crit = nn.CrossEntropyLoss()
    if method == "vanilla":
        opt = torch.optim.Adam(model.parameters(), lr=LR)
        controlled = False
    elif method == "vanilla_hi":
        opt = torch.optim.Adam(model.parameters(), lr=LR_HI)
        controlled = False
    else:
        mode = "watchdog" if method == "watchdog" else "tracker"
        opt = AdamSLSControlled(model.parameters(), lr=LR, probe_every=K, mode=mode,
                                init_safety=0.25)
        controlled = True
    for _ in range(STEPS):
        def closure():
            opt.zero_grad(set_to_none=True)
            loss = crit(model(X), Y); loss.backward(); return loss

        @torch.no_grad()
        def eval_loss():
            return crit(model(X), Y)
        if controlled:
            opt.step(closure, eval_loss)
        else:
            closure(); opt.step()
        if solved(model):
            return True
    return solved(model)


def main():
    rows = []
    # vanilla + watchdog at a default K; tracker scans K and keeps the best.
    pct = {}
    for method in ["vanilla", "vanilla_hi", "watchdog"]:
        s = sum(run(method, sd) for sd in range(N_SEEDS))
        pct[method] = 100.0 * s / N_SEEDS
        rows.append(dict(method=method, K="-", solved=s, n=N_SEEDS,
                         pct=round(pct[method], 1)))
        print(f"{method:10s} K=-   solved {s}/{N_SEEDS} = {pct[method]:.0f}%", flush=True)
    best_tracker, best_K = -1.0, None
    for K in [5, 10, 20]:
        s = sum(run("tracker", sd, K=K) for sd in range(N_SEEDS))
        p = 100.0 * s / N_SEEDS
        rows.append(dict(method="tracker", K=K, solved=s, n=N_SEEDS, pct=round(p, 1)))
        print(f"tracker    K={K:<3d} solved {s}/{N_SEEDS} = {p:.0f}%", flush=True)
        if p > best_tracker:
            best_tracker, best_K = p, K
    pct["tracker"] = best_tracker
    os.makedirs(RUNS, exist_ok=True)
    with open(f"{RUNS}/xor_periodic.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["method", "K", "solved", "n", "pct"])
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"\nBEST: vanilla {pct['vanilla']:.0f}%  watchdog {pct['watchdog']:.0f}%  "
          f"tracker {best_tracker:.0f}% (K={best_K})")
    print(f"Saved {RUNS}/xor_periodic.csv")


if __name__ == "__main__":
    main()
