# Reproducing the experiments (Armijo curvature probe)

This directory contains the code and run drivers (plus, in the full
repository, the raw run outputs under `eos/runs/`) for the
empirical study reported in the manuscript (source not included in this archive; see arXiv:2607.03998)

> **Directional Curvature from Armijo Backtracking: A Low-Cost Sharpness
> Probe and a Calibration-Free Learning-Rate Safeguard for Adam**

Every table and figure in the paper is reproducible from this directory plus
the datasets created by `setup_data.py`. Run all commands **from the
repository root** (the scripts assume `eos/` and `data/` are siblings).

> **Note on `run_all.sh`.** `run_all.sh` reproduces only the *mechanism* part
> (the α↔λ₁ correlation runs, the master scatter, and the divergence-boundary
> sweep). It does **not** cover the main rescue results. The full paper is
> reproduced by the per-experiment drivers listed in Section 4 below.

## 1. Environment

```bash
conda env create -f eos/environment.yml      # creates env `eos-probe`
conda activate eos-probe
pip install pyhessian==0.1                    # not on conda
pip install schedulefree==1.4.1 prodigyopt==1.1.2  # parameter-free baselines
pip install datasets==5.0.0                   # AG News AND WikiText-103
pip install tiktoken==0.13.0                  # GPT-2 BPE (WikiText bins)
```
All five pip packages are also pinned in `environment.yml`.

Key versions (recorded in `environment.yml`): Python 3.11, PyTorch 2.8.0 +
CUDA 12.9, torchvision 0.24.0, PyHessian 0.1, numpy/scipy/scikit-learn/
pandas/matplotlib/seaborn (conda-forge).

## 2. Hardware used in this report

- 2 × NVIDIA RTX 6000 Ada Generation (48 GB each), CUDA driver 12.9.
- The classifier experiments fit easily in 8 GB of GPU memory; the GPT-2 runs
  (small/medium with Adam states, batch 16 x 512 tokens, bf16 autocast, no
  gradient checkpointing) need substantially more and were run on the 48 GB
  cards above. The drivers round-robin across the two GPUs but also run on one
  (`GPU0=0 GPU1=0`; note the two worker queues then share that GPU
  concurrently rather than serially).

## 3. Data

The `data/` folder may be shipped with the package or omitted. To (re)create
it:

```bash
python -m eos.setup_data                 # all five datasets
# or a subset:
python -m eos.setup_data --only cifar10
python -m eos.setup_data --only imagenette wikitext
```

- **CIFAR-10** is downloaded from the Toronto mirror
  (`https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz`) and extracted
  (the loaders use `download=False`).
- **Fashion-MNIST** is fetched by torchvision on demand.
- **AG News** builds a word vocabulary + tensor cache from the
  `fancyzhx/ag_news` HuggingFace dataset (needs `datasets` + network on the
  first run; cached afterwards).
- **Imagenette** (fastai ImageNet subset, 160px variant) is downloaded from
  `https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-160.tgz` and
  extracted to `data/imagenette2-160/{train,val}`; the loaders read it with
  `ImageFolder` and train at 128px. Needed only for the real-resolution
  control (`app:imagenette`).
- **WikiText-103** is the raw configuration `wikitext-103-raw-v1` of the
  HuggingFace dataset `Salesforce/wikitext`, tokenised once with the GPT-2 BPE
  (`tiktoken` encoding `"gpt2"`) into the uint16 memmaps
  `data/wikitext103_gpt2_{train,val}.bin` (~250 MB). Needed only for the
  language-model experiments (`tab:lm-rescue`); equivalent to running
  `python -m eos.lm` directly.
- The scikit-learn **digits** set is fetched on the fly, no setup needed.

## 4. Reproduction matrix (table/figure → driver → aggregator)

Each row: run the **driver** (produces `runs/…` directories), then the
**aggregator** (prints the LaTeX body / writes the figure). Every aggregator
script names its target `\label{}` in its header.

| Manuscript item | Driver (`bash eos/…`) | Aggregator (`python -m eos.…` / script) |
|---|---|---|
| Tab. `tab:rescue` (CIFAR-10, 5 seeds) | `run_cifar_seeds_kappa.sh`, `run_new_baselines.sh` | `summarize_adam_sls` |
| Tab. `tab:baselines` | `run_all.sh` (clip/warmup), `run_cifar_seeds_kappa.sh` | `summarize_adam_sls` |
| Tab. `tab:fashion-rescue` | `run_new_baselines.sh` | `summarize_fashion_calib` |
| Tab. `tab:agnews-rescue` | `run_agnews.sh` | `summarize_agnews` |
| Tab. `tab:correlation` | `run_mechanism_all.sh` (+ `run_mechanism_fashion.sh`) | `analyze` → `summarize_mechanism` (one call per architecture) |
| Tab. `tab:kappa` (divergence boundary, Sec. 5.5) | `run_all.sh` (fine-multiplier heredoc) | values printed by the heredoc; raw in `runs/divergence_*` |
| Tab. `tab:longrun` (100-epoch cosine) | `run_cosine100_full.sh` | `summarize_cosine100` |
| Tab. `tab:kappa-sens` (Appendix B) | `run_cifar_seeds_kappa.sh` (κ sweep) | `summarize_kappa` |
| Fig. `fig:rescue-headline` | `run_cifar_seeds_kappa.sh`, `run_new_baselines.sh` | `headline_plot.py` |
| Fig. `fig:rescue-loss`, `fig:lr-trace` | `run_cifar_seeds_kappa.sh`, `run_new_baselines.sh` | `summarize_adam_sls` |
| Fig. `fig:kappa-perarch` (per-architecture bars, main text) | (uses `kappa_universality.csv` + `kappa_sweep_adamdir.csv`) | `plot_kappa_perarch.py` |
| Fig. `fig:scatter` | `run_all.sh` (CIFAR-10 + digits line-search runs) | `master_scatter.py` (invoked by `run_all.sh`) |
| Fig. `fig:tracking` (1/α tracks λ₁ over training) | `run_mechanism_all.sh` (CIFAR-10 + Fashion pure-Armijo traces) | `sharpness_tracking.py` |
| Tab. `tab:fidelity` (sensor fidelity: β band, batch noise) | self-contained (trains a Fashion CNN, probes it) | `probe_fidelity.py` → `runs/probe_fidelity.csv` |
| Tab. `tab:universal-kappa` (single κ via Adam-direction probe, 9 archs; divergence + accuracy) | self-contained (builds 9 architectures) | `validate_kappa_universality.py` → `runs/kappa_universality.csv` |
| Tab. `tab:kappa-universal-sweep` (κ-sweep of the Adam-direction probe) | `run_kappa_sweep.py` (κ∈{1,2}; κ=3 from `kappa_universality.csv`) | `summarize_kappa_sweep` → `runs/kappa_sweep_summary.csv` |
| Tab. `tab:rangetest` (real LR range test vs one-shot probe, all four benchmarks) | `run_rangetest_all.py` (range-test arm; probe arm from the grid runs) | `summarize_rangetest_all` → `runs/rangetest_all_summary.csv` |
| Tab. `tab:lowcost-cross` (low-cost safeguards across all four benchmarks) | grid runs + `run_lowcost_baselines.sh` (missing arms) | `summarize_lowcost_baselines` → `runs/lowcost_baselines_summary.csv` |
| Tab. `tab:kappa-perarch` (per-architecture breakdown, appendix) | (uses `kappa_universality.csv`) | `summarize_kappa_perarch` → `runs/kappa_perarch_summary.csv` |
| Tab. `tab:default-unsafe` (no-norm ResNet, no-warmup 12-layer Transformer) | `run_default_unsafe.sh` | `summarize_default_unsafe` → `runs/default_unsafe_summary.csv` |
| Tab. `tab:periodic` (CIFAR/AG-News rows from the verified main sweep; XOR row fresh) | `run_xor_periodic.py` (XOR only) | `summarize_periodic` → `runs/periodic_summary.csv` |
| Sec. 5.4 prose (q vs λ₁, 73 % band) | `run_mechanism_all.sh` | `summarize_proposition` (console only) |
| Sec. "Cost analysis" (wall-clock overhead) | `run_overhead.sh` (interleaved, single session) | `summarize_overhead` → `runs/overhead_benchmark.csv` |
| Tab. `tab:correlation-detrended` (trend-robustness of the α–λ₁ correlation) | (uses the mechanism runs above) | `detrend_correlation` (one call per architecture) |
| Tab. `tab:retry` (retry-on-divergence baseline, simulated from grid runs) | (uses existing grid runs + logs) | `simulate_retry` → `runs/retry_baseline_summary.csv` |
| Tab. `tab:probe-variance` (cross-batch variance of the init probe) | `probe_batch_variance.py` (GPU, 4 benchmarks × 3 seeds × 50 batches) | `summarize_probe_variance` → reads `runs/probe_batch_variance.csv` |
| Tab. `tab:lm-rescue` (GPT-2 small/medium on WikiText-103, 6 arms) | `python -m eos.lm` (data prep, tiktoken) then `run_lm_grid.sh`, once per model size: `MODEL=small SEEDS="0 1" bash eos/run_lm_grid.sh` and `MODEL=medium SEEDS="0 1" bash eos/run_lm_grid.sh` (ARMS env selects arms) | `summarize_lm` → `runs/lm_rescue_summary.csv` |
| Fig. `fig:lm-sharpening` (α collapse in the first steps) | `lm_sharpening_curve.py` (lr 0.001 + 0.01) | `plot_lm_sharpening.py` |
| Sec. LM prose: size ladder κ* (16M–355M) | `lm_kappa_ladder.py` | writes `runs/lm_kappa_ladder.json` (console summary) |
| Method prose: probationary protocol on the 9-arch suite (two divergences in 54, the marginal MLP case) | `EOS_PROBATION=1 python -m eos.validate_kappa_universality` | writes `runs/probation_universality.csv` (extended-init probe, K=8 window; `runs/probation_universality_K8init.csv` is the negative control with K=8 init that fails on the no-norm ResNet) |
| App. `app:noop` (bit-exact no-op: paired state/first-update test + whole-run check at η = 10⁻³) | paired test is self-contained (`CUBLAS_WORKSPACE_CONFIG=:4096:8 python -m eos.no_op_paired_test`); the whole-run check reads the η = 10⁻³ grid runs above plus the evidence re-runs under `runs/_noop_fullrun_evidence/` (layout documented in the aggregator's header) | `no_op_paired_test` → `runs/no_op_paired_test.csv`; `summarize_noop_fullrun` → `runs/noop_fullrun_summary.csv` |

The figures referenced by the `.tex` are loaded from `results/figures/`
(frozen copies), so the paper compiles without re-running anything. Regenerate
them with the aggregators above if you re-run the experiments, then re-freeze.

## 4.1 Single source of truth (freeze + verify)

To keep the manuscript's tables synchronised with the data-derived outputs,
the result tables are backed by a frozen snapshot and checked against the
manuscript before release (21 of the 24 tables; `tab:protocol` is
descriptive, `tab:kappa` and `tab:imagenette` are verified by hand):

```bash
python -m eos.freeze_paper_data            # re-derive every table body + copy
                                           # CSVs/figures into results/
python results/verify_tables.py # flags any covered canonical number
                                           # missing from the .tex; in the
                                           # artifact, pass the manuscript path
                                           # as an argument (else it only lists
                                           # its coverage)
```

`freeze_paper_data` runs each aggregator, stores its canonical LaTeX body under
`results/tables_canonical/`, copies the source CSVs and the seven
figures into `results/`, and writes `PROVENANCE.md` with a truncated
sha256 (first 16 hex characters) per artefact. **Never hand-edit a table number**: change the data/run, re-run
`freeze_paper_data`, then `verify_tables.py`. Run `verify_tables.py` before every
submission.

### 4.2 Drivers at a glance

All drivers are idempotent (existing runs with a `summary.json` are skipped)
and round-robin across `GPU0`/`GPU1` (override via env vars). Override the
Python interpreter with `PY=…`.

- `run_mechanism_all.sh` — Pure-Armijo runs on CIFAR-10 + Fashion-MNIST
  (3 seeds) with λ₁/q/α_probe logging → `tab:correlation` and the Sec. 5.4
  prose. `run_mechanism_fashion.sh` is the Fashion-only subset. (The
  `fig:scatter` overlay uses the previous CIFAR-10 + digits line-search runs
  from `run_all.sh`, not these.)
- `run_cifar_seeds_kappa.sh` — extends the CIFAR controllers to 5 seeds (`tab:rescue`)
  and sweeps the safety factor κ (`tab:kappa-sens`).
- `run_new_baselines.sh` — Schedule-Free AdamW + Prodigy on CIFAR-10 and
  Fashion-MNIST (the parameter-free rows of `tab:rescue` / `tab:fashion-rescue`).
- `run_agnews.sh` — AG News / small-Transformer sweep (`tab:agnews-rescue`);
  set `KAPPA`/`TAG` for the calibrated block.
- `run_cosine100_full.sh` — 100-epoch cosine grid (`tab:longrun`);
  `run_cosine100.sh` runs only the three sanity cells.
- `run_all.sh` — mechanism + divergence-boundary sweep (see note at top).

## 5. Determinism and seeds

All runs set `torch.manual_seed`, `numpy.random.seed`, and a seeded DataLoader
generator at the start of training. CUDNN deterministic mode is **not** set, so
the last digit of test accuracy may differ between machines; the qualitative
findings (correlation strengths, divergence flags, controller behaviour) are
robust across the seeds we tested.

## 6. Outputs

Each run directory contains:
- `summary.json` — final accuracy, F1, wall-clock, `diverged` flag.
- `trace.csv` — one row per `probe_every`/`log_every` steps (step, epoch,
  loss, mean α, λ₁, and for mechanism runs `dir_curv_q`, `alpha_probe`).
- Controlled-Adam runs also write `controller_log.json` (α and lr histories).
- `analyze.py` additionally writes per-run `correlations.json` (+ diagnostic
  PNGs) — the input to `summarize_mechanism`.

## 7. Known caveats

- The `tracker` controller's coefficient `tracker_c` (default 0.25) was tuned
  by inspection of the divergence-sweep boundary; re-tuning on another
  architecture is expected.
- The per-experiment `summary.json` `wall_s` values include data loading and
  were collected across separate sessions, so they are NOT a reliable measure
  of probe overhead (some early runs ran on a loaded GPU). For overhead use the
  controlled interleaved benchmark `run_overhead.sh` instead: at `probe_every=50`
  the deployed (forward-only) controllers add ~1 % (Adam-InitOnly), ~2.7 %
  (Adam-Tracker) and ~5.3 % (Adam-Watchdog) of wall-clock over vanilla Adam.
- The divergence criterion (`loss > 5·initial` or NaN/Inf) is identical in
  `train_adam_sls.py` and `divergence.py` and matches the paper (Sec. 5.1).
- Language-model pretraining is covered up to GPT-2 medium (355M) on
  WikiText-103 (`tab:lm-rescue`; needs `pip install tiktoken` in the env and
  ~250 MB of token bins built by `python -m eos.lm`). Larger settings
  (ImageNet, billion-parameter LLMs) remain outside the single-GPU budget and
  are not claimed.

## 8. Citing

If you use this code, please cite the paper and PyHessian (Yao et al., 2020).
See the bibliography of the manuscript (source not included in this archive; see arXiv:2607.03998).
