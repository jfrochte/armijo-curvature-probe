#!/usr/bin/env bash
# Completes the low-cost baseline comparison (gradient-norm clipping,
# linear warmup, Schedule-Free AdamW, Prodigy) across all four benchmarks.
# CIFAR-10/ResNet-18 and Fashion-MNIST/CNN already have every arm from the
# main grids; this runs the missing arms with the identical protocol
# (same budgets, batch size and divergence rule as the grid runs):
#   AG News/Transformer : adam_clip, adam_warmup            (6 lr x 5 seeds)
#   Imagenette/ResNet-18: adam_clip, adam_warmup,
#                         adam_schedulefree, prodigy        (6 lr x 5 seeds)
# 180 runs total. Output follows the grid naming convention
# (runs/<dataset>_<opt>_lr<lr>_seed<sd>) so the existing summarizers apply.
#
# PARALLEL: jobs split round-robin (index parity) across two GPUs. Idempotent.
# Env overrides: PY, GPU0, GPU1, SEEDS, LRS.

set -uo pipefail
PY=${PY:-python}
GPU0=${GPU0:-0}
GPU1=${GPU1:-1}
SEEDS=${SEEDS:-"0 1 2 3 4"}
LRS=${LRS:-"0.001 0.01 0.1 0.3 1.0 3.0"}

cd "$(dirname "$0")/.."
mkdir -p eos/runs

# job = "dataset epochs opt lr seed"
JOBS=()
for opt in adam_clip adam_warmup; do
    for lr in $LRS; do
        for sd in $SEEDS; do
            JOBS+=("agnews 10 $opt $lr $sd")
        done
    done
done
for opt in adam_clip adam_warmup adam_schedulefree prodigy; do
    for lr in $LRS; do
        for sd in $SEEDS; do
            JOBS+=("imagenette 20 $opt $lr $sd")
        done
    done
done

run_one () {
    local gpu=$1 ds=$2 ep=$3 opt=$4 lr=$5 sd=$6
    local outdir="eos/runs/${ds}_${opt}_lr${lr}_seed${sd}"
    if [[ -f "$outdir/summary.json" ]]; then echo "[skip gpu$gpu] $outdir"; return; fi
    echo "[run  gpu$gpu] $outdir"
    "$PY" -m eos.train_adam_sls --dataset "$ds" --optimizer "$opt" \
        --epochs "$ep" --probe-every 50 --batch-size 256 --num-workers 4 \
        --gpu "$gpu" --seed "$sd" --lr "$lr" --outdir "$outdir" \
        > "${outdir}.log" 2>&1 || echo "[FAIL gpu$gpu] $outdir"
}

worker () {
    local gpu=$1 parity=$2 i=0
    for job in "${JOBS[@]}"; do
        if (( i % 2 == parity )); then
            # shellcheck disable=SC2086
            run_one "$gpu" $job
        fi
        i=$((i + 1))
    done
}

worker "$GPU0" 0 &
worker "$GPU1" 1 &
wait
echo "[done] run_lowcost_baselines: ${#JOBS[@]} jobs"
