# eos/summarize_adam_sls.py
#
# Reproduction artifact: produces runs/fig_adam_sls_loss_lr0.1.png and
#   runs/fig_adam_sls_lrtrace_lr0.1.png
#   -> Figures \label{fig:rescue-loss} and \label{fig:lr-trace}; the
#   aggregated CSV also feeds Tables \label{tab:rescue} and
#   \label{tab:baselines} in armijo_curvature_probe.tex.
#   Data: run_cifar_seeds_kappa.sh + run_new_baselines.sh + run_all.sh.
#
# Aggregate the CIFAR-10 Adam sweep (Adam / Watchdog / Tracker / InitOnly /
# Clip / Warmup / Schedule-Free / Prodigy x 6 lr x 5 seeds) and produce:
#   - a markdown/console table of mean +/- std test_acc and divergence rate
#   - a loss-vs-step plot for the lr=0.01 case (vanilla vs controllers)

import os, json, glob
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = "eos/runs"
# The direction-matched and AdamW rows are aggregated here as well, so every
# row of tab:rescue comes from one source with one summary convention and is
# covered by results/verify_tables.py.
OPTS = ["adam", "adam_init_only", "adam_watchdog", "adam_tracker",
        "adam_clip", "adam_warmup", "adam_schedulefree", "prodigy",
        "adam_init_dir", "adamw", "adamw_init_dir"]
LRS  = ["0.001", "0.01", "0.1", "0.3", "1.0", "3.0"]
SEEDS = [0, 1, 2, 3, 4]


def load(opt, lr, seed):
    d = f"{ROOT}/cifar_{opt}_lr{lr}_seed{seed}"
    sj = f"{d}/summary.json"
    cj = f"{d}/trace.csv"
    if not os.path.exists(sj):
        return None, None
    with open(sj) as f:
        s = json.load(f)
    df = pd.read_csv(cj) if os.path.exists(cj) else None
    return s, df


def aggregate():
    rows = []
    for opt in OPTS:
        for lr in LRS:
            accs, divs, walls = [], [], []
            for sd in SEEDS:
                s, _ = load(opt, lr, sd)
                if s is None:
                    continue
                accs.append(s["test_acc"] if not s["diverged"] else float("nan"))
                divs.append(int(s["diverged"]))
                walls.append(s["wall_s"])
            mean_acc = np.nanmean(accs) if any(not np.isnan(a) for a in accs) else float("nan")
            std_acc = np.nanstd(accs) if any(not np.isnan(a) for a in accs) else float("nan")
            div_rate = float(np.mean(divs)) if divs else float("nan")
            rows.append(dict(opt=opt, lr=lr,
                             mean_acc=mean_acc, std_acc=std_acc,
                             div_rate=div_rate,
                             mean_wall=float(np.mean(walls)) if walls else float("nan")))
    return pd.DataFrame(rows)


def print_table(df):
    print(f"\n{'Optimizer':<18} {'lr':<8} {'acc (mean±std)':<22} {'div_rate':<10} {'wall (s)':<10}")
    print("-" * 72)
    for _, r in df.iterrows():
        if np.isnan(r["mean_acc"]):
            acc_s = "DIVERGED (both seeds)"
        else:
            acc_s = f"{r['mean_acc']:.4f} ± {r['std_acc']:.4f}"
        print(f"{r['opt']:<18} {r['lr']:<8} {acc_s:<22} {r['div_rate']:<10.2f} {r['mean_wall']:<10.1f}")


def _agg_over_seeds(series_by_seed):
    """Align (steps, values) seed traces on their common steps and return
    (steps, mean, lo, hi). `series_by_seed` is a list of (steps, values)."""
    from collections import defaultdict
    by_step = defaultdict(list)
    for steps, vals in series_by_seed:
        for s, v in zip(steps, vals):
            if v is not None and np.isfinite(v):
                by_step[int(s)].append(float(v))
    if not by_step:
        return None
    steps = np.array(sorted(by_step))
    mean = np.array([np.mean(by_step[s]) for s in steps])
    lo = np.array([np.min(by_step[s]) for s in steps])
    hi = np.array([np.max(by_step[s]) for s in steps])
    return steps, mean, lo, hi


# Only the methods the figure is actually about: the divergent baseline and
# the three probe-controlled variants. Everything else lives in the tables.
_LOSS_CONFIG = [
    ("adam",           "Vanilla Adam",         "C3"),
    ("adam_init_only", "Adam-InitOnly (ours)", "C0"),
    ("adam_watchdog",  "Adam-Watchdog (ours)", "C9"),
    ("adam_tracker",   "Adam-Tracker (ours)",  "C2"),
]


def plot_loss_curves(lr="0.01", out="eos/runs/fig_adam_sls_lr01.png"):
    """Mini-batch training loss: divergent vanilla Adam vs the probe-controlled
    variants. One line per method (mean over seeds), shaded min--max band."""
    fig, ax = plt.subplots(figsize=(7, 4))

    # Reference: vanilla Adam at a well-tuned eta=1e-3 trains fine on this task.
    # Showing it makes clear that the divergence below is specific to the
    # misspecified eta_init, not a general failure of Adam on CIFAR-10.
    ref_traces = []
    for sd in SEEDS:
        _, df = load("adam", "0.001", sd)
        if df is not None and len(df) > 0:
            ref_traces.append((df["step"].values, df["loss"].values))
    ref = _agg_over_seeds(ref_traces)
    if ref is not None and lr != "0.001":
        rs, rm, _, _ = ref
        ax.plot(rs, rm, color="0.5", ls="--", lw=1.6,
                label=r"Vanilla Adam, tuned $\eta=10^{-3}$ (reference)")

    diverged_label = None
    for opt, label, color in _LOSS_CONFIG:
        traces, any_diverged = [], False
        for sd in SEEDS:
            s, df = load(opt, lr, sd)
            if s is not None and s.get("diverged"):
                any_diverged = True
            if df is None or len(df) == 0:
                continue
            traces.append((df["step"].values, df["loss"].values))
        agg = _agg_over_seeds(traces)
        if agg is None:
            # No loggable curve: the run diverged before the first logged step.
            if any_diverged:
                diverged_label = (label, color)
            continue
        steps, mean, lo, hi = agg
        ax.fill_between(steps, lo, hi, color=color, alpha=0.15, linewidth=0)
        ax.plot(steps, mean, color=color, linewidth=1.8, label=label)
    # A diverged baseline (e.g. vanilla Adam at a too-large eta) has no curve to
    # draw because it blows up before the first logged step; annotate it instead.
    if diverged_label is not None:
        label, color = diverged_label
        # Short upward marker at the left edge (loss leaves the top of the chart)
        # plus a plain label -- no connecting line that could read as a curve.
        ymin, ymax = ax.get_ylim()
        ax.annotate("", xy=(2, ymax), xytext=(2, ymax * 0.6),
                    arrowprops=dict(arrowstyle="-|>", color=color, lw=2.0))
        ax.text(0.045, 0.93, f"{label} diverges at step 2\n(loss " + r"$\to\infty$)",
                transform=ax.transAxes, color=color, fontsize=9, va="top")
        ax.plot([], [], color=color, lw=1.8, label=f"{label} (diverges)")
    ax.set_xlabel("Step")
    ax.set_ylabel("Training loss")
    ax.set_yscale("log")
    ax.set_title(rf"CIFAR-10 / ResNet-18, $\eta_{{\rm init}} = {lr}$")
    ax.legend(loc="upper right", frameon=True)
    ax.grid(True, which="both", alpha=0.2)
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print(f"[plot] {out}")


def plot_lr_traces(lr="0.01", out="eos/runs/fig_adam_sls_lr_traces.png"):
    """How the init cap and the two periodic controllers move Adam's learning
    rate: the init probe caps eta once before training, then the controllers
    adjust it online. One line per controller (mean over seeds), min--max band."""
    fig, ax = plt.subplots(figsize=(7, 4))
    cfg = [("adam_watchdog", "Adam-Watchdog", "C9"),
           ("adam_tracker", "Adam-Tracker", "C2")]
    capped = None
    for opt, label, color in cfg:
        traces = []
        for sd in SEEDS:
            cj = f"{ROOT}/cifar_{opt}_lr{lr}_seed{sd}/controller_log.json"
            if not os.path.exists(cj):
                continue
            lr_hist = json.load(open(cj)).get("lr_history", [])
            if not lr_hist:
                continue
            traces.append(([x[0] for x in lr_hist], [x[1] for x in lr_hist]))
            capped = lr_hist[0][1] if capped is None else capped
        agg = _agg_over_seeds(traces)
        if agg is None:
            continue
        steps, mean, lo, hi = agg
        ax.fill_between(steps, lo, hi, color=color, alpha=0.15, linewidth=0)
        ax.plot(steps, mean, color=color, linewidth=1.8, label=label)
    # Reference lines: the user's (too large) requested eta and the capped value.
    ax.axhline(float(lr), color="C3", ls="--", alpha=0.7,
               label=rf"requested $\eta_{{\rm init}}={lr}$ (diverges)")
    if capped is not None:
        ax.axhline(capped, color="gray", ls=":", alpha=0.7,
                   label=rf"init-cap $\approx {capped:.3g}$")
    ax.set_xlabel("Step")
    ax.set_ylabel(r"Adam learning rate $\eta$")
    ax.set_yscale("log")
    ax.set_title(rf"Controller-adjusted $\eta$, $\eta_{{\rm init}} = {lr}$")
    ax.legend(loc="lower right", fontsize=8)
    ax.grid(True, which="both", alpha=0.2)
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print(f"[plot] {out}")


if __name__ == "__main__":
    df = aggregate()
    print_table(df)
    df.to_csv("eos/runs/adam_sls_summary.csv", index=False)
    print("\nSaved eos/runs/adam_sls_summary.csv")
    for lr in ("0.001", "0.01", "0.1"):
        plot_loss_curves(lr=lr, out=f"eos/runs/fig_adam_sls_loss_lr{lr}.png")
        plot_lr_traces(lr=lr,   out=f"eos/runs/fig_adam_sls_lrtrace_lr{lr}.png")
