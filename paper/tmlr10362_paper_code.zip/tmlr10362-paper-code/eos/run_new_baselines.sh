#!/usr/bin/env bash
# Additional parameter-free baselines: Schedule-Free Adam and Prodigy, as extra rows
# in Table 1 (CIFAR-10/ResNet-18) and Table 3 (Fashion-MNIST/small CNN).
#
# Both are parameter-free / schedule-free modern optimisers and need no kappa
# calibration, so they slot in next to vanilla Adam. We sweep the same six
# initial learning rates and five seeds as the rest of the rescue tables; the
# output directory names match what eos/summarize_adam_sls.py (CIFAR) and
# eos/summarize_fashion.py (Fashion-MNIST) already look for, so the new rows
# appear automatically once these runs complete.
#
# PARALLEL: all jobs are split round-robin (by index parity) across two GPUs,
# which gives each GPU an equal mix of (slow) CIFAR and (fast) Fashion runs.
# Both per-GPU queues run concurrently; we wait for both, then aggregate.
#
# Idempotent: directories that already contain summary.json are skipped.
# Env overrides: PY (interpreter), GPU0 / GPU1 (CUDA devices), SEEDS, LRS.

set -uo pipefail   # NOT -e: a single diverging run must not abort the queue

PY=${PY:-python}
GPU0=${GPU0:-0}
GPU1=${GPU1:-1}
SEEDS=${SEEDS:-"0 1 2 3 4"}
LRS=${LRS:-"0.001 0.01 0.1 0.3 1.0 3.0"}

cd "$(dirname "$0")/.."   # project root
mkdir -p eos/runs

# ---- build the full job list: "dataset opt lr seed" ------------------------
JOBS=()
for dataset in cifar10 fashion_mnist; do
    for opt in adam_schedulefree prodigy; do
        for lr in $LRS; do
            for sd in $SEEDS; do
                JOBS+=("$dataset $opt $lr $sd")
            done
        done
    done
done

run_one () {
    local gpu=$1 dataset=$2 opt=$3 lr=$4 sd=$5
    local prefix; [[ "$dataset" == "cifar10" ]] && prefix=cifar || prefix=fashion
    local outdir="eos/runs/${prefix}_${opt}_lr${lr}_seed${sd}"
    if [[ -f "$outdir/summary.json" ]]; then
        echo "[skip gpu$gpu] $outdir"; return
    fi
    echo "[run  gpu$gpu] $outdir"
    "$PY" -m eos.train_adam_sls --dataset "$dataset" --optimizer "$opt" \
        --epochs 10 --probe-every 50 --batch-size 256 --num-workers 4 \
        --gpu "$gpu" --seed "$sd" --lr "$lr" --outdir "$outdir" \
        > "${outdir}.log" 2>&1 || echo "[FAIL gpu$gpu] $outdir (see ${outdir}.log)"
}

# ---- dispatch: even index -> GPU0 queue, odd index -> GPU1 queue -----------
worker () {
    local gpu=$1 parity=$2 i=0
    for job in "${JOBS[@]}"; do
        if (( i % 2 == parity )); then
            run_one "$gpu" $job
        fi
        ((i++))
    done
    echo "[worker gpu$gpu] done"
}

echo "=== launching ${#JOBS[@]} jobs across GPU$GPU0 and GPU$GPU1 ==="
worker "$GPU0" 0 &
P0=$!
worker "$GPU1" 1 &
P1=$!
wait $P0 $P1
echo "=== all queues finished ==="

# ---- aggregate (new rows now included) -------------------------------------
echo "=== Aggregating ==="
"$PY" -m eos.summarize_adam_sls
"$PY" -m eos.summarize_fashion

echo "Done. New rows: adam_schedulefree, prodigy in both summary tables."
