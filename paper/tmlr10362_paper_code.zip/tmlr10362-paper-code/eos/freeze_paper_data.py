"""eos/freeze_paper_data.py

SINGLE SOURCE OF TRUTH for the manuscript's tables and figures.

Runs every table aggregator, captures its canonical (data-derived) LaTeX body,
and writes it to  results/tables_canonical/<label>.body.tex .
Copies the source CSVs and the seven figures into  results/ , and
writes PROVENANCE.md with a truncated sha256 (first 16 hex chars) of every frozen artefact plus the command
that produced it.

After running this, results/ is a frozen, self-contained snapshot of
exactly the numbers/figures the paper should contain. verify_tables.py then
checks the live .tex against this snapshot and flags any drift. Re-run this
script whenever the underlying runs change; never hand-edit a table without
re-running it.

Usage:  python -m eos.freeze_paper_data
"""
import os, sys, subprocess, hashlib, shutil, datetime

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUNS = os.path.join(REPO, "eos", "runs")
OUT = os.path.join(REPO, "results")
TAB = os.path.join(OUT, "tables_canonical")
FIG = os.path.join(OUT, "figures")
PY = sys.executable

# table label -> aggregator command (stdout captured); body extracted between the
# first \toprule/\midrule data region markers by verify (we store full stdout).
AGGREGATORS = {
    "tab:fashion-rescue":  [PY, "-m", "eos.summarize_fashion_calib"],
    "tab:agnews-rescue":   [PY, "-m", "eos.summarize_agnews"],
    "tab:kappa-sens":      [PY, "-m", "eos.summarize_kappa"],
    "tab:longrun":         [PY, "-m", "eos.summarize_cosine100"],
    "tab:default-unsafe":  [PY, "-m", "eos.summarize_default_unsafe"],
    "tab:periodic":        [PY, "-m", "eos.summarize_periodic"],
    "tab:kappa-universal-sweep": [PY, "-m", "eos.summarize_kappa_sweep"],
    # Range test vs probe, extended to all four benchmarks
    # (range-test arm via eos/run_rangetest_all.py).
    "tab:rangetest":       [PY, "-m", "eos.summarize_rangetest_all"],
    # Low-cost safeguards across all four benchmarks (missing arms
    # produced by eos/run_lowcost_baselines.sh).
    "tab:lowcost-cross":   [PY, "-m", "eos.summarize_lowcost_baselines"],
    "tab:kappa-perarch":   [PY, "-m", "eos.summarize_kappa_perarch"],
    # Retry-on-divergence baseline, simulated
    # from the existing grid runs (worst-case start eta=3.0).
    "tab:retry":           [PY, "-m", "eos.simulate_retry", "3.0"],
    # Cross-batch variance of the init probe;
    # summarizes the CSV written by the GPU measurement eos/probe_batch_variance.py.
    "tab:probe-variance":  [PY, "-m", "eos.summarize_probe_variance"],
    # Scale extension: GPT-2 pretraining
    # rescue grid on WikiText-103 (runs via eos/run_lm_grid.sh).
    "tab:lm-rescue":       [PY, "-m", "eos.summarize_lm"],
    # Genuine held-out validation of the fixed
    # kappa=2 (ViT / GRU / MobileNetV2; runs via eos/heldout_kappa2.py).
    "tab:heldout-kappa2":  [PY, "-m", "eos.summarize_heldout"],
    # Correlation under the stricter protocol
    # (ceiling-censored points excluded, autocorrelation-robust p) on both
    # trajectory types (runs via eos/run_fixed_mechanism.sh).
    "tab:correlation-robust": [PY, "-m", "eos.summarize_fixed_mechanism", "--paper"],
}
# tab:correlation is five rows, one aggregator call each:
MECH = {
    "tab:correlation": [
        [PY, "-m", "eos.summarize_mechanism", "eos/runs/cifar10_ggao_armijo_seed", "0", "1", "2"],
        [PY, "-m", "eos.summarize_mechanism", "eos/runs/fashion_ggao_armijo_seed", "0", "1", "2"],
        [PY, "-m", "eos.summarize_mechanism", "eos/runs/imagenette_ggao_armijo_seed", "0", "1", "2"],
        [PY, "-m", "eos.summarize_mechanism", "eos/runs/digits_ggao_armijo_seed", "0"],
        [PY, "-m", "eos.summarize_mechanism", "eos/runs/cifar10_ggao_gs_armijo_seed", "0"],
    ],
    # Trend-robustness check of tab:correlation.
    "tab:correlation-detrended": [
        [PY, "-m", "eos.detrend_correlation", "eos/runs/cifar10_ggao_armijo_seed", "0", "1", "2"],
        [PY, "-m", "eos.detrend_correlation", "eos/runs/fashion_ggao_armijo_seed", "0", "1", "2"],
        [PY, "-m", "eos.detrend_correlation", "eos/runs/imagenette_ggao_armijo_seed", "0", "1", "2"],
    ],
}
# tables read directly from a source CSV (no aggregator):
CSV_TABLES = {
    "tab:rescue":          "adam_sls_summary.csv",
    "tab:baselines":       "adam_sls_summary.csv",
    "tab:universal-kappa": "kappa_universality.csv",
    "tab:fidelity":        "probe_fidelity.csv",
}
FIGURES = [
    "fig_master_scatter.png", "fig_sharpness_tracking.png",
    "fig_rescue_headline.png", "fig_adam_sls_loss_lr0.1.png",
    "fig_adam_sls_lrtrace_lr0.1.png", "fig_kappa_perarch.png",
    "fig_lm_sharpening.png",
]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(65536), b""):
            h.update(b)
    return h.hexdigest()


def run(cmd):
    r = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True)
    if r.returncode != 0:
        return f"% AGGREGATOR FAILED: {' '.join(cmd)}\n{r.stderr}"
    return r.stdout


def main():
    os.makedirs(TAB, exist_ok=True); os.makedirs(FIG, exist_ok=True)
    prov = ["# PROVENANCE — frozen paper data\n",
            f"Generated {datetime.datetime.now(datetime.timezone.utc).isoformat()} "
            "by eos/freeze_paper_data.py (do not hand-edit).\n",
            "\n## Canonical table bodies (data-derived)\n"]

    for label, cmd in AGGREGATORS.items():
        body = run(cmd)
        fn = os.path.join(TAB, label.replace(":", "_") + ".body.tex")
        open(fn, "w").write(body)
        prov.append(f"- `{label}` <- `{' '.join(cmd[2:])}` (sha256/16 {sha(fn)[:16]})\n")

    for label, cmds in MECH.items():
        body = "\n".join(run(c) for c in cmds)
        fn = os.path.join(TAB, label.replace(":", "_") + ".body.tex")
        open(fn, "w").write(body)
        prov.append(f"- `{label}` <- summarize_mechanism x{len(cmds)} (sha256/16 {sha(fn)[:16]})\n")

    prov.append("\n## Source CSVs (copied verbatim)\n")
    for label, csvname in CSV_TABLES.items():
        src = os.path.join(RUNS, csvname); dst = os.path.join(OUT, csvname)
        if os.path.exists(src):
            shutil.copy2(src, dst)
            prov.append(f"- `{label}` <- `eos/runs/{csvname}` (sha256/16 {sha(dst)[:16]})\n")
    # also freeze the new-experiment CSVs
    for extra in ["default_unsafe_summary.csv", "periodic_summary.csv", "xor_periodic.csv",
                  "kappa_sweep_adamdir.csv", "kappa_sweep_summary.csv",
                  "lr_rangetest_all.csv", "rangetest_all_summary.csv",
                  "lowcost_baselines_summary.csv",
                  "kappa_perarch_summary.csv",
                  "retry_baseline_summary.csv", "probe_batch_variance.csv",
                  "lm_rescue_summary.csv", "lm_kappa_ladder.json",
                  "probation_universality.csv",
                  # Held-out kappa=2, bit-exact no-op verification,
                  # per-run records of the suite re-runs.
                  "heldout_kappa2.csv", "no_op_paired_test.csv",
                  "rerun_suite_protocols.csv",
                  # Criterion unification: 5x sweep columns, the MLP margin
                  # check, and the archived 8x-criterion runs, kept for
                  # comparison.
                  "rerun_sweep_k12.csv", "mlp_margin_check.csv",
                  "kappa_universality_8xcriterion.csv",
                  "kappa_sweep_adamdir_8xcriterion.csv",
                  "probation_universality_8xcriterion.csv",
                  "heldout_kappa2_8xcriterion.csv",
                  "rerun_suite_protocols_8xcriterion.csv"]:
        src = os.path.join(RUNS, extra)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(OUT, extra))
            prov.append(f"- (data) `eos/runs/{extra}` (sha256/16 {sha(os.path.join(OUT, extra))[:16]})\n")

    prov.append("\n## Figures (copied verbatim)\n")
    for fig in FIGURES:
        src = os.path.join(RUNS, fig); dst = os.path.join(FIG, fig)
        if os.path.exists(src):
            shutil.copy2(src, dst)
            prov.append(f"- `{fig}` (sha256/16 {sha(dst)[:16]})\n")
        else:
            prov.append(f"- `{fig}` MISSING in eos/runs\n")

    # DATA_PROVENANCE.md is hand-maintained (dataset revisions + checksums of
    # the derived inputs); it is not regenerated here, only listed.
    dp = os.path.join(OUT, "DATA_PROVENANCE.md")
    if os.path.exists(dp):
        prov.append(f"\n## Data provenance\n- `DATA_PROVENANCE.md` "
                    f"(dataset revisions + derived-input checksums, sha256 {sha(dp)[:16]})\n")

    open(os.path.join(OUT, "PROVENANCE.md"), "w").write("".join(prov))
    print("Froze table bodies + CSVs + figures into", OUT)
    print("Wrote", os.path.join(OUT, "PROVENANCE.md"))


if __name__ == "__main__":
    main()
