# eos/train_adam_sls.py
#
# Reproduction artifact: the main rescue driver. Produces the runs behind Tables
#   \label{tab:rescue}, \label{tab:baselines}, \label{tab:fashion-rescue},
#   \label{tab:agnews-rescue}, \label{tab:longrun}, \label{tab:kappa-sens}
#   and Figures fig:rescue-headline / fig:rescue-loss / fig:lr-trace /
#   fig:fashion-headline. Drivers: run_cifar_seeds_kappa.sh, run_new_baselines.sh,
#   run_agnews.sh, run_cosine100_full.sh.
#
# Training script comparing vanilla Adam against AdamSLSControlled on
# CIFAR-10/ResNet-18, including a "bad initial lr" challenge that vanilla Adam
# cannot survive but the controller is supposed to rescue.

import os, sys, json, time, argparse, csv, math
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, f1_score

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.adam_sls import AdamSLSControlled
from eos.data import (cifar_resnet18, make_cifar10_loaders,
                      DigitsMLP, make_digits_loaders,
                      FashionCNN, make_fashion_mnist_loaders,
                      AGNewsTransformer, make_agnews_loaders,
                      imagenette_resnet18, make_imagenette_loaders)


def evaluate(model, loader, device):
    model.eval()
    yt, yp = [], []
    with torch.no_grad():
        for X, y in loader:
            X = X.to(device, non_blocking=True)
            yp.extend(model(X).argmax(1).cpu().numpy())
            yt.extend(y.numpy())
    return accuracy_score(yt, yp), f1_score(yt, yp, average="macro")


def make_optimizer(name, params, lr, probe_every, init_safety=0.25, model=None):
    """Returns (optimizer, is_controlled, extras_dict)."""
    extras = {}
    if name == "adam":
        return torch.optim.Adam(params, lr=lr), False, extras
    if name == "adam_clip":
        extras["clip_grad_norm"] = 1.0
        return torch.optim.Adam(params, lr=lr), False, extras
    if name == "adam_warmup":
        extras["warmup_steps"] = 200
        extras["warmup_target_lr"] = lr
        # actual optimizer starts at lr/100 and ramps linearly to lr over 200 steps
        return torch.optim.Adam(params, lr=lr / 100.0), False, extras
    if name == "adam_init_only":
        return AdamSLSControlled(params, lr=lr, probe_every=probe_every, model=model,
                                 mode="init_only", init_safety=init_safety), True, extras
    if name == "adam_init_dir":
        # direction-matched init probe along Adam's own update direction
        # (recommended deployment variant; pass --init-safety 2.0)
        return AdamSLSControlled(params, lr=lr, probe_every=probe_every, model=model,
                                 mode="init_only", init_safety=init_safety,
                                 probe_direction="adam"), True, extras
    if name == "adamw":
        return torch.optim.AdamW(params, lr=lr), False, extras
    if name == "adamw_init_dir":
        # AdamW base + direction-matched init probe (transfer check)
        return AdamSLSControlled(params, lr=lr, probe_every=probe_every, model=model,
                                 mode="init_only", init_safety=init_safety,
                                 probe_direction="adam", base="adamw"), True, extras
    if name == "adam_init_dir_probation":
        # Direction-matched init probe + probationary re-probes over the first
        # ~50 steps (monotone cap at init_safety * min alpha). LM extension
        # (see train_lm.py PROBATION_STEPS); on the classifier suite this is
        # expected to be a no-op because the init reading already sits at the
        # backtracking floor beta^K (tab:probe-variance).
        return AdamSLSControlled(params, lr=lr, probe_every=probe_every, model=model,
                                 mode="init_only", init_safety=init_safety,
                                 probe_direction="adam"), True, extras
    if name == "adam_watchdog":
        return AdamSLSControlled(params, lr=lr, probe_every=probe_every, model=model,
                                 mode="watchdog", init_safety=init_safety), True, extras
    if name == "adam_tracker":
        return AdamSLSControlled(params, lr=lr, probe_every=probe_every, model=model,
                                 mode="tracker", init_safety=init_safety), True, extras
    if name == "adam_schedulefree":
        # Schedule-Free AdamW (Defazio et al., 2024). Drop-in optimiser, but its
        # weight averaging requires optimizer.train()/optimizer.eval() around the
        # training loop and evaluation respectively (handled in train()).
        import schedulefree
        extras["schedulefree"] = True
        return schedulefree.AdamWScheduleFree(params, lr=lr), False, extras
    if name == "prodigy":
        # Prodigy (Mishchenko & Defazio, 2023), a parameter-free learner. lr is a
        # multiplier on the adapted step (default 1.0); we sweep it like every other
        # optimiser so this row fills the same 6-lr robustness matrix.
        import prodigyopt
        return prodigyopt.Prodigy(params, lr=lr), False, extras
    raise ValueError(name)


def train(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.cuda.set_device(args.gpu)
    torch.manual_seed(args.seed); np.random.seed(args.seed)

    if args.dataset == "cifar10":
        train_loader, test_loader = make_cifar10_loaders(
            batch_size=args.batch_size, num_workers=args.num_workers, seed=args.seed)
        model = cifar_resnet18(num_classes=10,
                               norm=not getattr(args, "no_norm", False)).to(device)
    elif args.dataset == "fashion_mnist":
        train_loader, test_loader = make_fashion_mnist_loaders(
            batch_size=args.batch_size, num_workers=args.num_workers, seed=args.seed)
        model = FashionCNN(num_classes=10).to(device)
    elif args.dataset == "agnews":
        train_loader, test_loader, vocab_eff = make_agnews_loaders(
            batch_size=args.batch_size, num_workers=args.num_workers, seed=args.seed)
        model = AGNewsTransformer(vocab_eff, num_classes=4,
                                  num_layers=getattr(args, "tf_layers", 4)).to(device)
    elif args.dataset == "imagenette":
        train_loader, test_loader = make_imagenette_loaders(
            batch_size=args.batch_size, num_workers=args.num_workers, seed=args.seed)
        model = imagenette_resnet18(num_classes=10).to(device)
    else:
        train_loader, test_loader = make_digits_loaders(
            batch_size=args.batch_size, seed=args.seed)
        model = DigitsMLP(hidden=64, num_classes=10).to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer, is_controlled, extras = make_optimizer(
        args.optimizer, model.parameters(), args.lr, args.probe_every,
        init_safety=args.init_safety, model=model)
    clip_grad_norm = extras.get("clip_grad_norm", None)
    warmup_steps = extras.get("warmup_steps", 0)
    warmup_target_lr = extras.get("warmup_target_lr", args.lr)
    schedulefree = extras.get("schedulefree", False)
    cosine = getattr(args, "cosine", False)
    total_steps = args.epochs * len(train_loader)
    cosine_base_lr = None  # captured after the lr is finalised (post init-cap)

    os.makedirs(args.outdir, exist_ok=True)
    csv_path = os.path.join(args.outdir, "trace.csv")
    csv_f = open(csv_path, "w", newline="")
    writer = csv.DictWriter(csv_f, fieldnames=["step", "epoch", "wall_s",
                                               "loss", "lr", "alpha"])
    writer.writeheader()

    print(f"[run] dataset={args.dataset} opt={args.optimizer} lr_init={args.lr} "
          f"epochs={args.epochs} bs={args.batch_size} probe_every={args.probe_every} "
          f"seed={args.seed} outdir={args.outdir}", flush=True)

    t0 = time.time()
    step = 0
    diverged = False
    initial_loss = None

    for ep in range(args.epochs):
        model.train()
        if schedulefree:
            optimizer.train()  # Schedule-Free: switch to training (y) iterate
        for Xb, yb in train_loader:
            Xb = Xb.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)

            def closure():
                optimizer.zero_grad(set_to_none=True)
                loss = criterion(model(Xb), yb)
                loss.backward()
                return loss

            # Forward-only loss for the Armijo backtracking trials in the probe:
            # no gradient, so each trial costs only a forward pass.
            @torch.no_grad()
            def eval_loss():
                return criterion(model(Xb), yb)

            if is_controlled:
                # EOS_PROBE_FORWARD_ONLY=0 selects the forward+backward
                # reference variant of the backtracking (for overhead
                # benchmarking only); the default is the forward-only probe
                # described in the paper.
                if os.environ.get("EOS_PROBE_FORWARD_ONLY", "1") == "0":
                    loss_t = optimizer.step(closure)
                else:
                    loss_t = optimizer.step(closure, eval_loss)
            else:
                loss_t = closure()
                if clip_grad_norm is not None:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), clip_grad_norm)
                optimizer.step()
            step += 1
            # Probationary re-probes (adam_init_dir_probation): tighten the cap
            # to init_safety * min(alpha) during the first steps; same schedule
            # as train_lm.py PROBATION_STEPS.
            if (args.optimizer == "adam_init_dir_probation"
                    and step in {1, 2, 3, 5, 8, 12, 20, 35, 50}):
                optimizer._probe_at_current_params(closure, eval_loss)
                _target = args.init_safety * min(a for _, a in optimizer.alpha_history)
                if optimizer.current_lr > _target:
                    print(f"[probation] step={step} alpha={optimizer.last_alpha:.5g} "
                          f"cap {optimizer.current_lr:.5g} -> {_target:.5g}", flush=True)
                    optimizer._set_lr(_target)
            # linear warmup adjustment for adam_warmup baseline
            if warmup_steps > 0 and step <= warmup_steps and not is_controlled:
                ramp = step / warmup_steps
                cur = (1 - ramp) * (warmup_target_lr / 100.0) + ramp * warmup_target_lr
                for g in optimizer.param_groups:
                    g["lr"] = cur

            # Cosine annealing: anneal from the finalised base lr to ~0.
            # For controlled init_only the base is captured AFTER the init-cap has
            # fired on step 1; periodic controllers (watchdog/tracker) are excluded.
            if cosine and not (is_controlled and optimizer.mode in ("watchdog", "tracker")):
                if cosine_base_lr is None:
                    cosine_base_lr = (optimizer.current_lr if is_controlled
                                      else optimizer.param_groups[0]["lr"])
                factor = 0.5 * (1.0 + math.cos(math.pi * min(step / max(total_steps, 1), 1.0)))
                new_lr = cosine_base_lr * factor
                if is_controlled:
                    optimizer._set_lr(new_lr)
                else:
                    for g in optimizer.param_groups:
                        g["lr"] = new_lr

            cur_loss = float(loss_t.detach()) if torch.is_tensor(loss_t) else float(loss_t)
            if initial_loss is None:
                initial_loss = cur_loss
            cur_lr = (optimizer.current_lr if is_controlled
                      else optimizer.param_groups[0]["lr"])
            cur_alpha = (optimizer.last_alpha if is_controlled else float("nan"))

            if step % args.log_every == 0:
                writer.writerow({
                    "step": step, "epoch": ep + 1, "wall_s": time.time() - t0,
                    "loss": cur_loss, "lr": cur_lr, "alpha": cur_alpha,
                })
                csv_f.flush()

            # Divergence criterion matches the paper (Sec. 5.1) and
            # eos/divergence.py: loss exceeds 5x its initial value, or NaN/Inf.
            if not np.isfinite(cur_loss) or cur_loss > 5 * initial_loss:
                print(f"[diverged] step={step} loss={cur_loss:.4f}", flush=True)
                diverged = True
                break
            # Optional short-protocol cap (tab:default-unsafe uses 600 steps).
            if getattr(args, "max_steps", 0) and step >= args.max_steps:
                break
        if diverged or (getattr(args, "max_steps", 0) and step >= args.max_steps):
            break
        print(f"[ep {ep+1}/{args.epochs}] loss={cur_loss:.4f} lr={cur_lr:.2e} "
              f"alpha={cur_alpha if cur_alpha == cur_alpha else float('nan'):.4f}",
              flush=True)

    elapsed = time.time() - t0

    if diverged:
        acc, f1 = float("nan"), float("nan")
    else:
        if schedulefree:
            optimizer.eval()  # Schedule-Free: switch to the averaged (x) iterate
        acc, f1 = evaluate(model, test_loader, device)

    summary = {
        "dataset": args.dataset, "optimizer": args.optimizer,
        "lr_initial": args.lr, "epochs": args.epochs,
        "batch_size": args.batch_size, "probe_every": args.probe_every,
        "seed": args.seed, "diverged": diverged,
        "test_acc": acc, "test_f1": f1, "wall_s": elapsed,
        "no_norm": getattr(args, "no_norm", False),
        "tf_layers": getattr(args, "tf_layers", 4),
        "max_steps": getattr(args, "max_steps", 0),
        "init_safety": args.init_safety,
    }
    with open(os.path.join(args.outdir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    csv_f.close()

    if is_controlled:
        with open(os.path.join(args.outdir, "controller_log.json"), "w") as f:
            json.dump({"alpha_baseline": optimizer.alpha_baseline,
                       "alpha_history": optimizer.alpha_history,
                       "lr_history": optimizer.lr_history}, f)

    print(f"[done] diverged={diverged} acc={acc} f1={f1} wall={elapsed:.1f}s",
          flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", choices=["cifar10", "digits", "fashion_mnist", "agnews", "imagenette"], default="cifar10")
    p.add_argument("--optimizer",
                   choices=["adam", "adam_clip", "adam_warmup",
                            "adam_init_only", "adam_init_dir",
                            "adam_init_dir_probation",
                            "adamw", "adamw_init_dir",
                            "adam_watchdog", "adam_tracker",
                            "adam_schedulefree", "prodigy"],
                   required=True)
    p.add_argument("--init-safety", type=float, default=0.25,
                   help="kappa: cap user's lr at kappa * alpha_init from init probe")
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--probe-every", type=int, default=50)
    p.add_argument("--log-every", type=int, default=20)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--cosine", action="store_true",
                   help="cosine-anneal the (finalised) lr to ~0 over all epochs")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--gpu", type=int, default=0)
    p.add_argument("--no-norm", action="store_true",
                   help="cifar10 only: strip all BatchNorm (normalisation-free net)")
    p.add_argument("--tf-layers", type=int, default=4,
                   help="agnews only: number of Transformer encoder layers")
    p.add_argument("--max-steps", type=int, default=0,
                   help="stop after this many steps (0 = full epochs); short protocol")
    p.add_argument("--outdir", required=True)
    args = p.parse_args()
    train(args)
