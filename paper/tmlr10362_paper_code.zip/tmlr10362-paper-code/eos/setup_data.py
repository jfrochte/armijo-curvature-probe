#!/usr/bin/env python
"""Organise the ``data/`` directory needed by the experiments.

The repository ships *without* the bulky ``data/`` folder. This script
(re)creates everything the training code expects at ``<repo>/data`` (the
``DATA_ROOT`` computed in :mod:`eos.data`):

* CIFAR-10   -- downloaded from the canonical Toronto mirror and extracted,
                because :func:`eos.data.make_cifar10_loaders` uses
                ``download=False``.
* FashionMNIST -- fetched via torchvision (``download=True``).
* AG News    -- vocabulary + tensor cache built from the ``fancyzhx/ag_news``
                HuggingFace dataset (needs the ``datasets`` package + network).
* Imagenette -- the fastai ImageNet subset, 160px variant, downloaded from the
                fast.ai S3 mirror and extracted to ``imagenette2-160/``
                (:func:`eos.data.make_imagenette_loaders` reads it with
                ``ImageFolder`` and trains at 128px).
* WikiText-103 -- the raw configuration ``wikitext-103-raw-v1`` of the
                HuggingFace dataset ``Salesforce/wikitext``, tokenised once
                with the GPT-2 BPE (``tiktoken`` encoding ``"gpt2"``) into the
                uint16 memmaps ``wikitext103_gpt2_{train,val}.bin`` used by
                the language-model experiments (needs ``tiktoken`` +
                ``datasets``; ~250 MB of token bins).

The script is idempotent: anything already present is skipped. Run it once
before reproducing the experiments if you received the package without the
``data/`` folder::

    python -m eos.setup_data           # all five datasets
    python -m eos.setup_data --only cifar10
    python -m eos.setup_data --only imagenette wikitext

The two large ones are also the two optional ones: ``imagenette`` is needed
only for the real-resolution control, ``wikitext`` only for the GPT-2
pretraining experiments.
"""
import argparse
import os
import sys
import tarfile
import urllib.request

from eos.data import DATA_ROOT

CIFAR_URL = "https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz"
CIFAR_DIR = os.path.join(DATA_ROOT, "cifar-10-batches-py")
CIFAR_TGZ = os.path.join(DATA_ROOT, "cifar-10-python.tar.gz")

IMAGENETTE_URL = "https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-160.tgz"
IMAGENETTE_DIR = os.path.join(DATA_ROOT, "imagenette2-160")
IMAGENETTE_TGZ = os.path.join(DATA_ROOT, "imagenette2-160.tgz")


def setup_cifar10():
    if os.path.isdir(CIFAR_DIR):
        print(f"[cifar10] already present at {CIFAR_DIR} -- skip")
        return
    os.makedirs(DATA_ROOT, exist_ok=True)
    if not os.path.isfile(CIFAR_TGZ):
        print(f"[cifar10] downloading {CIFAR_URL}")
        urllib.request.urlretrieve(CIFAR_URL, CIFAR_TGZ)
    print(f"[cifar10] extracting into {DATA_ROOT}")
    with tarfile.open(CIFAR_TGZ) as tf:
        tf.extractall(DATA_ROOT)
    print("[cifar10] done")


def setup_fashion():
    from eos.data import make_fashion_mnist_loaders
    print("[fashion] fetching via torchvision (download=True)")
    make_fashion_mnist_loaders(batch_size=128, num_workers=0)
    print("[fashion] done")


def setup_agnews():
    from eos.data import make_agnews_loaders
    print("[agnews] building vocab + tensor cache from fancyzhx/ag_news")
    make_agnews_loaders(batch_size=256, num_workers=0)
    print("[agnews] done")


def setup_imagenette():
    if os.path.isdir(os.path.join(IMAGENETTE_DIR, "train")):
        print(f"[imagenette] already present at {IMAGENETTE_DIR} -- skip")
        return
    os.makedirs(DATA_ROOT, exist_ok=True)
    if not os.path.isfile(IMAGENETTE_TGZ):
        print(f"[imagenette] downloading {IMAGENETTE_URL}")
        urllib.request.urlretrieve(IMAGENETTE_URL, IMAGENETTE_TGZ)
    print(f"[imagenette] extracting into {DATA_ROOT}")
    with tarfile.open(IMAGENETTE_TGZ) as tf:
        tf.extractall(DATA_ROOT)
    print("[imagenette] done")


def setup_wikitext():
    """GPT-2-BPE token bins for the language-model experiments."""
    from eos.lm import TRAIN_BIN, VAL_BIN, prepare_wikitext103
    if os.path.isfile(TRAIN_BIN) and os.path.isfile(VAL_BIN):
        print(f"[wikitext] token bins already present in {DATA_ROOT} -- skip")
        return
    os.makedirs(DATA_ROOT, exist_ok=True)  # fresh checkout: data/ may not exist
    print("[wikitext] tokenising Salesforce/wikitext (wikitext-103-raw-v1) "
          "with the GPT-2 BPE via tiktoken")
    prepare_wikitext103()
    print("[wikitext] done")


SETUPS = {
    "cifar10": setup_cifar10,
    "fashion": setup_fashion,
    "agnews": setup_agnews,
    "imagenette": setup_imagenette,
    "wikitext": setup_wikitext,
}


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", choices=sorted(SETUPS), nargs="+",
                    help="only set up the named dataset(s); default: all")
    args = ap.parse_args()

    targets = args.only or list(SETUPS)
    print(f"DATA_ROOT = {DATA_ROOT}")
    failed = []
    for name in targets:
        try:
            SETUPS[name]()
        except Exception as exc:  # noqa: BLE001 -- report, continue, fail at end
            print(f"[{name}] FAILED: {exc}", file=sys.stderr)
            failed.append(name)
    if failed:
        print(f"setup_data finished WITH FAILURES: {', '.join(failed)}",
              file=sys.stderr)
        sys.exit(1)
    print("setup_data finished.")


if __name__ == "__main__":
    main()
