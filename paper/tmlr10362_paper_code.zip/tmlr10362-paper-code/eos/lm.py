# eos/lm.py
#
# Reproduction artifact: GPT-2-style causal
# language model + WikiText-103 data
# preparation for the language-model rescue experiment (tab:lm-rescue).
#
# Model: standard decoder-only transformer in the GPT-2 configuration
# (learned positional embeddings, pre-LN blocks, GELU MLP with 4x expansion,
# tied input/output embeddings, init N(0, 0.02) with 1/sqrt(2L) residual
# scaling). "small" = 12L/768d/12h (~124M params), "medium" = 24L/1024d/16h
# (~355M params). Attention uses torch's scaled_dot_product_attention with
# is_causal=True.
#
# Data: WikiText-103 (raw), GPT-2 BPE via tiktoken, tokenised once into
# uint16 memmaps  data/wikitext103_gpt2_{train,val}.bin . Non-empty lines are
# concatenated into one token stream per split with a single <|endoftext|>
# appended at the end of the split (no per-document separators; the frozen
# results are computed on exactly this stream). Run  python -m eos.lm
# to build the bins.

import os
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

DATA_ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
TRAIN_BIN = os.path.join(DATA_ROOT, "wikitext103_gpt2_train.bin")
VAL_BIN = os.path.join(DATA_ROOT, "wikitext103_gpt2_val.bin")
VOCAB_SIZE = 50257
# Hub revision of Salesforce/wikitext used for the reported results.
WIKITEXT_REVISION = "b08601e04326c79dfdd32d625aee71d232d685c3"

CONFIGS = {
    # size ladder for the domain-vs-scale question (kappa* = boundary/alpha
    # as a function of model size within the LM domain):
    "tiny": dict(n_layer=4, n_head=4, n_embd=256),       # ~16M params
    "mid": dict(n_layer=6, n_head=8, n_embd=512),        # ~45M params
    "small": dict(n_layer=12, n_head=12, n_embd=768),    # ~124M params
    "medium": dict(n_layer=24, n_head=16, n_embd=1024),  # ~355M params
}


class Block(nn.Module):
    def __init__(self, n_embd, n_head):
        super().__init__()
        self.ln1 = nn.LayerNorm(n_embd)
        self.attn = nn.Linear(n_embd, 3 * n_embd)
        self.proj = nn.Linear(n_embd, n_embd)
        self.ln2 = nn.LayerNorm(n_embd)
        self.mlp_fc = nn.Linear(n_embd, 4 * n_embd)
        self.mlp_proj = nn.Linear(4 * n_embd, n_embd)
        self.n_head = n_head

    def forward(self, x):
        B, T, C = x.shape
        h = self.ln1(x)
        qkv = self.attn(h)
        q, k, v = qkv.split(C, dim=2)
        q = q.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        k = k.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        v = v.view(B, T, self.n_head, C // self.n_head).transpose(1, 2)
        a = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        a = a.transpose(1, 2).contiguous().view(B, T, C)
        x = x + self.proj(a)
        h = self.ln2(x)
        x = x + self.mlp_proj(F.gelu(self.mlp_fc(h)))
        return x


class GPT2LM(nn.Module):
    def __init__(self, model_size="small", block_size=512, vocab_size=VOCAB_SIZE):
        super().__init__()
        cfg = CONFIGS[model_size]
        self.block_size = block_size
        self.tok_emb = nn.Embedding(vocab_size, cfg["n_embd"])
        self.pos_emb = nn.Embedding(block_size, cfg["n_embd"])
        self.blocks = nn.ModuleList(
            [Block(cfg["n_embd"], cfg["n_head"]) for _ in range(cfg["n_layer"])])
        self.ln_f = nn.LayerNorm(cfg["n_embd"])
        self.head = nn.Linear(cfg["n_embd"], vocab_size, bias=False)
        self.head.weight = self.tok_emb.weight  # weight tying
        self.apply(self._init)
        # GPT-2 residual-projection scaling
        scale = 0.02 / math.sqrt(2 * cfg["n_layer"])
        for blk in self.blocks:
            nn.init.normal_(blk.proj.weight, mean=0.0, std=scale)
            nn.init.normal_(blk.mlp_proj.weight, mean=0.0, std=scale)

    @staticmethod
    def _init(m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Embedding):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)

    def forward(self, idx):
        B, T = idx.shape
        pos = torch.arange(T, device=idx.device)
        x = self.tok_emb(idx) + self.pos_emb(pos)[None]
        for blk in self.blocks:
            x = blk(x)
        return self.head(self.ln_f(x))


def lm_loss(model, xb, yb):
    logits = model(xb)
    return F.cross_entropy(logits.view(-1, logits.size(-1)), yb.view(-1))


class BinBatches:
    """Random (x, y) next-token batches from a uint16 token memmap."""
    def __init__(self, bin_path, block_size, batch_size, device, seed):
        self.data = np.memmap(bin_path, dtype=np.uint16, mode="r")
        self.block_size = block_size
        self.batch_size = batch_size
        self.device = device
        self.rng = np.random.default_rng(seed)

    def next(self):
        ix = self.rng.integers(0, len(self.data) - self.block_size - 1,
                               size=self.batch_size)
        x = np.stack([self.data[i:i + self.block_size] for i in ix]).astype(np.int64)
        y = np.stack([self.data[i + 1:i + 1 + self.block_size] for i in ix]).astype(np.int64)
        return (torch.from_numpy(x).to(self.device, non_blocking=True),
                torch.from_numpy(y).to(self.device, non_blocking=True))


def sequential_val_batches(block_size, batch_size, device, max_tokens=None):
    """Non-overlapping sequential batches over the whole val split."""
    data = np.memmap(VAL_BIN, dtype=np.uint16, mode="r")
    n = len(data) - 1 if max_tokens is None else min(len(data) - 1, max_tokens)
    step = block_size * batch_size
    for start in range(0, n - block_size, step):
        xs, ys = [], []
        for b in range(batch_size):
            i = start + b * block_size
            if i + block_size + 1 > n:
                break
            xs.append(data[i:i + block_size].astype(np.int64))
            ys.append(data[i + 1:i + 1 + block_size].astype(np.int64))
        if not xs:
            return
        yield (torch.from_numpy(np.stack(xs)).to(device),
               torch.from_numpy(np.stack(ys)).to(device))


def prepare_wikitext103():
    """Tokenise WikiText-103 (raw) with GPT-2 BPE into uint16 memmaps."""
    import tiktoken
    from datasets import load_dataset
    enc = tiktoken.get_encoding("gpt2")
    eot = enc.eot_token
    # Revision pinned to the snapshot the reported perplexities were computed
    # from; without it a re-upload on the Hub would silently change the input.
    ds = load_dataset("Salesforce/wikitext", "wikitext-103-raw-v1",
                      revision=WIKITEXT_REVISION)
    for split, path in [("train", TRAIN_BIN), ("validation", VAL_BIN)]:
        if os.path.exists(path):
            print(f"[skip] {path} exists")
            continue
        ids = []
        for row in ds[split]["text"]:
            if row:
                ids.extend(enc.encode_ordinary(row))
        ids.append(eot)
        arr = np.array(ids, dtype=np.uint16)
        arr.tofile(path)
        print(f"[written] {path}: {len(arr):,} tokens")


if __name__ == "__main__":
    prepare_wikitext103()
