# eos/compare_runs.py
#
# Diagnostic overlay helper; its output does not
#   correspond to any figure in armijo_curvature_probe.tex.
#
# Overlay alpha and lambda_1 traces from several runs on a single figure.
# Used to produce the GS-vs-Armijo ablation plot and the Adam reference plot.

import os, sys, json, argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def load_run(run_dir):
    df = pd.read_csv(os.path.join(run_dir, "trace.csv"))
    summary = json.load(open(os.path.join(run_dir, "summary.json")))
    return df, summary


def overlay(run_dirs, labels, out_png, title=""):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    colors = ["C0", "C1", "C2", "C3", "C4"]
    for d, lab, color in zip(run_dirs, labels, colors):
        df, summary = load_run(d)
        sub = df.dropna(subset=["mean_alpha_window"])
        if len(sub) > 0:
            axes[0].plot(sub["step"], sub["mean_alpha_window"], "-o",
                         color=color, label=lab, markersize=3)
        axes[1].plot(df["step"], df["lambda_1"], "-s",
                     color=color, label=lab, markersize=3, alpha=0.85)
    axes[0].set_xlabel("Step")
    axes[0].set_ylabel(r"Line-search $\alpha$")
    axes[0].legend()
    axes[0].set_title(r"$\alpha$ over training")
    axes[1].set_xlabel("Step")
    axes[1].set_ylabel(r"$\lambda_1$ (top Hessian eigenvalue)")
    axes[1].set_yscale("log")
    axes[1].legend()
    axes[1].set_title(r"$\lambda_1$ over training")
    if title:
        fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    print(f"[plot] {out_png}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--out", required=True)
    p.add_argument("--title", default="")
    p.add_argument("--runs", nargs="+", required=True,
                   help="alternating run-dir label run-dir label ...")
    args = p.parse_args()
    pairs = list(zip(args.runs[::2], args.runs[1::2]))
    run_dirs = [r for r, _ in pairs]
    labels = [l for _, l in pairs]
    overlay(run_dirs, labels, args.out, title=args.title)
