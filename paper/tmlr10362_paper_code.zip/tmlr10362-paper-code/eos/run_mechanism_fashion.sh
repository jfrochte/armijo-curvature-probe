#!/usr/bin/env bash
# B: alpha <-> lambda_1 correlation on a SECOND architecture (Fashion-MNIST /
# small CNN), to show the line-search step tracks the top Hessian eigenvalue
# beyond CIFAR-10/ResNet-18. Pure Armijo (the SLS variant), 3 seeds, with
# periodic PyHessian probes. Mirrors the CIFAR mechanism runs in run_all.sh.
set -uo pipefail
PY=${PY:-python}
GPU0=${GPU0:-0}
GPU1=${GPU1:-1}
cd "$(dirname "$0")/.."
mkdir -p eos/runs

run () {  # gpu seed
    local gpu=$1 sd=$2 outdir="eos/runs/fashion_ggao_armijo_seed${2}"
    if [[ -f "$outdir/summary.json" ]]; then echo "[skip] $outdir"; return; fi
    echo "[run gpu$gpu] $outdir"
    "$PY" -m eos.train --dataset fashion_mnist --optimizer ggao_armijo \
        --epochs 10 --probe-every 100 --probe-size 256 --batch-size 256 \
        --num-workers 4 --gpu "$gpu" --seed "$sd" --outdir "$outdir" \
        > "${outdir}.log" 2>&1 || echo "[FAIL] $outdir"
}

( run "$GPU0" 0; run "$GPU0" 2 ) &
P0=$!
( run "$GPU1" 1 ) &
P1=$!
wait $P0 $P1
echo "=== fashion mechanism runs finished; analysing ==="
"$PY" -m eos.analyze eos/runs/fashion_ggao_armijo_seed0 \
                     eos/runs/fashion_ggao_armijo_seed1 \
                     eos/runs/fashion_ggao_armijo_seed2 > eos/runs/analyze_fashion.log 2>&1
"$PY" -m eos.summarize_mechanism eos/runs/fashion_ggao_armijo_seed 0 1 2
