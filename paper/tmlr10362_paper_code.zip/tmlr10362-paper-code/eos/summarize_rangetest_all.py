"""eos/summarize_rangetest_all.py

Reproduction artifact: prints the LaTeX body of Table \\label{tab:rangetest}
  and writes runs/rangetest_all_summary.csv.
  Data: runs/lr_rangetest_all.csv (run_rangetest_all.py) for the range-test
  arm; the grid runs runs/<ds>_adam_init_dir_lr0.1_seed<sd> for the probe arm.

Head-to-head on all four benchmarks (5 seeds): a real learning-rate range
test (Smith 2017) that ramps eta over ~2 epochs, picks eta* and trains,
versus the direction-matched one-shot probe (kappa = 2) handed a deliberately
100x-too-large eta = 0.1. Extra cost is reported in forward/backward passes
(architecture- and hardware-invariant) and as a fraction of the training
budget: the ramp costs its steps in full forward+backward passes, the probe
one extra forward+backward pass plus eight forward-only evaluations.
"""
import os, csv, json
import numpy as np
import pandas as pd

RUNS = "eos/runs"
DATASETS = [("cifar10", "cifar", "CIFAR-10/ResNet-18"),
            ("fashion_mnist", "fashion", "Fashion-MNIST/CNN"),
            ("agnews", "agnews", "AG News/Transformer"),
            ("imagenette", "imagenette", "Imagenette/ResNet-18")]
SEEDS = range(5)


def probe(ds_prefix):
    accs, caps, ndiv, n = [], [], 0, 0
    for s in SEEDS:
        p = os.path.join(RUNS, f"{ds_prefix}_adam_init_dir_lr0.1_seed{s}", "summary.json")
        if not os.path.exists(p):
            continue
        r = json.load(open(p)); n += 1
        if r.get("diverged"):
            ndiv += 1; continue
        accs.append(r["test_acc"])
        c = os.path.join(RUNS, f"{ds_prefix}_adam_init_dir_lr0.1_seed{s}", "controller_log.json")
        if os.path.exists(c):
            caps.append(json.load(open(c))["lr_history"][0][1])
    return (np.mean(accs) if accs else np.nan,
            np.std(accs) if accs else np.nan,
            np.mean(caps) if caps else np.nan, ndiv, n)


def main():
    d = pd.read_csv(f"{RUNS}/lr_rangetest_all.csv")
    rows = []
    print("=== LaTeX body (paste into tab:rangetest) ===")
    print("Benchmark & $\\eta^{\\ast}$ & test acc & extra cost "
          "& $\\eta_{\\text{cap}}$ & test acc \\\\")
    print("\\midrule")
    for csv_ds, prefix, label in DATASETS:
        s = d[d.dataset == csv_ds]
        if not len(s):
            continue
        surv = s[s.diverged == 0]
        rt_acc, rt_std = surv.test_acc.mean(), surv.test_acc.std(ddof=0)
        rt_div = int(s.diverged.sum())
        eta_star = surv.eta_star.mean()
        ramp = int(round(s.ramp_steps_used.mean()))
        budget = int(s.steps_per_epoch.iloc[0]) * int(s.epochs.iloc[0])
        rt_pct = 100.0 * ramp / budget
        p_acc, p_std, cap, p_div, p_n = probe(prefix)
        p_pct = 100.0 * 1.0 / budget   # 1 extra fwd+bwd step-equivalent (+8 f)
        print(f"{label} & ${eta_star:.4f}$ & ${rt_acc:.3f} \\pm {rt_std:.3f}$ "
              f"& ${ramp}$\\,fb (${rt_pct:.0f}\\%$) "
              f"& ${cap:.4f}$ & ${p_acc:.3f} \\pm {p_std:.3f}$ \\\\")
        if rt_div or p_div:
            print(f"% NOTE {label}: divergences rt={rt_div} probe={p_div}")
        rows.append(dict(dataset=csv_ds, n=len(s),
                         rt_eta_star=round(float(eta_star), 6),
                         rt_acc_mean=round(float(rt_acc), 4),
                         rt_acc_std=round(float(rt_std), 4), rt_div=rt_div,
                         rt_ramp_steps=ramp, budget_steps=budget,
                         rt_cost_pct=round(rt_pct, 2),
                         probe_cap=round(float(cap), 6),
                         probe_acc_mean=round(float(p_acc), 4),
                         probe_acc_std=round(float(p_std), 4),
                         probe_div=p_div, probe_n=p_n,
                         probe_cost_pct=round(p_pct, 4)))
    path = f"{RUNS}/rangetest_all_summary.csv"
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(f"[csv] {path}")


if __name__ == "__main__":
    main()
