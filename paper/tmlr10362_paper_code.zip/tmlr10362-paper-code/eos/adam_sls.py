# eos/adam_sls.py
#
# Adam optimizer with an SLS (stochastic-Armijo) line-search probe used as an
# online controller for Adam's learning rate.
#
# Two control modes:
#   "watchdog": defensive — keep Adam's lr at lr_initial unless the probed alpha
#               drops below `shrink_threshold * alpha_baseline`, in which case
#               shrink lr by `shrink_factor`. Allow gradual recovery back to
#               lr_initial when alpha rises above `grow_threshold * baseline`.
#   "tracker": active — Adam's lr continuously tracks `tracker_c * alpha_probe`
#              with EMA smoothing.
#
# The probe is a single Armijo backtracking at the current parameters, executed
# every `probe_every` Adam steps. The probe needs the gradient only once (for
# the descent direction) via one fresh forward+backward; every subsequent
# backtracking trial evaluates the loss with a *forward-only* pass supplied as
# `eval_loss` (no gradient). After the probe the parameters are restored so the
# probe does not influence the Adam trajectory directly --- only via the lr
# adjustment. If no `eval_loss` is given the optimizer falls back to the full
# (forward+backward) `closure` for backtracking, which is numerically identical
# but more expensive.

import contextlib

import torch


class AdamSLSControlled:
    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                 probe_every=50,
                 mode="watchdog",
                 init_probe=True,           # NEW: probe once before first step
                 init_safety=0.25,          # NEW: if user's lr > safety*alpha_init, lr := safety*alpha_init
                 probe_direction="grad",    # "grad": d = -g (raw-gradient probe);
                                            # "adam": d = -g/(|g|+eps), Adam's first-step
                                            # geometry (direction-matched probe, kappa=2)
                 base="adam",               # base optimizer: "adam" or "adamw"
                 model=None,                # optional: enables buffer (BN stats)
                                            # restoration in the probe guard
                 # Armijo settings
                 alpha_max=1.0, armijo_c=1e-4, armijo_beta=0.5, armijo_max_iter=8,
                 # Watchdog params
                 shrink_threshold=0.5, grow_threshold=0.8,
                 shrink_factor=0.5, grow_factor=1.2,
                 lr_min_factor=0.05, lr_max_factor=1.0,
                 # Tracker params
                 tracker_c=0.25, tracker_beta=0.1,   # changed default 0.5 -> 0.25
                 lr_min=1e-7, lr_max=1.0):
        assert mode in ("watchdog", "tracker", "init_only", "off")
        assert probe_direction in ("grad", "adam")
        params = list(params)
        opt_cls = torch.optim.AdamW if base == "adamw" else torch.optim.Adam
        self.adam = opt_cls(params, lr=lr, betas=betas, eps=eps)
        self.probe_direction = probe_direction
        self._eps = eps
        self._params = params
        self._model = model
        self.lr_initial = lr
        self.probe_every = probe_every
        self.mode = mode
        self.alpha_max = alpha_max
        self.armijo_c = armijo_c
        self.armijo_beta = armijo_beta
        self.armijo_max_iter = armijo_max_iter
        self.shrink_threshold = shrink_threshold
        self.grow_threshold = grow_threshold
        self.shrink_factor = shrink_factor
        self.grow_factor = grow_factor
        self.lr_min_factor = lr_min_factor
        self.lr_max_factor = lr_max_factor
        self.tracker_c = tracker_c
        self.tracker_beta = tracker_beta
        self.lr_min = lr_min
        self.lr_max = lr_max

        self.init_probe = init_probe
        self.init_safety = init_safety
        self.step_count = 0
        self.alpha_baseline = None
        self._init_done = False
        # logs (for plotting)
        self.alpha_history = []        # (step, alpha)
        self.lr_history = []           # (step, lr_after_adjust)
        self.last_alpha = float("nan")

    # Hardening: the probe's trial forward passes must
    # not leave a trace. RNG state (CPU + CUDA) is always restored; the
    # non-parameter buffers (BatchNorm running stats) additionally when the
    # model was passed to the constructor. Values computed INSIDE the guard
    # are unchanged, so the probed alpha is bit-identical either way; see
    # eos/no_op_paired_test.py for the paired verification protocol.
    @contextlib.contextmanager
    def _probe_guard(self):
        bufs = ([(b, b.detach().clone()) for b in self._model.buffers()]
                if self._model is not None else [])
        devs = (list(range(torch.cuda.device_count()))
                if torch.cuda.is_available() else [])
        try:
            with torch.random.fork_rng(devices=devs):
                yield
        finally:
            with torch.no_grad():
                for b, b0 in bufs:
                    b.copy_(b0)

    def zero_grad(self, set_to_none=True):
        self.adam.zero_grad(set_to_none=set_to_none)

    @property
    def current_lr(self):
        return self.adam.param_groups[0]["lr"]

    def _set_lr(self, lr):
        lr = max(min(lr, self.lr_max), self.lr_min)
        for g in self.adam.param_groups:
            g["lr"] = lr

    def step(self, closure, eval_loss=None):
        # `eval_loss`, if given, is a forward-only (no-grad) loss evaluation at
        # the current parameters; it is used for the Armijo backtracking trials
        # so they cost only a forward pass. `closure` (forward+backward) is still
        # used once per probe to obtain the gradient for the descent direction.
        #
        # Calibration probe BEFORE the first Adam step: if user's lr is above
        # init_safety * alpha_init, scale lr down. Prevents catastrophic first
        # step at over-aggressive initial learning rates.
        if self.mode != "off" and self.init_probe and not self._init_done:
            self._probe_at_current_params(closure, eval_loss)
            self._init_done = True
            if self.alpha_baseline is not None:
                target = self.init_safety * self.alpha_baseline
                if self.current_lr > target:
                    self._set_lr(target)
            self.lr_history.append((0, self.current_lr))

        loss = self.adam.step(closure)
        self.step_count += 1

        # init_only mode never runs periodic probes (init probe only).
        if (self.mode in ("watchdog", "tracker")
                and self.step_count % self.probe_every == 0):
            self._probe_and_adjust(closure, eval_loss)

        return loss

    @staticmethod
    def _loss_value(closure, eval_loss):
        """Forward-only loss at the current params if `eval_loss` is available;
        otherwise fall back to the full forward+backward `closure`."""
        if eval_loss is not None:
            with torch.no_grad():
                val = eval_loss()
        else:
            with torch.enable_grad():
                val = closure()
        return float(val.detach()) if torch.is_tensor(val) else float(val)

    def _probe_at_current_params(self, closure, eval_loss=None):
        """Run only the probe (no controller); store alpha into baseline+history."""
        with self._probe_guard():
            return self._probe_at_current_params_inner(closure, eval_loss)

    def _probe_at_current_params_inner(self, closure, eval_loss=None):
        params = [p for p in self._params if p.requires_grad]
        x0 = [p.detach().clone() for p in params]
        with torch.enable_grad():
            loss0 = closure()
        cur_loss = float(loss0.detach()) if torch.is_tensor(loss0) else float(loss0)
        grads = [p.grad.detach().clone() if p.grad is not None else torch.zeros_like(p)
                 for p in params]
        if self.probe_direction == "adam":
            # Adam's first-step geometry: d = -g/(|g|+eps) ~ -sign(g).
            d = [-g / (g.abs() + self._eps) for g in grads]
        else:
            d = [-g for g in grads]
        gd = sum((g * di).sum().item() for g, di in zip(grads, d))

        def f_alpha(alpha):
            with torch.no_grad():
                for p, x0p, dp in zip(params, x0, d):
                    p.data.copy_(x0p + alpha * dp)
            # Forward-only loss evaluation for the backtracking trial.
            return self._loss_value(closure, eval_loss)

        alpha = self.alpha_max
        for _ in range(self.armijo_max_iter):
            if f_alpha(alpha) <= cur_loss + self.armijo_c * alpha * gd:
                break
            alpha *= self.armijo_beta
        with torch.no_grad():
            for p, x0p in zip(params, x0):
                p.data.copy_(x0p)

        self.last_alpha = alpha
        self.alpha_history.append((self.step_count, alpha))
        if self.alpha_baseline is None:
            self.alpha_baseline = alpha

    def _probe_and_adjust(self, closure, eval_loss=None):
        """Run one Armijo probe at the current params; do not change params; adjust lr."""
        with self._probe_guard():
            return self._probe_and_adjust_inner(closure, eval_loss)

    def _probe_and_adjust_inner(self, closure, eval_loss=None):
        params = [p for p in self._params if p.requires_grad]

        # Snapshot parameters
        x0 = [p.detach().clone() for p in params]

        # Fresh forward+backward at the post-Adam-step params to get gradient & loss
        with torch.enable_grad():
            loss0 = closure()
        cur_loss = float(loss0.detach()) if torch.is_tensor(loss0) else float(loss0)
        grads = [p.grad.detach().clone() if p.grad is not None else torch.zeros_like(p)
                 for p in params]
        d = [-g for g in grads]
        gd = sum((g * di).sum().item() for g, di in zip(grads, d))

        def f_alpha(alpha):
            with torch.no_grad():
                for p, x0p, dp in zip(params, x0, d):
                    p.data.copy_(x0p + alpha * dp)
            # Forward-only loss evaluation for the backtracking trial.
            return self._loss_value(closure, eval_loss)

        # Armijo backtracking from alpha_max
        alpha = self.alpha_max
        for _ in range(self.armijo_max_iter):
            if f_alpha(alpha) <= cur_loss + self.armijo_c * alpha * gd:
                break
            alpha *= self.armijo_beta

        # Restore parameters and gradients to pre-probe state
        with torch.no_grad():
            for p, x0p in zip(params, x0):
                p.data.copy_(x0p)
        # Recompute grads at the restored params so subsequent training step
        # has the correct gradient for the *post-Adam-step* point.
        # (closure does zero_grad + backward inside; so any next training step
        # will refresh grads anyway. We don't need to do anything here.)

        self.last_alpha = alpha
        self.alpha_history.append((self.step_count, alpha))

        # Establish baseline at first probe
        if self.alpha_baseline is None:
            self.alpha_baseline = alpha

        # Apply controller
        if self.mode == "watchdog":
            self._control_watchdog(alpha)
        elif self.mode == "tracker":
            self._control_tracker(alpha)

        self.lr_history.append((self.step_count, self.current_lr))

    def _control_watchdog(self, alpha):
        ratio = alpha / max(self.alpha_baseline, 1e-12)
        cur = self.current_lr
        lr_floor = self.lr_initial * self.lr_min_factor
        lr_ceil = self.lr_initial * self.lr_max_factor
        if ratio < self.shrink_threshold:
            new_lr = max(cur * self.shrink_factor, lr_floor)
        elif ratio > self.grow_threshold and cur < lr_ceil:
            new_lr = min(cur * self.grow_factor, lr_ceil)
        else:
            new_lr = cur
        if new_lr != cur:
            self._set_lr(new_lr)

    def _control_tracker(self, alpha):
        target_lr = self.tracker_c * alpha
        cur = self.current_lr
        new_lr = (1.0 - self.tracker_beta) * cur + self.tracker_beta * target_lr
        self._set_lr(new_lr)
