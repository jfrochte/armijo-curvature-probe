#!/usr/bin/env bash
# CIFAR-10/ResNet-18 controller extension and kappa-sensitivity sweep.
#
# Extend the main CIFAR-10 sweep from 2 to 5 seeds -> run seeds 2,3,4 for the four main
#         controllers (the parameter-free rows are already at 5 seeds).
# Kappa sensitivity for Adam-InitOnly -- sweep kappa x {few lr} x 3 seeds.
#
# All jobs split round-robin across two GPUs; idempotent (skip if summary.json).
set -uo pipefail
PY=${PY:-python}
GPU0=${GPU0:-0}
GPU1=${GPU1:-1}
cd "$(dirname "$0")/.."
mkdir -p eos/runs

JOBS=()   # each entry: "outdir|optimizer|lr|seed|kappa"

# ---- Additional seeds 2,3,4 for the four main controllers ------------------
for opt in adam adam_init_only adam_watchdog adam_tracker; do
    for lr in 0.001 0.01 0.1 0.3 1.0 3.0; do
        for sd in 2 3 4; do
            JOBS+=("eos/runs/cifar_${opt}_lr${lr}_seed${sd}|${opt}|${lr}|${sd}|0.25")
        done
    done
done

# ---- Kappa sensitivity for Adam-InitOnly ----------------------------
for k in 0.05 0.1 0.25 0.5 1.0; do
    for lr in 0.001 0.1 1.0; do
        for sd in 0 1 2; do
            JOBS+=("eos/runs/cifar_kappa${k}_lr${lr}_seed${sd}|adam_init_only|${lr}|${sd}|${k}")
        done
    done
done

run_one () {
    local gpu=$1 spec=$2
    local outdir optimizer lr sd kappa
    IFS='|' read -r outdir optimizer lr sd kappa <<< "$spec"
    if [[ -f "$outdir/summary.json" ]]; then echo "[skip gpu$gpu] $outdir"; return; fi
    echo "[run  gpu$gpu] $outdir (k=$kappa)"
    "$PY" -m eos.train_adam_sls --dataset cifar10 --optimizer "$optimizer" \
        --epochs 10 --probe-every 50 --batch-size 256 --num-workers 4 \
        --init-safety "$kappa" --gpu "$gpu" --seed "$sd" --lr "$lr" --outdir "$outdir" \
        > "${outdir}.log" 2>&1 || echo "[FAIL gpu$gpu] $outdir"
}

worker () {
    local gpu=$1 parity=$2 i=0
    for spec in "${JOBS[@]}"; do
        if (( i % 2 == parity )); then run_one "$gpu" "$spec"; fi
        ((i++))
    done
    echo "[worker gpu$gpu] done"
}

echo "=== launching ${#JOBS[@]} controller-extension and kappa-sensitivity jobs across GPU$GPU0 and GPU$GPU1 ==="
worker "$GPU0" 0 &
P0=$!
worker "$GPU1" 1 &
P1=$!
wait $P0 $P1
echo "=== controller-extension and kappa-sensitivity sweeps finished ==="
"$PY" -m eos.summarize_adam_sls
"$PY" -m eos.summarize_kappa
