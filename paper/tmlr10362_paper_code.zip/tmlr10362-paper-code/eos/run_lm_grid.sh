#!/usr/bin/env bash
# eos/run_lm_grid.sh
#
# Reproduction artifact: the language-model
# rescue grid behind Table \label{tab:lm-rescue}. GPT-2-{small,medium} on
# WikiText-103, AdamW without warmup, vanilla vs. direction-matched init
# probe (kappa = 2), fixed step budget.
#
#   GPU=<id> SEEDS="0" MODEL=small STEPS=10000 bash eos/run_lm_grid.sh
#
# Convention: one seed per GPU, run this script once per GPU in parallel.
# Runs are resumable: a run directory with summary.json is skipped.
set -u
PY=${PY:-python}
GPU=${GPU:-0}
MODEL=${MODEL:-small}
STEPS=${STEPS:-10000}
SEEDS=${SEEDS:-0}
LRS=${LRS:-"0.001 0.01 0.1 0.3 1.0 3.0"}
# Arms: vanilla AdamW; direction-matched probe at the paper's fixed kappa=2;
# direction-matched probe at the LM-calibrated kappa=0.5 (divergence sweep
# Note: gpt2-small/WikiText-103 diverges from eta=0.0625 on, i.e.
# below alpha_init=0.0625, so kappa=2 and kappa=1 do not protect here);
# probationary probe (kappa=2 fixed, re-probes during the first 50 steps,
# see PROBATION_STEPS in train_lm.py -- the calibration-free fix).
# plus the linear-warmup baseline (lr/100 -> lr over 1000 steps = 10% of the
# budget, proportional to the vision adam_warmup baseline).
ARMS=${ARMS:-"adamw:2.0 adamw_warmup:2.0 adamw_init_dir_k2:2.0 adamw_init_dir_k0.5:0.5 adamw_init_dir_probation:2.0 adamw_warmup_probation:2.0"}  # all six arms of tab:lm-rescue
cd "$(dirname "$0")/.."
mkdir -p eos/runs

for seed in $SEEDS; do
  for lr in $LRS; do
    for arm in $ARMS; do
      name="${arm%%:*}"; safety="${arm##*:}"
      case "$name" in
        adamw) opt="adamw" ;;
        adamw_warmup) opt="adamw_warmup" ;;
        adamw_warmup_probation) opt="adamw_warmup_probation" ;;
        adamw_init_dir_probation) opt="adamw_init_dir_probation" ;;
        *) opt="adamw_init_dir" ;;
      esac
      out="eos/runs/lm_${MODEL}_${name}_lr${lr}_seed${seed}"
      if [ -f "$out/summary.json" ]; then
        echo "[skip] $out"
        continue
      fi
      echo "[start] $out (gpu $GPU)"
      $PY -m eos.train_lm --model "$MODEL" --optimizer "$opt" --lr "$lr" \
          --seed "$seed" --steps "$STEPS" --gpu "$GPU" --outdir "$out" \
          --init-safety "$safety" > "$out.log" 2>&1
    done
  done
done
echo "[grid done] model=$MODEL seeds=$SEEDS gpu=$GPU"
