# eos/check_noop_in_tables.py
#
# Verification artifact: at the one learning rate where the cap provably does
# not bind (eta = 1e-3, since kappa*beta^8 = 0.0078), the direction-matched
# probe must leave training identical to the baseline optimiser. This script
# compares the two run families seed by seed, so the no-op property is visible
# in the reported tables and not only in the paired test of the appendix.
#
# Usage: python -m eos.check_noop_in_tables

import json
import os
import sys

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
PAIRS = [
    ("cifar", "adam", "adam_init_dir", "CIFAR-10 / ResNet-18"),
    ("cifar", "adamw", "adamw_init_dir", "CIFAR-10 / ResNet-18 (AdamW)"),
    ("fashion", "adam", "adam_init_dir", "Fashion-MNIST / CNN"),
    ("agnews", "adam", "adam_init_dir", "AG News / Transformer"),
    ("imagenette", "adam", "adam_init_dir", "Imagenette / ResNet-18"),
]
SEEDS = range(5)


def acc(ds, opt, seed):
    p = os.path.join(RUNS, f"{ds}_{opt}_lr0.001_seed{seed}", "summary.json")
    if not os.path.exists(p):
        return None
    return json.load(open(p)).get("test_acc")


def main():
    print("No-op check at eta = 1e-3 (cap = kappa*beta^8 = 0.0078, does not bind)\n")
    all_equal = True
    for ds, base, probe, label in PAIRS:
        b = [acc(ds, base, s) for s in SEEDS]
        p = [acc(ds, probe, s) for s in SEEDS]
        if any(x is None for x in b + p):
            print(f"  [skip] {label}: runs missing")
            continue
        same = all(x == y for x, y in zip(b, p))
        all_equal &= same
        mark = "identical" if same else "DIFFER"
        print(f"  {label}")
        print(f"    baseline : {b}")
        print(f"    probe    : {p}")
        print(f"    -> {mark}"
              + ("" if same else f"  (max |delta| = {max(abs(x-y) for x, y in zip(b, p)):.4f})"))
    print()
    if all_equal:
        print("PASS: the probe is a no-op wherever the cap does not bind, "
              "seed by seed, in the reported tables.")
    else:
        print("NOTE: residual differences remain; see the per-pair deltas above.")
    return 0 if all_equal else 1


if __name__ == "__main__":
    sys.exit(main())
