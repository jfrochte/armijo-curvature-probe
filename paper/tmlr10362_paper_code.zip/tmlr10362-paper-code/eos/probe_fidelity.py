# eos/probe_fidelity.py
#
# Reproduction artifact: produces runs/fig_fidelity.png + runs/probe_fidelity.csv
#   -> Figure \label{fig:fidelity} in armijo_curvature_probe.tex
#
# Characterises the Armijo step AS A SENSOR (TMLR-style thoroughness): how
# faithfully 1/alpha reads the directional curvature q and the top eigenvalue
# lambda_1, as a function of (i) the backtracking factor beta -- theory says
# 1/alpha lies in [q/2(1-c), q/(2 beta (1-c))], a band of width 1/beta, so a
# finer beta resolves q more precisely; (ii) alpha_max -- raising it past 1
# removes the saturation floor (1/alpha cannot drop below 1/alpha_max); and
# (iii) probe batch size -- the noise of the reading. Small Fashion CNN so the
# PyHessian lambda_1 is cheap; the relation is architecture-agnostic.

import os, sys, csv
import numpy as np
import torch, torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.data import FashionCNN, make_fashion_mnist_loaders
from eos.probe import HessianProbe

dev = "cuda" if torch.cuda.is_available() else "cpu"
RES = "eos/runs"
C = 1e-4  # Armijo constant


def get_batch(loader, bs):
    Xs, Ys = [], []
    for X, Y in loader:
        Xs.append(X); Ys.append(Y)
        if sum(x.shape[0] for x in Xs) >= bs:
            break
    X = torch.cat(Xs)[:bs]; Y = torch.cat(Ys)[:bs]
    return X, Y


def main():
    torch.manual_seed(0)
    tl, _ = make_fashion_mnist_loaders(batch_size=128, num_workers=2, seed=0)
    model = FashionCNN().to(dev)
    crit = nn.CrossEntropyLoss()
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    rows = []
    probe_steps = [0, 20, 50, 100, 200, 400, 800, 1500]
    step = 0
    it = iter(tl)
    while step <= max(probe_steps):
        if step in probe_steps:
            # fresh probe batch (bs=256) at this checkpoint
            Xp, Yp = get_batch(tl, 256)
            P = HessianProbe(model, crit, Xp, Yp, top_n=1, device=dev)
            lam1 = P()["eigenvalues"][0]
            q, _ = P.directional_curvature()
            # match the backtracking DEPTH across beta (same min alpha ~ 0.004)
            # so the band comparison is fair rather than iteration-budget limited.
            for beta in (0.5, 0.7, 0.9):
                mi = int(np.ceil(np.log(0.004) / np.log(beta)))
                a = P.armijo_alpha(c=C, beta=beta, alpha_max=1.0, max_iter=mi)
                rows.append(dict(kind="beta", step=step, beta=beta, alpha_max=1.0,
                                 bs=256, lam1=lam1, q=q, inv_alpha=1.0 / a))
        try:
            X, Y = next(it)
        except StopIteration:
            it = iter(tl); X, Y = next(it)
        X, Y = X.to(dev), Y.to(dev)
        opt.zero_grad(set_to_none=True)
        loss = crit(model(X), Y); loss.backward(); opt.step()
        step += 1

    # batch-size noise sweep at a fixed mid checkpoint (model is now trained)
    for bs in (64, 256, 1024):
        for rep in range(5):
            Xp, Yp = get_batch(tl, bs)
            P = HessianProbe(model, crit, Xp, Yp, top_n=1, device=dev)
            lam1 = P()["eigenvalues"][0]; q, _ = P.directional_curvature()
            a = P.armijo_alpha(c=C, beta=0.5, alpha_max=4.0, max_iter=16)
            rows.append(dict(kind="bs", step=-1, beta=0.5, alpha_max=4.0,
                             bs=bs, lam1=lam1, q=q, inv_alpha=1.0 / a))

    os.makedirs(RES, exist_ok=True)
    with open(f"{RES}/probe_fidelity.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader()
        for r in rows: w.writerow(r)

    # ---- analysis ----
    import pandas as pd
    d = pd.DataFrame(rows)
    print("\n=== (i) band tightness vs beta:  ratio (1/alpha)/(q/2)  should lie in [1, 1/beta] ===")
    db = d[(d.kind == "beta") & (d.q > 0) & (d.inv_alpha > 1.0001)]  # active (not floored)
    for beta in (0.5, 0.7, 0.9):
        s = db[db.beta == beta]
        ratio = s.inv_alpha / (s.q / 2)
        frac = ((ratio >= 0.9) & (ratio <= 1 / beta + 0.15)).mean()
        print(f"  beta={beta}: band [1,{1/beta:.2f}]  median ratio={ratio.median():.2f}  "
              f"frac in band={frac:.0%}  (n={len(s)})")
    print("\n=== (ii) probe-batch noise: rel. std of estimates over 5 batches ===")
    for bs in (64, 256, 1024):
        s = d[(d.kind == "bs") & (d.bs == bs)]
        print(f"  bs={bs}: lambda1 rel-std={s.lam1.std()/s.lam1.mean():.2f}  "
              f"q rel-std={s.q.std()/s.q.mean():.2f}  1/alpha rel-std={s.inv_alpha.std()/s.inv_alpha.mean():.2f}")
    print("\n=== q / lambda_1 (EoS alignment) ===")
    da = d[(d.kind == 'beta') & (d.lam1 > 0)]
    print(f"  median q/lambda1 = {(da.q/da.lam1).median():.2f}")
    print("[done] wrote runs/probe_fidelity.csv")


if __name__ == "__main__":
    main()
