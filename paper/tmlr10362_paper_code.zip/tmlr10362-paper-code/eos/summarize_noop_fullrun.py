# eos/summarize_noop_fullrun.py
#
# Reproduction artifact: produces the whole-run figures quoted in the no-op
# appendix. The paired test (eos/no_op_paired_test.py) is the primary evidence;
# this script is the weaker whole-run check that the appendix reports alongside
# it, including the control that establishes the platform's own noise floor.
#
# Three comparisons, all at eta = 1e-3, where the cap provably cannot bind
# (kappa*beta^8 = 0.0078), so the probe must not change the trajectory:
#   control    vanilla Adam vs. an identical-seed repeat of itself
#   published  the runs behind the tables (unguarded probe) vs. their baseline
#   hardened   the same cells re-run with state restoration vs. their baseline
#
# Inputs: the published pairs are the standard eta = 1e-3 grid runs
# (eos/runs/<ds>_<opt>[_init_dir]_lr0.001_seed*). The evidence pairs live in
# eos/runs/_noop_fullrun_evidence/: "hardened_<run>" are the same *_init_dir
# configurations re-trained with the current (state-restoring)
# implementation; "control_cifar_adam_seed<s>" are identical-seed re-runs of
# the vanilla CIFAR-10 baseline (e.g. python -m eos.train_adam_sls
# --dataset cifar10 --optimizer adam --lr 0.001 --epochs 10 --batch-size 256
# --probe-every 50 --seed <s>). Each run directory needs its summary.json.
#
# Writes eos/runs/noop_fullrun_summary.csv.
#
# Usage: python -m eos.summarize_noop_fullrun

import csv
import json
import os
import statistics as st
import sys

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
EVID = os.path.join(RUNS, "_noop_fullrun_evidence")
SEEDS = range(5)
CELLS = [("cifar", "adam", "CIFAR-10 / ResNet-18"),
         ("cifar", "adamw", "CIFAR-10 / ResNet-18 (AdamW)"),
         ("fashion", "adam", "Fashion-MNIST / CNN"),
         ("imagenette", "adam", "Imagenette / ResNet-18"),
         ("agnews", "adam", "AG News / Transformer")]
DETERMINISTIC = {"agnews"}  # no non-deterministic kernels on this benchmark


def acc(path):
    p = os.path.join(path, "summary.json")
    return json.load(open(p))["test_acc"] if os.path.exists(p) else None


def pairs(ds, opt, kind):
    """|delta| in test accuracy, seed by seed, for one cell and comparison."""
    out = []
    for s in SEEDS:
        base = acc(os.path.join(RUNS, f"{ds}_{opt}_lr0.001_seed{s}"))
        if kind == "control":
            other = acc(os.path.join(EVID, f"control_{ds}_{opt}_seed{s}"))
        elif kind == "published":
            other = acc(os.path.join(RUNS, f"{ds}_{opt}_init_dir_lr0.001_seed{s}"))
        else:
            other = acc(os.path.join(
                EVID, f"hardened_{ds}_{opt}_init_dir_lr0.001_seed{s}"))
        if base is not None and other is not None:
            out.append((s, base, other, abs(base - other)))
    return out


def main():
    rows = []
    print("Whole-run no-op check at eta = 1e-3 "
          "(cap = kappa*beta^8 = 0.0078, cannot bind)\n")
    for kind in ("control", "published", "hardened"):
        print(f"  {kind}")
        for ds, opt, label in CELLS:
            rec = pairs(ds, opt, kind)
            if not rec:
                continue
            d = [x[3] for x in rec]
            for s, b, o, dd in rec:
                rows.append({"comparison": kind, "dataset": ds, "optimizer": opt,
                             "seed": s, "baseline_acc": b, "other_acc": o,
                             "abs_delta": dd})
            flag = "  <- exact" if max(d) == 0 else ""
            print(f"    {label:32s} median {st.median(d):.4f} "
                  f"max {max(d):.4f}{flag}")
        print()

    vision = [r["abs_delta"] for r in rows
              if r["dataset"] not in DETERMINISTIC and r["comparison"] != "control"]
    if vision:
        print("  Aggregate over the convolutional cells (the appendix figures):")
        for kind in ("control", "published", "hardened"):
            d = [r["abs_delta"] for r in rows if r["comparison"] == kind
                 and r["dataset"] not in DETERMINISTIC]
            if d:
                print(f"    {kind:10s} n={len(d):2d} median {st.median(d):.4f} "
                      f"max {max(d):.4f}")
        print("\n  The control is the noise floor: whole runs cannot certify the "
              "\n  property on these benchmarks, in either direction. The claim "
              "\n  rests on the paired test and on the deterministic benchmark.")

    out = os.path.join(RUNS, "noop_fullrun_summary.csv")
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"\n[written] {out}  ({len(rows)} pairs)", file=sys.stderr)


if __name__ == "__main__":
    main()
