# eos/plot_lm_sharpening.py
#
# Reproduction artifact: Figure fig:lm-sharpening. The direction-matched Armijo
# reading alpha collapses from 0.0625 to the backtracking floor beta^K
# within the first ~5 optimiser steps of stable GPT-2-small training on
# WikiText-103 (both stable learning rates, both seeds): the loss surface
# along Adam's direction sharpens right after initialisation, so a step-0
# reading alone overestimates the safe step. This is the mechanism behind
# the failure of the static init cap in the LM domain and the motivation
# for the probationary probe.
#
# Data: eos/runs/lm_sharpening_small_lr{0.001,0.01}.json
#       (written by eos/lm_sharpening_curve.py).
# Usage: python -m eos.plot_lm_sharpening

import os, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
BETA_FLOOR = 0.5 ** 8


def main():
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    # the eta=0.001 curves coincide with eta=0.01 at most probe points; draw
    # them wider and underneath, with a small multiplicative x-offset so the
    # overlap stays visible on the log axis.
    styles = {("0.001", "seed0"): ("C0", "-", "o", 3.2, 0.93, 1),
              ("0.001", "seed1"): ("C0", "--", "o", 3.2, 0.93, 1),
              ("0.01", "seed0"): ("C3", "-", "s", 1.4, 1.0, 2),
              ("0.01", "seed1"): ("C3", "--", "s", 1.4, 1.0, 2)}
    for lr in ["0.001", "0.01"]:
        data = json.load(open(os.path.join(RUNS, f"lm_sharpening_small_lr{lr}.json")))
        for seed_key, curve in data.items():
            c, ls, mk, lw, xoff, z = styles[(lr, seed_key)]
            steps = [max(p["step"], 0.7) * xoff for p in curve]  # step 0 on log axis
            ax.plot(steps, [p["alpha"] for p in curve], color=c, ls=ls,
                    marker=mk, ms=4, lw=lw, zorder=z, alpha=0.85,
                    label=f"$\\eta={lr}$, {seed_key}")
    ax.axhline(BETA_FLOOR, color="grey", lw=1, ls=":")
    ax.text(0.75, BETA_FLOOR * 1.15, r"backtracking floor $\beta^{K}$",
            fontsize=9, color="grey")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Optimiser step (log scale; leftmost point = initialisation)")
    ax.set_ylabel(r"Armijo reading $\alpha$ (Adam direction)")
    ax.set_title("GPT-2 small / WikiText-103: early sharpness growth reduces the admissible step "
                 "within $\\sim$5 steps", fontsize=10)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    out = os.path.join(RUNS, "fig_lm_sharpening.png")
    fig.savefig(out, dpi=150)
    print(f"[written] {out}")


if __name__ == "__main__":
    main()
