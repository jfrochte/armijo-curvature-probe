# eos/sharpness_tracking.py
#
# Reproduction artifact: produces runs/fig_sharpness_tracking.png
#   -> Figure \label{fig:tracking} in armijo_curvature_probe.tex
#   Data: pure-Armijo mechanism runs (trace.csv with step, lambda_1,
#   dir_curv_q, mean_alpha_window) from run_mechanism_all.sh / run_all.sh.
#
# Message: the Armijo step is not just statically correlated with sharpness --
# it TRACKS it online over the whole trajectory. We overlay, vs training step,
# the expensive top Hessian eigenvalue lambda_1 (Lanczos/PyHessian), the
# directional curvature q, and the low-cost probe reading 1/alpha. The probe
# follows lambda_1 (up to a roughly constant factor, since 1/alpha ~ q/2 and
# q ~ 0.3 lambda_1) for ~5 forward passes per point instead of k Hessian-vector
# products -- i.e. a low-cost online Edge-of-Stability monitor.

import os, sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

RUNS = [("eos/runs/cifar10_ggao_armijo_seed0", "CIFAR-10 / ResNet-18"),
        ("eos/runs/fashion_ggao_armijo_seed0", "Fashion-MNIST / CNN")]


def main(out="eos/runs/fig_sharpness_tracking.png"):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for ax, (run, title) in zip(axes, RUNS):
        d = pd.read_csv(f"{run}/trace.csv")
        d = d.dropna(subset=["lambda_1", "mean_alpha_window"])
        d = d[(d["lambda_1"] > 0) & (d["mean_alpha_window"] > 0)].sort_values("step")
        step = d["step"].values
        lam = d["lambda_1"].values
        inv_a = 1.0 / d["mean_alpha_window"].values
        ax.plot(step, lam, "o-", color="C3", lw=1.8, ms=4,
                label=r"$\lambda_1$ (Lanczos, expensive)")
        if "dir_curv_q" in d.columns and d["dir_curv_q"].notna().any():
            ax.plot(step, d["dir_curv_q"].values, "s-", color="C1", lw=1.5, ms=3,
                    alpha=0.8, label=r"$q$ (directional curvature)")
        ax.plot(step, inv_a, "^-", color="C0", lw=1.8, ms=4,
                label=r"$1/\alpha$ (Armijo probe, $\sim$5 fwd passes)")
        ax.set_yscale("log")
        ax.set_xlabel("training step")
        ax.set_title(title)
        ax.grid(True, which="both", alpha=0.2)
        r = np.corrcoef(np.log(lam), np.log(inv_a))[0, 1]
        ax.text(0.97, 0.95, rf"$r(\log\alpha,\log\lambda_1)={-r:.2f}$",
                transform=ax.transAxes, ha="right", va="top", fontsize=9,
                bbox=dict(boxstyle="round", fc="white", ec="0.7", alpha=0.9))
    axes[0].set_ylabel("curvature / inverse step (log)")
    axes[0].legend(loc="lower left", fontsize=8.5)
    fig.suptitle(r"The low-cost Armijo probe tracks local sharpness over training "
                 r"(progressive flattening under line search)", fontsize=11)
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print(f"[plot] {out}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "eos/runs/fig_sharpness_tracking.png")
