#!/usr/bin/env bash
# Long-schedule robustness experiment on CIFAR-10/ResNet-18
# to show the 10-epoch rescue numbers (78-81%) are not representative of what the
# net normally reaches (92-94%). Three cells, 100 epochs, cosine annealing:
#   1) vanilla Adam at the optimal lr (1e-3)
#   2) Adam-InitOnly at the optimal lr (1e-3)
#   3) Adam-InitOnly at a 100x misspecified lr (1e-1)
# Sanity check, not a full sweep -> single seed. Idempotent.

set -uo pipefail
PY=${PY:-python}
GPU0=${GPU0:-0}
GPU1=${GPU1:-1}
cd "$(dirname "$0")/.."
mkdir -p eos/runs

run () {  # gpu opt lr
    local gpu=$1 opt=$2 lr=$3
    local outdir="eos/runs/cos100_${opt}_lr${lr}_seed0"
    if [[ -f "$outdir/summary.json" ]]; then echo "[skip] $outdir"; return; fi
    echo "[run gpu$gpu] $outdir"
    "$PY" -m eos.train_adam_sls --dataset cifar10 --optimizer "$opt" --cosine \
        --epochs 100 --probe-every 50 --batch-size 256 --num-workers 4 \
        --gpu "$gpu" --seed 0 --lr "$lr" --outdir "$outdir" \
        > "${outdir}.log" 2>&1 || echo "[FAIL gpu$gpu] $outdir"
}

# GPU0 handles the two cells that share it sequentially; GPU1 runs in parallel.
( run "$GPU0" adam            0.001
  run "$GPU0" adam_init_only  0.1 ) &
P0=$!
( run "$GPU1" adam_init_only  0.001 ) &
P1=$!
wait $P0 $P1
echo "=== cosine-100 cells finished ==="
for d in eos/runs/cos100_adam_lr0.001_seed0 eos/runs/cos100_adam_init_only_lr0.001_seed0 eos/runs/cos100_adam_init_only_lr0.1_seed0; do
    [[ -f "$d/summary.json" ]] && "$PY" -c "import json;s=json.load(open('$d/summary.json'));print('$d', 'acc=%.4f'%s['test_acc'] if not s['diverged'] else 'DIV', 'wall=%.0fs'%s['wall_s'])"
done
