"""VALIDATION: does an init cap that probes along Adam's preconditioned direction
make a SINGLE safety factor kappa work across architectures (no per-arch sweep)?

Per architecture, full training at the framework default eta=1e-3 (and at a
too-large eta=0.1) with:
  - vanilla Adam (baseline)
  - grad-probe  + single kappa=0.25  (gradient-direction probe along -g; expected to fail on the
                                       high-curvature nets, since kappa is arch-specific)
  - adam-probe  + single kappa=3.0   (probe along -g/(sqrt(g^2)+eps); hypothesis:
                                       one kappa caps safely everywhere)
Reports final test accuracy, the capped lr, and divergence. FAIR CSV + log.
"""
import contextlib
import os, sys, csv, time, traceback
import numpy as np
import torch, torch.nn as nn
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from eos.data import (cifar_resnet18, make_cifar10_loaders, FashionCNN,
                      make_fashion_mnist_loaders, make_agnews_loaders, AGNewsTransformer)

dev = "cuda"; EPS = 1e-8; C = 1e-4
RES = os.environ.get("RESULTS_HARD", os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "eos", "runs"))
RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
SMOKE = os.environ.get("SMOKE", "0") == "1"
SEEDS = 1 if SMOKE else 3
# EOS_PROBATION=1: run ONLY the probationary variant (kappa=2, re-probes over
# the first 50 steps) across the same nine architectures, writing to
# eos/runs/probation_universality.csv. Closes the empirical gap for the
# unified thirteen-architecture claim.
PROBATION_ONLY = os.environ.get("EOS_PROBATION", "0") == "1"
PROBATION_STEPS = {1, 2, 3, 5, 8, 12, 20, 35, 50}


def log(m): print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def strip_norm(m):
    for n, mod in m.named_children():
        if isinstance(mod, (nn.BatchNorm2d, nn.BatchNorm1d)):
            setattr(m, n, nn.Identity())
        else:
            strip_norm(mod)
    return m


def bn_to_gn(m):
    for n, mod in m.named_children():
        if isinstance(mod, nn.BatchNorm2d):
            setattr(m, n, nn.GroupNorm(min(32, mod.num_features), mod.num_features))
        else:
            bn_to_gn(mod)
    return m


class MLP(nn.Module):
    def __init__(self, din, nc, hidden=(512, 256, 128)):
        super().__init__()
        layers = [nn.Flatten()]; d = din
        for h in hidden:
            layers += [nn.Linear(d, h), nn.ReLU(inplace=True)]; d = h
        layers += [nn.Linear(d, nc)]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


def vgg_bn(num_classes=10):
    def blk(ci, co):
        return [nn.Conv2d(ci, co, 3, padding=1), nn.BatchNorm2d(co), nn.ReLU(inplace=True)]
    feats = nn.Sequential(*blk(3, 64), *blk(64, 64), nn.MaxPool2d(2),
                          *blk(64, 128), *blk(128, 128), nn.MaxPool2d(2),
                          *blk(128, 256), *blk(256, 256), nn.MaxPool2d(2))
    return nn.Sequential(feats, nn.AdaptiveAvgPool2d(1), nn.Flatten(),
                         nn.Linear(256, num_classes))


class LSTMClf(nn.Module):
    def __init__(self, vocab, nc=4, d=128):
        super().__init__()
        self.emb = nn.Embedding(vocab, d, padding_idx=0)
        self.lstm = nn.LSTM(d, d, num_layers=2, batch_first=True)
        self.head = nn.Linear(d, nc)

    def forward(self, x):
        o, _ = self.lstm(self.emb(x))
        return self.head(o[:, -1])


@contextlib.contextmanager
def probe_state_guard(model):
    """Hardening: make the probe a bit-exact no-op on
    everything except its return value. Snapshots the non-parameter buffers
    (BN running stats / num_batches_tracked) and the torch RNG state
    (CPU + CUDA) and restores both afterwards. The forwards INSIDE the guard
    are unchanged, so the returned alpha is bit-identical to the unguarded
    implementation; parameters are snapshotted/restored by the caller."""
    bufs = [(b, b.detach().clone()) for b in model.buffers()]
    devs = list(range(torch.cuda.device_count())) if torch.cuda.is_available() else []
    try:
        with torch.random.fork_rng(devices=devs):
            yield
    finally:
        with torch.no_grad():
            for b, b0 in bufs:
                b.copy_(b0)


def armijo_cap(model, crit, X, Y, lr, kappa, mode, beta=0.5, amax=1.0, max_iter=30,
               return_details=False):
    """Return capped lr = min(lr, kappa * alpha_bar), alpha along -g (mode='grad')
    or along Adam's preconditioned direction (mode='adam').

    With return_details=True additionally returns the per-run record: number
    of backtracks, whether an Armijo-
    acceptable candidate was found (False = saturated, i.e. the returned alpha
    is the untested next candidate beta^max_iter), and whether the cap bound."""
    with probe_state_guard(model):
        params = [p for p in model.parameters() if p.requires_grad]
        model.zero_grad(set_to_none=True)
        loss0 = crit(model(X), Y)
        g = torch.autograd.grad(loss0, params)
        L0 = float(loss0.detach())
        d = [-gi for gi in g] if mode == "grad" else [-gi / (gi.abs() + EPS) for gi in g]
        gTd = float(sum((gi * di).sum() for gi, di in zip(g, d)))
        x0 = [p.detach().clone() for p in params]

        def f(a):
            with torch.no_grad():
                for p, x, di in zip(params, x0, d):
                    p.copy_(x + a * di)
                v = float(crit(model(X), Y).detach())
            return v
        a = amax
        backtracks = 0
        accepted = False
        for _ in range(max_iter):
            if f(a) <= L0 + C * a * gTd:
                accepted = True
                break
            a *= beta
            backtracks += 1
        with torch.no_grad():
            for p, x in zip(params, x0):
                p.copy_(x)
    clr = min(lr, kappa * a)
    if return_details:
        return clr, a, {"backtracks": backtracks, "accepted": accepted,
                        "cap_bound": clr < lr}
    return clr, a


def evaluate(model, te, limit=10000):
    model.eval(); c = t = 0
    with torch.no_grad():
        for X, Y in te:
            X, Y = X.to(dev), Y.to(dev)
            c += (model(X).argmax(1) == Y).sum().item(); t += Y.numel()
            if t >= limit: break
    return c / t


def train(model, tl, te, lr, steps=None, epochs=None):
    crit = nn.CrossEntropyLoss()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    l0 = None; it = 0; diverged = False
    done = False
    for ep in range(epochs or 1):
        model.train()
        for X, Y in tl:
            X, Y = X.to(dev), Y.to(dev)
            opt.zero_grad(set_to_none=True)
            loss = crit(model(X), Y); loss.backward(); opt.step()
            lv = float(loss.detach())
            if l0 is None: l0 = lv
            if not np.isfinite(lv) or lv > 5 * l0: diverged = True; done = True; break  # 5x = paper criterion (eos/divergence.py)
            it += 1
            if steps and it >= steps: done = True; break
        if done: break
    return (float("nan") if diverged else evaluate(model, te)), diverged


def train_probation(model, tl, te, lr, kappa, Xb, Yb, crit,
                    steps=None, epochs=None):
    """train() plus probationary re-probes: at PROBATION_STEPS re-measure
    alpha along the Adam direction on the (fixed) probe batch and lower the
    lr monotonically to min(lr, kappa * min alpha). Mirrors train_lm.py."""
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    cur_lr = lr; alpha_min = float("inf")
    l0 = None; it = 0; diverged = False
    done = False
    for ep in range(epochs or 1):
        model.train()
        for X, Y in tl:
            X, Y = X.to(dev), Y.to(dev)
            opt.zero_grad(set_to_none=True)
            loss = crit(model(X), Y); loss.backward(); opt.step()
            lv = float(loss.detach())
            if l0 is None: l0 = lv
            if not np.isfinite(lv) or lv > 5 * l0: diverged = True; done = True; break  # 5x = paper criterion (eos/divergence.py)
            it += 1
            if it in PROBATION_STEPS:
                # deployed protocol: backtracking cap K=8 (Algorithm 1), so the
                # reading floors at beta^8 and the cap at kappa*beta^8.
                _, a = armijo_cap(model, crit, Xb, Yb, cur_lr, kappa,
                                  "adam", max_iter=8)
                alpha_min = min(alpha_min, a)
                target = kappa * alpha_min
                if cur_lr > target:
                    cur_lr = target
                    for grp in opt.param_groups:
                        grp["lr"] = cur_lr
            if steps and it >= steps: done = True; break
        if done: break
    return (float("nan") if diverged else evaluate(model, te)), diverged, cur_lr


def build_suite(ep, tsteps):
    """The nine-architecture suite: loaders + (name, factory, tl, te, train
    kwargs) exactly as used for the published tables. Factored out of main()
    so the validation re-runs (eos/rerun_suite_protocols.py) use the
    identical models, loaders and budgets."""
    cif_tl, cif_te = make_cifar10_loaders(batch_size=256, num_workers=3, seed=0)
    fas_tl, fas_te = make_fashion_mnist_loaders(batch_size=256, num_workers=3, seed=0)
    ag_tl, ag_te, vocab = make_agnews_loaders(batch_size=256, num_workers=2, seed=0)
    archs = [
        ("cifar_bn", lambda: cifar_resnet18(), cif_tl, cif_te, dict(epochs=ep)),
        ("fashion", lambda: FashionCNN(), fas_tl, fas_te, dict(epochs=ep)),
        ("cifar_nobn", lambda: strip_norm(cifar_resnet18()), cif_tl, cif_te, dict(epochs=ep)),
        ("transformer_nowarmup",
         lambda: AGNewsTransformer(vocab, num_classes=4, d_model=256, nhead=4,
                                   num_layers=8, dim_feedforward=1024, max_len=64),
         ag_tl, ag_te, dict(steps=tsteps)),
        # --- scale-up: more diverse architectures (norm / recurrence / depth / domain) ---
        ("mlp_fashion", lambda: MLP(784, 10), fas_tl, fas_te, dict(epochs=ep)),
        ("vgg_bn_cifar", lambda: vgg_bn(10), cif_tl, cif_te, dict(epochs=ep)),
        ("resnet_gn_cifar", lambda: bn_to_gn(cifar_resnet18()), cif_tl, cif_te, dict(epochs=ep)),
        ("lstm_agnews", lambda: LSTMClf(vocab), ag_tl, ag_te, dict(steps=tsteps)),
        ("transformer_wide", lambda: AGNewsTransformer(vocab, num_classes=4, d_model=384,
                              nhead=6, num_layers=6, dim_feedforward=1536, max_len=64),
         ag_tl, ag_te, dict(steps=tsteps)),
    ]
    return archs


def main():
    crit = nn.CrossEntropyLoss()
    ep = 1 if SMOKE else 3
    tsteps = 100 if SMOKE else 600
    archs = build_suite(ep, tsteps)
    variants = [  # (label, mode, kappa)   mode None = vanilla (no cap)
        ("vanilla", None, None),
        ("gradprobe_k0.25", "grad", 0.25),
        ("adamprobe_k3", "adam", 3.0),
    ]
    etas = [1e-3] if SMOKE else [1e-3, 0.1]
    path = f"{RES}/validate_adamdir.csv"
    if PROBATION_ONLY:
        variants = [("adamprobe_k2_probation", "adam_probation", 2.0)]
        path = os.path.join(RUNS, "probation_universality.csv")
    new = not os.path.exists(path); f = open(path, "a", newline="")
    w = csv.DictWriter(f, fieldnames=["arch", "variant", "eta", "seed", "capped_lr",
                                      "alpha_bar", "diverged", "test_acc"])
    if new: w.writeheader(); f.flush()
    seen = set() if new else {(r["arch"], r["variant"], r["eta"], r["seed"])
                              for r in csv.DictReader(open(path))}
    log(f"VALIDATE START (SMOKE={SMOKE})")
    t0 = time.time()
    for arch, mf, tl, te, tk in archs:
        Xb = Yb = None
        for X, Y in tl:
            Xb, Yb = X[:256].to(dev), Y[:256].to(dev); break
        for eta in etas:
            for label, mode, kappa in variants:
                for sd in range(SEEDS):
                    key = (arch, label, str(eta), str(sd))
                    if key in seen: continue
                    try:
                        torch.manual_seed(sd)
                        model = mf().to(dev)
                        if mode is None:
                            clr, ab = eta, float("nan")
                            acc, div = train(model, tl, te, clr, **tk)
                        elif mode == "adam_probation":
                            # deployed protocol: the INIT probe
                            # extends backtracking on saturation (max_iter=30
                            # covers every acceptance here) so ultra-sharp
                            # landscapes like the no-norm ResNet are read below
                            # the beta^8 floor; the probationary RE-probes stay
                            # at K=8 (they correct the initial probe reading, they
                            # do not chase the instantaneous step).
                            clr, ab = armijo_cap(model, crit, Xb, Yb, eta, kappa,
                                                 "adam", max_iter=30)
                            acc, div, clr = train_probation(model, tl, te, clr,
                                                            kappa, Xb, Yb, crit, **tk)
                        else:
                            clr, ab = armijo_cap(model, crit, Xb, Yb, eta, kappa, mode)
                            acc, div = train(model, tl, te, clr, **tk)
                        w.writerow(dict(arch=arch, variant=label, eta=eta, seed=sd,
                                        capped_lr=round(clr, 7), alpha_bar=round(ab, 7) if ab==ab else "",
                                        diverged=int(div), test_acc=round(acc, 4) if acc==acc else "")); f.flush()
                    except Exception:
                        log(f"!!! {arch} {label} eta={eta} s{sd} FAILED:\n{traceback.format_exc()}")
            log(f"done: {arch} eta={eta} ({(time.time()-t0)/60:.1f} min)")
    log(f"VALIDATE DONE in {(time.time()-t0)/60:.1f} min")


if __name__ == "__main__":
    main()
