# eos/summarize_kappa.py
#
# Reproduction artifact: prints the LaTeX body of Table \label{tab:kappa-sens}
#   (Appendix B, kappa sensitivity) in armijo_curvature_probe.tex.
#   Data: kappa-sensitivity sweep of run_cifar_seeds_kappa.sh.
#
# Kappa sensitivity for Adam-InitOnly on CIFAR-10/ResNet-18.
# Aggregates cifar_kappa{K}_lr{LR}_seed{S} into a kappa x lr grid of mean
# test accuracy (std in parentheses), and emits a paste-ready LaTeX table.

import os, json
import numpy as np

ROOT = "eos/runs"
KAPPAS = ["0.05", "0.1", "0.25", "0.5", "1.0"]
LRS = ["0.001", "0.1", "1.0"]
SEEDS = [0, 1, 2]


def cell(k, lr):
    accs, divs = [], []
    for sd in SEEDS:
        p = f"{ROOT}/cifar_kappa{k}_lr{lr}_seed{sd}/summary.json"
        if not os.path.exists(p):
            continue
        s = json.load(open(p))
        divs.append(int(s["diverged"]))
        if not s["diverged"]:
            accs.append(s["test_acc"])
    n = len(divs)
    if n == 0:
        return "--"
    if sum(divs) == n:
        return "DIV."
    mean, std = float(np.mean(accs)), float(np.std(accs))
    s = f"${mean:.3f} \\pm {std:.3f}$"
    if sum(divs) > 0:
        s = f"{mean:.3f}\\,({sum(divs)}/{n} div.)"
    return s


def main():
    print("\n=== kappa sensitivity (console) ===")
    print(f"{'kappa':<8}" + "".join(f"{('lr='+lr):<22}" for lr in LRS))
    for k in KAPPAS:
        print(f"{k:<8}" + "".join(f"{cell(k, lr):<22}" for lr in LRS))

    print("\n=== LaTeX table (paste into paper) ===")
    print("\\begin{tabular}{lccc}")
    print("\\toprule")
    print("$\\kappa$ & $\\eta=10^{-3}$ & $\\eta=10^{-1}$ & $\\eta=1.0$ \\\\")
    print("\\midrule")
    for k in KAPPAS:
        cells = [cell(k, lr) for lr in LRS]
        print(f"${k}$ & {' & '.join(cells)} \\\\")
    print("\\bottomrule")
    print("\\end{tabular}")


if __name__ == "__main__":
    main()
