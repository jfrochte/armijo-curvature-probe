# eos/simulate_retry.py
#
# Reproduction artifact: prints the LaTeX rows of Table \label{tab:retry} in
#   armijo_curvature_probe.tex and writes eos/runs/retry_baseline_summary.csv.
#
# Motivation: compare the init-probe safeguard
# against the simple practitioner strategy "retry on divergence": start at the
# chosen learning rate, and every time training diverges, restart from scratch
# at the next lower rate. This baseline addresses the same first-step failure
# mode at nominally similar cost.
#
# The simulation replays existing grid runs, no new training: for each dataset
# the ladder is the descending learning-rate grid {3.0, 1.0, 0.3, 0.1, 0.01,
# 0.001} and each attempt at (lr, seed) reuses the recorded outcome of run
# <ds>_adam_lr<lr>_seed<s>. A diverged attempt costs the steps until the
# divergence detector fires (parsed from "[diverged] step=S" in the run log;
# detector: loss > 5x initial or non-finite, eos/divergence.py). This credits
# the baseline with the earliest reasonable detection; a human watching a loss
# curve is slower. The final attempt is the first non-diverged rung; its
# accuracy and step count come from its summary.json / trace.csv.
#
# Usage: python -m eos.simulate_retry [eta_start ...]   (default: 3.0)

import os, re, sys, json, glob
import numpy as np
import pandas as pd

RUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
GRID = [3.0, 1.0, 0.3, 0.1, 0.01, 0.001]
DATASETS = [("cifar", "CIFAR-10/ResNet-18"),
            ("fashion", "Fashion-MNIST/CNN"),
            ("agnews", "AG News/Transformer"),
            ("imagenette", "Imagenette/ResNet-18")]
SEEDS = range(5)


def run_dir(ds, lr, seed, opt="adam"):
    return os.path.join(RUNS, f"{ds}_{opt}_lr{lr}_seed{seed}")


def load_summary(ds, lr, seed, opt="adam"):
    p = os.path.join(run_dir(ds, lr, seed, opt), "summary.json")
    if not os.path.exists(p):
        return None
    return json.load(open(p))


TRACE_INTERVAL = 20  # train_adam_sls.py logging interval


def divergence_step(ds, lr, seed):
    """Step at which the detector fired: exact from the run log; where the log
    is missing (fashion grid), a conservative upper bound from the last trace
    row plus one logging interval."""
    log = run_dir(ds, lr, seed) + ".log"
    if os.path.exists(log):
        hits = re.findall(r"\[diverged\] step=(\d+)", open(log).read())
        if hits:
            return int(hits[-1]), True
    trace = os.path.join(run_dir(ds, lr, seed), "trace.csv")
    last = 0
    if os.path.exists(trace):
        df = pd.read_csv(trace)
        if len(df):
            last = int(df["step"].iloc[-1])
    return last + TRACE_INTERVAL, False


def full_run_steps(ds, lr, seed, opt="adam"):
    trace = os.path.join(run_dir(ds, lr, seed, opt), "trace.csv")
    if os.path.exists(trace):
        df = pd.read_csv(trace)
        if len(df):
            return int(df["step"].iloc[-1])
    return np.nan


def simulate(ds, eta_start, seed):
    """Walk the ladder from eta_start down; return path, cost, final outcome."""
    ladder = [lr for lr in GRID if lr <= eta_start]
    wasted, path, exact = 0, [], True
    for lr in ladder:
        s = load_summary(ds, lr, seed)
        if s is None:
            return None
        path.append(lr)
        if s.get("diverged"):
            w, ex = divergence_step(ds, lr, seed)
            wasted += w
            exact = exact and ex
            continue
        return {"final_lr": lr, "acc": s["test_acc"], "restarts": len(path) - 1,
                "wasted_steps": wasted, "exact": exact,
                "full_steps": full_run_steps(ds, lr, seed),
                "path": path}
    return {"final_lr": np.nan, "acc": np.nan, "restarts": len(path) - 1,
            "wasted_steps": wasted, "exact": exact, "full_steps": np.nan,
            "path": path}


def init_dir_acc(ds, eta, seed):
    s = load_summary(ds, eta, seed, opt="adam_init_dir")
    if s is None:
        return np.nan
    return 0.0 if s.get("diverged") else s["test_acc"]


def main(etas):
    rows = []
    for ds, label in DATASETS:
        for eta in etas:
            per_seed = [simulate(ds, eta, s) for s in SEEDS]
            per_seed = [r for r in per_seed if r is not None]
            if not per_seed:
                print(f"[skip] {ds} eta={eta}: no runs")
                continue
            probe = [a for a in (init_dir_acc(ds, eta, s) for s in SEEDS)
                     if np.isfinite(a)]
            acc = [r["acc"] for r in per_seed]
            over = [100.0 * r["wasted_steps"] / r["full_steps"]
                    for r in per_seed if np.isfinite(r["full_steps"])]
            rows.append({
                "dataset": ds, "label": label, "eta_start": eta,
                "n_seeds": len(per_seed),
                "exact": all(r["exact"] for r in per_seed),
                "final_lr": per_seed[0]["final_lr"],
                "restarts_mean": np.mean([r["restarts"] for r in per_seed]),
                "wasted_steps_mean": np.mean([r["wasted_steps"] for r in per_seed]),
                "overhead_pct_mean": np.mean(over) if over else np.nan,
                "retry_acc_mean": np.nanmean(acc), "retry_acc_std": np.nanstd(acc),
                "initdir_acc_mean": np.mean(probe) if probe else np.nan,
                "initdir_acc_std": np.std(probe) if probe else np.nan,
                "path": "->".join(str(x) for x in per_seed[0]["path"]),
            })
    df = pd.DataFrame(rows)
    out = os.path.join(RUNS, "retry_baseline_summary.csv")
    df.to_csv(out, index=False)
    # Side-effect message goes to stderr: freeze_paper_data.py captures this
    # script's stdout verbatim as the canonical table body, and an absolute
    # path has no business in that frozen snapshot.
    print(f"[written] {out}\n", file=sys.stderr)
    print(df.to_string(index=False))

    print("\n  LaTeX rows (Dataset & restarts & wasted steps & overhead"
          " & retry acc & Adam-InitOnly (dir) acc); ladder in the caption:")
    for _, r in df.iterrows():
        le = "" if r.exact else "\\le "
        wa = (f"{r.retry_acc_mean:.3f} \\pm {r.retry_acc_std:.3f}"
              if np.isfinite(r.retry_acc_mean) else "DIV.")
        pa = (f"{r.initdir_acc_mean:.3f} \\pm {r.initdir_acc_std:.3f}"
              if np.isfinite(r.initdir_acc_mean) else "--")
        ov = (f"${le}{r.overhead_pct_mean:.1f}\\%$"
              if np.isfinite(r.overhead_pct_mean) else "--")
        print(f"  {r['label']} & {r.restarts_mean:.0f}"
              f" & ${le}{r.wasted_steps_mean:.0f}$ & {ov} & ${wa}$ & ${pa}$ \\\\")


if __name__ == "__main__":
    etas = [float(x) for x in sys.argv[1:]] or [3.0]
    main(etas)
