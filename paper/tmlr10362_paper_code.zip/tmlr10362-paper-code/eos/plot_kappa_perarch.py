# eos/plot_kappa_perarch.py
#
# Reproduction artifact: produces runs/fig_kappa_perarch.png
#   -> Figure \label{fig:kappa-perarch} in armijo_curvature_probe.tex
#   Data: runs/kappa_universality.csv (vanilla, grad probe kappa=0.25) and
#         runs/kappa_sweep_adamdir.csv (Adam-direction probe, kappa=2),
#   the same sources as tab:universal-kappa / tab:kappa-perarch.
#
# Message: the paper's strongest result, made visible. At the discriminating
# 100x-too-large learning rate (eta = 0.1), one fixed kappa = 2 with the
# direction-matched probe keeps every one of the nine architectures training
# (best accuracy everywhere, zero divergences), while vanilla Adam diverges on
# most and the plain-gradient probe at a single kappa fails on several.
# Divergent runs count as accuracy 0, exactly as in the tables.

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

RUNS = "eos/runs"
PRETTY = {
    "cifar_bn": "ResNet-18 BN (CIFAR-10)", "fashion": "CNN (Fashion-MNIST)",
    "cifar_nobn": "ResNet-18 no-norm (CIFAR-10)", "resnet_gn_cifar": "ResNet-18 GN (CIFAR-10)",
    "vgg_bn_cifar": "VGG BN (CIFAR-10)", "mlp_fashion": "MLP (Fashion-MNIST)",
    "lstm_agnews": "LSTM (AG News)", "transformer_nowarmup": "Transformer no-warmup (AG News)",
    "transformer_wide": "Transformer wide (AG News)",
}
ORDER = ["cifar_bn", "vgg_bn_cifar", "resnet_gn_cifar", "cifar_nobn", "fashion",
         "mlp_fashion", "lstm_agnews", "transformer_nowarmup", "transformer_wide"]
# Colours follow the conventions of the other paper figures: vanilla Adam red,
# our recommended variant blue; the intermediate grad probe orange.
METHODS = [
    ("vanilla Adam", "C3"),
    (r"grad probe ($\kappa=0.25$)", "C1"),
    (r"Adam-dir probe ($\kappa=2$, ours)", "C0"),
]
ETA = 0.1


def stats(d):
    """(mean acc with divergent run = 0, n divergent, n runs) for a run subset."""
    n = len(d)
    if n == 0:
        return None
    ndiv = int(d.diverged.sum())
    acc = float(np.where(d.diverged == 1, 0.0, d.test_acc).mean())
    return acc, ndiv, n


def main(out="eos/runs/fig_kappa_perarch.png"):
    df = pd.read_csv(f"{RUNS}/kappa_universality.csv")
    sweep = pd.read_csv(f"{RUNS}/kappa_sweep_adamdir.csv")
    per_arch = []
    for arch in ORDER:
        van = stats(df[(df.arch == arch) & (df.variant == "vanilla")
                       & (np.isclose(df.eta, ETA))])
        grad = stats(df[(df.arch == arch) & (df.variant == "gradprobe_k0.25")
                        & (np.isclose(df.eta, ETA))])
        adam = stats(sweep[(sweep.arch == arch) & (np.isclose(sweep.kappa, 2.0))
                           & (np.isclose(sweep.eta, ETA))])
        per_arch.append((PRETTY[arch], [van, grad, adam]))

    fig, ax = plt.subplots(figsize=(9, 6.2))
    ngroup = len(per_arch)
    ys = np.arange(ngroup)[::-1]          # first architecture on top
    off = [0.27, 0.0, -0.27]              # vanilla top, Adam-dir bottom per group
    height = 0.24
    for j, (label, color) in enumerate(METHODS):
        yy = ys + off[j]
        for i, (_, vals) in enumerate(per_arch):
            acc, ndiv, n = vals[j]
            if ndiv == n:                 # all seeds diverged: no bar, x marker
                ax.plot(0.012, yy[i], marker="x", color=color, ms=8, mew=2.2,
                        clip_on=False)
                ax.text(0.030, yy[i], "DIV.", color=color, fontsize=8,
                        va="center", ha="left")
                continue
            ax.barh(yy[i], acc, height=height, color=color, alpha=0.9,
                    edgecolor="white", linewidth=0.8)
            note = f"{acc:.2f}" + (f" ({ndiv}/{n} div.)" if ndiv else "")
            ax.text(acc + 0.012, yy[i], note, color="0.25", fontsize=8,
                    va="center", ha="left")
    ax.set_yticks(ys)
    ax.set_yticklabels([name for name, _ in per_arch], fontsize=9)
    ax.set_xlim(0, 1.0)
    ax.set_xlabel(r"Test accuracy at the $100\times$-too-large rate "
                  r"($\eta = 0.1$), mean over 3 seeds; divergent run $= 0$")
    ax.set_title("One fixed safety factor across nine architectures",
                 pad=32)
    handles = [Patch(facecolor=color, label=label) for label, color in METHODS]
    ax.legend(handles=handles, ncol=3, loc="lower center",
              bbox_to_anchor=(0.5, 1.005), frameon=False, fontsize=9)
    ax.grid(True, axis="x", alpha=0.2)
    ax.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print(f"[plot] {out}")


if __name__ == "__main__":
    main()
