# Code and data of the paper

Reference implementation and frozen result snapshot for

> Ashmitha R and Jörg Frochte. Directional Curvature from Armijo Backtracking:
> A Low-Cost Sharpness Probe and a Calibration-Free Learning-Rate Safeguard for
> Adam. Transactions on Machine Learning Research, 2026.
> https://openreview.net/forum?id=foLGwG3ne4 (arXiv:2607.03998)

This is the archive provided as supplementary material during review, with the
author names restored. Absolute paths and environment prefixes are removed;
nothing else was changed.

## Layout

    eos/                     reference implementation (probe, training, analysis)
    eos/REPRODUCE.md         how to re-run every experiment end to end
    eos/environment.yml      conda environment
    eos/LICENSE              MIT license
    results/                 frozen snapshot: one CSV per experiment, the
                             canonical table bodies, the figures, and
                             PROVENANCE.md with a truncated sha256
                             (first 16 hex chars) per file
    results/verify_tables.py drift check (see below)

Scripts covering the points raised in review:

    eos/detrend_correlation.py     detrended / first-difference correlation
    eos/simulate_retry.py          retry-on-divergence baseline
    eos/probe_batch_variance.py    single-batch probe noise at initialisation
    eos/train_lm.py, eos/lm.py     GPT-2 pretraining on WikiText-103
    eos/lm_sharpening_curve.py     re-probing during early training
    eos/lm_kappa_ladder.py         size ladder (16M / 45M / 124M / 355M)
    eos/run_lm_grid.sh             full learning-rate grid for the LM runs
    eos/no_op_paired_test.py       paired state/first-update no-op test (app. I)
    eos/summarize_noop_fullrun.py  whole-run no-op check at eta = 1e-3 (app. I)
    eos/run_lowcost_baselines.sh   low-cost baselines (clip, warmup, SF-AdamW,
    eos/summarize_lowcost_baselines.py   Prodigy) across all four benchmarks
    eos/run_rangetest_all.py       learning-rate range test on all benchmarks
    eos/summarize_rangetest_all.py       with pass-count cost accounting

## Verifying the numbers

The manuscript source is not included; it is available from arXiv:2607.03998. The
canonical table bodies in `results/tables_canonical/` correspond one-to-one to
the tables in the submitted PDF and can be checked against it directly. The
drift checker takes the source as an argument once it is available:

    python results/verify_tables.py path/to/manuscript.tex

Run without an argument it lists the tables it covers.

## What is not included

Raw per-run logs and checkpoints are omitted for size. `results/` is the
frozen, self-contained snapshot every table and figure in the manuscript is
built from; `eos/REPRODUCE.md` documents how to regenerate the raw runs.
