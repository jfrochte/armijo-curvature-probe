"""verify_tables.py -- drift check for the manuscript's tables.

Compares every numeric value in the manuscript's table bodies against the
frozen, data-derived canonical snapshot in this folder (produced by
`python -m eos.freeze_paper_data`). Exits non-zero and lists every canonical
number that does NOT appear in the corresponding .tex table.

The manuscript source is NOT part of this archive (see arXiv:2607.03998).
Pass it explicitly:

    python results/verify_tables.py path/to/manuscript.tex
    TEX=path/to/manuscript.tex python results/verify_tables.py

Without it the script reports what it would check and exits 0. The canonical
table bodies in results/tables_canonical/ correspond one-to-one to the tables
in the submitted PDF and can be compared against it directly.

It is tolerant of rounding (2 dp), bold, spacing and DIV./notation
differences; it only asks: is each canonical number present in that body?
"""
import os, re, sys
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
TEX = (sys.argv[1] if len(sys.argv) > 1 else os.environ.get("TEX"))
CANON = os.path.join(HERE, "tables_canonical")
TOL = 0.011
NUM = re.compile(r"-?\d+\.\d+|-?\d+")


def floats(s):
    return [float(x) for x in NUM.findall(s)]


def tex_table_body(label):
    """Extract text from \\label{label} up to the first \\end{tabular}."""
    txt = open(TEX).read()
    i = txt.find("\\label{" + label + "}")
    if i < 0:
        return None
    j = txt.find("\\end{tabular}", i)
    return txt[i:j] if j > 0 else txt[i:i + 4000]


def canonical_from_body(label):
    fn = os.path.join(CANON, label.replace(":", "_") + ".body.tex")
    if not os.path.exists(fn):
        return None
    # keep data rows only: contain ' & ', and are not column-header rows (which
    # carry the learning-rate / kappa column labels written with different
    # notation, e.g. $\eta=0.1$ vs $10^{-1}$ in the .tex -- a label, not data).
    rows = [ln for ln in open(fn).read().splitlines()
            if " & " in ln and "\\eta" not in ln and "multicolumn" not in ln]
    # drop 0.0 (zero std of single-seed rows; never a meaningful data value)
    return [x for x in floats("\n".join(rows)) if abs(x) > 1e-9]


# ---- CSV-derived canonical numbers for the four CSV-backed tables ----
def canon_rescue():
    d = pd.read_csv(os.path.join(HERE, "adam_sls_summary.csv"))
    # Includes the direction-matched and AdamW rows: those are the paper's
    # recommended method and were previously NOT covered by this checker.
    opts = ["adam", "adam_init_only", "adam_watchdog", "adam_tracker",
            "adam_schedulefree", "prodigy",
            "adam_init_dir", "adamw", "adamw_init_dir"]
    vals = []
    for _, r in d[d.opt.isin(opts)].iterrows():
        if r.div_rate == 0 and pd.notna(r.mean_acc):
            vals.append(round(float(r.mean_acc), 3))
    return vals


def canon_baselines():
    d = pd.read_csv(os.path.join(HERE, "adam_sls_summary.csv"))
    want = {("adam", 0.001), ("adam_clip", 0.001), ("adam_warmup", 0.1),
            ("adam_init_only", 0.001), ("adam_init_only", 0.1), ("adam_init_only", 1.0),
            ("adam_watchdog", 0.001), ("adam_watchdog", 0.1), ("adam_watchdog", 1.0),
            ("adam_tracker", 0.001), ("adam_tracker", 0.1), ("adam_tracker", 1.0)}
    vals = []
    for _, r in d.iterrows():
        if (r.opt, r.lr) in want and r.div_rate == 0 and pd.notna(r.mean_acc):
            vals.append(round(float(r.mean_acc), 3))
    return vals


def canon_universal():
    d = pd.read_csv(os.path.join(HERE, "kappa_universality.csv"))
    vals = []
    for v in ["vanilla", "gradprobe_k0.25", "adamprobe_k3"]:
        for eta in [0.001, 0.1]:
            vals.append(int(d[(d.variant == v) & (np.isclose(d.eta, eta))].diverged.sum()))
        vals.append(int(d[d.variant == v].diverged.sum()))
    # mean test accuracy per (variant, eta), divergent run counted as 0
    for v in ["vanilla", "gradprobe_k0.25", "adamprobe_k3"]:
        for eta in [0.001, 0.1]:
            s = d[(d.variant == v) & (np.isclose(d.eta, eta))]
            acc = np.where(s.diverged == 1, 0.0, s.test_acc).mean()
            vals.append(round(float(acc), 3))
    return [float(x) for x in vals]


def canon_fidelity():
    d = pd.read_csv(os.path.join(HERE, "probe_fidelity.csv"))
    b = d[(d.kind == "beta") & (d.step > 0)].copy()      # depth-matched: drop step-0 cap
    b["ratio"] = 2 * b.inv_alpha / b.q
    return [round(b[b.beta == be].ratio.median(), 2) for be in [0.5, 0.7, 0.9]]


CSV_CANON = {
    "tab:rescue": canon_rescue, "tab:baselines": canon_baselines,
    "tab:universal-kappa": canon_universal, "tab:fidelity": canon_fidelity,
}
BODY_TABLES = ["tab:correlation", "tab:correlation-detrended", "tab:fashion-rescue", "tab:agnews-rescue",
               "tab:kappa-sens", "tab:longrun", "tab:default-unsafe", "tab:periodic",
               "tab:rangetest", "tab:lowcost-cross",
               "tab:kappa-universal-sweep", "tab:kappa-perarch",
               "tab:retry", "tab:probe-variance", "tab:lm-rescue",
               "tab:heldout-kappa2", "tab:correlation-robust"]


def check(label, canon):
    body = tex_table_body(label)
    if body is None:
        return f"  [WARN] {label}: not found in .tex", 0
    if not canon:
        # An empty canonical set means the aggregator produced no numbers
        # (e.g. its source CSV is missing) -- that is an UNPROTECTED table,
        # not a pass. Count it as a failure so it cannot slip through.
        return f"  [FAIL] {label}: canonical snapshot is EMPTY (aggregator failed?)", 1
    tex_nums = floats(body)
    missing = []
    for c in canon:
        if not any(abs(c - t) <= TOL for t in tex_nums):
            missing.append(c)
    if missing:
        return (f"  [DRIFT] {label}: {len(missing)} canonical value(s) absent "
                f"from .tex: {sorted(set(missing))}", len(missing))
    return f"  [ok]    {label}: {len(canon)} values present", 0


def main():
    if not TEX or not os.path.exists(TEX):
        print("No manuscript source given; pass it as an argument or set $TEX.")
        print("Canonical snapshot in", HERE, "covers these tables:")
        for lbl in list(BODY_TABLES) + list(CSV_CANON):
            print("   ", lbl)
        sys.exit(0)
    print("Verifying .tex tables against frozen snapshot in", HERE)
    total = 0
    for label in BODY_TABLES:
        canon = canonical_from_body(label)
        if canon is None:
            print(f"  [WARN] {label}: no frozen body (run eos.freeze_paper_data)"); continue
        msg, n = check(label, canon); print(msg); total += n
    for label, fn in CSV_CANON.items():
        try:
            canon = fn()
        except FileNotFoundError:
            print(f"  [WARN] {label}: frozen CSV missing (run eos.freeze_paper_data)"); continue
        msg, n = check(label, canon); print(msg); total += n
    print()
    if total:
        print(f"FAIL: {total} drifted value(s). Update the .tex or re-freeze."); sys.exit(1)
    print("PASS: every canonical value appears in its table.")


if __name__ == "__main__":
    main()
