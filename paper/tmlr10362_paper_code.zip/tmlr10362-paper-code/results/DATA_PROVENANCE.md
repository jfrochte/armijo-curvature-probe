# Data provenance — exact inputs behind the reported numbers

This records *which version* of each public dataset produced the results in
`PROVENANCE.md`, and the checksums of the derived files the training code
actually reads. The raw downloads themselves are not archived here: they are
public and pinned by revision below, and the derived files are what the runs
consumed.

## Hub datasets, pinned by revision

| Dataset | Repo | Config | Revision (Hub commit) |
|---|---|---|---|
| AG News | `fancyzhx/ag_news` | default | `eb185aade064a813bc0b7f42de02595523103ca4` |
| WikiText-103 | `Salesforce/wikitext` | `wikitext-103-raw-v1` | `b08601e04326c79dfdd32d625aee71d232d685c3` |

Both revisions are pinned in the code (`eos/data.py:_AGNEWS_REVISION`,
`eos/lm.py:WIKITEXT_REVISION`), so a re-upload on the Hub cannot silently
change the input to a reproduction run.

## Other datasets (no Hub involvement)

| Dataset | Source |
|---|---|
| CIFAR-10 | `https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz` |
| Fashion-MNIST | `torchvision.datasets.FashionMNIST` (download=True) |
| Imagenette (160px) | `https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-160.tgz` |
| scikit-learn digits | `sklearn.datasets.load_digits` (bundled with scikit-learn) |
| GPT-2 BPE | `tiktoken` encoding `"gpt2"` (vocabulary size 50257) |

## Derived files the training code reads (sha256)

Built once by `python -m eos.setup_data`; these are the exact inputs of the
reported runs. Re-creating them from the pinned revisions must reproduce
these checksums.

    18f9a180a0a1a128c280f790eafb718fd5d3c857c244b04847afbef1a6795a90  data/agnews_cache_L64_V20000.pt
    86504d6285bb63ab27e2ebd43528de6f9a278fce0c29c025c37c51cecd38d618  data/agnews_vocab_V20000.json
    fba0b48b732481cb95a06fbb7f93bd3523a65ab13d7e6cb6ccabaec71d25e7c5  data/wikitext103_gpt2_train.bin
    a555c563d8c4082ad9451593a313e65a34dcbba07e5531310bbabaf6fa4e2d6a  data/wikitext103_gpt2_val.bin

Token counts: the train bin holds 117,920,141 uint16 tokens (~118M, the
figure quoted in the language-model section), the validation bin 247,290.

## No-op verification evidence (app:noop)

Two CSVs in this folder sit outside the `freeze_paper_data` set
(`PROVENANCE.md` lists only auto-frozen artefacts):

    6c55b0a28e36156c9754de1c907decfa0cfdf97bb2989931fb1813b93f2622a2  no_op_paired_test.csv
    c8a67dbcc795aa74930b31c0f5c38a546cb191bdb586d87358264ecf3fa44660  noop_fullrun_summary.csv

- `no_op_paired_test.csv` — per-architecture records of the paired
  state/first-update test; regenerate with
  `CUBLAS_WORKSPACE_CONFIG=:4096:8 python -m eos.no_op_paired_test`.
- `noop_fullrun_summary.csv` — the whole-run check at η = 1e-3; regenerate
  with `python -m eos.summarize_noop_fullrun`. It reads the η = 1e-3 grid
  runs (`eos/runs/<ds>_<opt>[_init_dir]_lr0.001_seed*`) plus the evidence
  re-runs under `eos/runs/_noop_fullrun_evidence/`: `hardened_<run>` are the
  same `*_init_dir` configurations re-trained with the current,
  state-restoring implementation; `control_cifar_adam_seed<s>` are
  identical-seed re-runs of the vanilla CIFAR-10 baseline (for example
  `python -m eos.train_adam_sls --dataset cifar10 --optimizer adam
  --lr 0.001 --epochs 10 --batch-size 256 --probe-every 50 --seed <s>`).

## Note on the download cache

The framework caches (`~/.cache/huggingface`, torchvision's download
directory) are *not* part of the reproducible state: everything the runs
consume is the derived set above. Deleting those caches costs one re-download,
which `python -m eos.setup_data` performs from the sources and revisions
listed here.
